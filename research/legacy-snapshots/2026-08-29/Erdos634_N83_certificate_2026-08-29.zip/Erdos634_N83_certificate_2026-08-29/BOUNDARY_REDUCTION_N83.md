# N=83 boundary reduction

This note proves the human geometric reduction used by the N=83 apex-frontier
certificate.  The proof is for ordinary finite triangle tilings by congruent
copies of a triangle; reflected copies and T-junctions are allowed, and no
edge-to-edge hypothesis is made.

## The exact instance and the necessary swap

In the usual Group-1 notation the tile has sides

\[
 (a,b,c)=(30,11,36)
\]

opposite angles \((\alpha,\beta,\gamma)\), with

\[
 3\alpha+2\beta=\pi.
\]

For the boundary lemma, swap the first two angle-side labels and put

\[
 \theta:=\beta,\qquad \phi:=\alpha,
 \qquad (u,v,c):=(11,30,36).
\]

Thus

\[
 2\theta+3\phi=\pi,qquad
 \gamma=\pi-\theta-\phi=\theta+2\phi.
\]

The divisibility hypothesis after this swap is

\[
 v\text{ is not a multiple of }u,
 \quad\text{that is}\quad u\nmid v,
 \quad\text{here }11\nmid30.
\]

This direction matters: the hypothesis is **not** the statement
\(30\nmid11\) obtained by reading the renamed sides backwards.

Since \(u<v<c\), the corresponding angles satisfy
\(\theta<\phi<\gamma\).  Moreover

\[
 \gamma-\frac\pi2
 =\theta+2\phi-\left(\theta+\frac32\phi\right)
 =\frac\phi2>0,
\]

so \(\gamma>\pi/2\).

The angle \(\theta\) is not a rational multiple of \(\pi\).  Indeed, the
cosine rule gives

\[
 \cos\theta
 =\frac{v^2+c^2-u^2}{2vc}
 =\frac{415}{432}.
\]

If \(\theta/\pi\in\mathbb Q\), then \(2\cos\theta\) is both rational and an
algebraic integer, hence an integer.  But \(2\cos\theta=415/216\) is not an
integer.  It follows as well that \(\theta\) and \(\phi\) are linearly
independent over \(\mathbb Q\): a rational relation between them, combined
with \(2\theta+3\phi=\pi\), would make \(\theta/\pi\) rational.

## Target corners contain no gamma sector

The target has sides \((216,216,415)\).  At either endpoint of the side of
length 415, the cosine rule gives

\[
 \cos\angle_{\rm base}
 =\frac{415^2+216^2-216^2}{2\cdot415\cdot216}
 =\frac{415}{432}=\cos\theta.
\]

Hence the target angles are

\[
 (\theta,\theta,\pi-2\theta)=(\theta,\theta,3\phi).
\]

The sector decompositions at those corners are unique.  If nonnegative
integers \(x,y,z\) satisfy

\[
 x\theta+y\phi+z\gamma=\theta,
\]

then, after substituting \(\gamma=\theta+2\phi\) and using the independence
of \(\theta,\phi\),

\[
 x+z=1,\qquad y+2z=0.
\]

Thus \((x,y,z)=(1,0,0)\).  Similarly, a decomposition of the apex angle
\(3\phi\) satisfies

\[
 x+z=0,\qquad y+2z=3,
\]

and therefore \((x,y,z)=(0,3,0)\).  Consequently:

- exactly one tile meets each base corner, with its \(\theta\)-angle there;
- exactly three tile sectors meet the apex, all three equal to \(\phi\);
- no target corner carries a \(\gamma\)-sector.

The last statement is the precise replacement needed below for the stronger
but false-in-this-instance inequality “every target angle is less than
\(\gamma\)”: in fact \(3\phi>\gamma\) because \(\phi>\theta\).

## Repaired two-c-edge lemma

### Lemma (specialized to N=83)

Let the triangle with sides \((216,216,415)\) be the union of finitely many
congruent copies of the \((u,v,c)=(11,30,36)\) tile, with pairwise disjoint
interiors. Reflections and T-junctions are allowed. In the swapped notation
above assume, as has already been verified,

1. \(2\theta+3\phi=\pi\) and \(\gamma=\theta+2\phi\);
2. \(\theta\) and \(\phi\) are linearly independent over \(\mathbb Q\);
3. \(\gamma>\pi/2\) and \(u<v<c\);
4. the target angles are \((\theta,\theta,3\phi)\), with sector inventories
   \(\theta\), \(\theta\), and \(\phi+\phi+\phi\), respectively; and
5. \(u\nmid v\), here \(11\nmid30\).

Then every side of the target contains at least two complete tile edges of
length \(c=36\).

This is the N=83 specialization of Beeson’s Lemma 6
(lemma:zerolimits2 in arXiv:1206.2229v3). Beeson's printed hypothesis
(iii), that every target angle is smaller than \(\gamma\), is used in his
proof only through the consequence that no target corner contains a
\(\gamma\)-sector. That consequence follows here from item 4 even though
the printed inequality itself is false: \(3\phi>\gamma\). The following
proof also makes explicit the local non-edge-to-edge step.

### Proof

We first record two elementary planar facts that will be used below.

**Boundary fact.** Each target side is a concatenation of complete tile
edges. Indeed, let \(L\) be the supporting line of a target side \(S\). A
tile which meets the relative interior of \(S\) in a nondegenerate interval
lies in the target half-plane bounded by \(L\); convexity then makes its
intersection with \(L\) a complete tile edge. Two such edges cannot overlap
in their relative interiors, and no such edge can extend past a target
corner. Finiteness and the equality between the union of the tiles and the
target show that these edges cover \(S\).

The same argument applies on the side opposite a tile along the relative
interior of any internal tile edge: that edge is covered by a finite chain of
collinear complete edges of neighbouring tiles. The first or last edge of
such a chain may extend past an endpoint unless the local geometry there
blocks it. Finally, two non-collinear tile edges cannot meet at a point
interior to both edges. If they did, each of the two corresponding tiles
would occupy a half-neighbourhood on one side of its edge, and the two
half-neighbourhoods would overlap in a sector of positive area. This would
contradict disjointness of tile interiors.

Moreover, the neighbouring edges in such a chain have pairwise disjoint
relative interiors on the same side of the supporting line and are therefore
ordered end to end. Thus, after a first edge starts at one endpoint, if
extension through the other endpoint is blocked, all later edges are complete
and contained in the remaining subsegment.

**Straight-fan fact.** Suppose a \(\gamma\)-sector occurs at an interior
point of a target side. If a tile had this boundary point in the relative interior of one of its
edges, that edge would lie on the target side and the tile would occupy the
whole local target half-neighbourhood. It could not coexist there with a
\(\gamma\)-sector. Thus every incident contribution in the case under
consideration is a genuine tile-angle sector.

At most one of those sectors can equal \(\gamma\), since
\(\gamma>\pi/2\). If one does, the whole straight fan consists of exactly
one sector of each type:

\[
 \theta+\phi+\gamma=\pi.
\]

To check this, write its inventory as
\(x\theta+y\phi+z\gamma=2\theta+3\phi\). The obtuse-angle inequality gives
\(z\le1\); if \(z=1\), substituting
\(\gamma=\theta+2\phi\) and using independence gives \(x=y=1\).

Now fix a target side \(S\). If its boundary decomposition has no
\(c\)-edge, let that decomposition have \(n\) edges. Each boundary tile then
has a \(u\)- or \(v\)-edge on \(S\). A
\(u\)-edge has endpoint angles \(\phi,\gamma\), while a \(v\)-edge has
endpoint angles \(\theta,\gamma\). Thus each of the \(n\) boundary tiles
places one \(\gamma\)-sector at an endpoint of its edge. No two can place
one at the same boundary point, and the two target corners are unavailable
by item 4. There are only \(n-1\) interior junctions, a contradiction.
Every target side therefore has at least one \(c\)-edge.

Suppose for contradiction that \(S\) has exactly one \(c\)-edge. Denote it
by \(PQ\), its tile by \(\Delta_1\), and the third vertex of \(\Delta_1\) by
\(R\). Reverse \(P,Q\) if necessary so that the angles of \(\Delta_1\) at
\(P,Q,R\) are respectively \(\theta,\phi,\gamma\). Consequently

\[
 |PR|=v=30,\qquad |QR|=u=11. \tag{1}
\]

If \(P\) is not a target corner, consider the maximal block of non-\(c\)
boundary edges from \(P\) to the target corner on that side. If the block
contains \(m\) edges, its \(m\) distinct \(\gamma\)-endpoints have only the
\(m-1\) junctions internal to the block and the point \(P\) available; the
target corner is unavailable. Hence the boundary tile next to
\(\Delta_1\) has its \(\gamma\)-angle at \(P\). The same conclusion holds
at \(Q\) whenever \(Q\) is not a target corner. By the straight-fan fact,
at such a \(P\) the sector between that boundary tile and \(\Delta_1\), on
the other side of \(PR\), is a single \(\phi\)-sector; call its tile
\(\Delta_2\). At such a \(Q\), the corresponding sector across \(QR\) is a
single \(\theta\)-sector; call its tile \(\Delta_4\).

We now exhaust the endpoint possibilities.

**Neither \(P\) nor \(Q\) is a target corner.** The edge of \(\Delta_4\)
which starts at its \(\theta\)-vertex \(Q\) along \(QR\) has length \(v\) or
\(c\). Both exceed \(|QR|=u\), so \(R\) is an interior point of this edge.
The edge of \(\Delta_2\) which starts at its \(\phi\)-vertex \(P\) along
\(PR\) has length \(u\) or \(c\). It cannot have length \(c>v=|PR|\), for
then the two non-collinear edges would cross at \(R\), with \(R\) interior
to both. Hence this first edge has length \(u\).

The edge of \(\Delta_4\) through \(R\) also prevents every subsequent edge
in the collinear chain covering \(PR\) from extending past \(R\): any such
edge would contain \(R\) in its relative interior and cross the
\(\Delta_4\)-edge there. After the first \(u\)-edge, the uncovered length
is \(v-u=19<v<c\). Therefore every
remaining complete edge in that chain has length \(u\). The chain is an
exact partition of \(PR\), so \(u\mid v\), contradicting item 5. Notice
that the chain may contain arbitrarily many T-junctions; no edge-to-edge
assumption has been used.

**\(P\) is a target corner and \(Q\) is not.** The tile \(\Delta_1\)
contributes \(\theta\) at \(P\). The unique apex inventory
\(3\phi=\phi+\phi+\phi\) rules out the apex, so \(P\) is a base corner of
angle \(\theta\), completely filled by \(\Delta_1\). Thus \(PR\) lies on
the other target side through \(P\). At \(Q\), the edge of \(\Delta_4\)
along \(QR\) has length \(v\) or \(c\), hence continues beyond \(R\) by
(1). But \(QR\) approaches the target side \(PR\) from the interior of the
target, so its continuation beyond \(R\) lies outside the convex target.
This is impossible for a tile edge.

**\(Q\) is a target corner and \(P\) is not.** Since \(\Delta_1\)
contributes \(\phi>\theta\), the corner \(Q\) cannot be a base corner. It is
the apex, whose exact inventory consists of three \(\phi\)-sectors. The
tile immediately across \(QR\) from \(\Delta_1\), again denoted
\(\Delta_4\), consequently has its \(\phi\)-angle at \(Q\). Its edge along
\(QR\) has length either \(u\) or \(c\).

If that edge has length \(c>u=|QR|\), it passes through \(R\). It then
blocks every edge in the chain along \(PR\) from extending beyond \(R\),
exactly as in the first case. The first such edge, belonging to
\(\Delta_2\), is therefore \(u\), not \(c\), and the same length argument
again gives \(u\mid v\), a contradiction.

If instead the edge of \(\Delta_4\) along \(QR\) has length \(u\), it ends
at \(R\), and the side-angle correspondence makes the angle of
\(\Delta_4\) at \(R\) equal to \(\gamma\). Starting from the ray \(RP\),
the sector of \(\Delta_1\) up to \(RQ\) has angle \(\gamma\), and the next
sector, belonging to \(\Delta_4\), also has angle \(\gamma\). Since
\(2\gamma>\pi\), the continuation beyond \(R\) of the line \(PR\) lies
strictly inside \(\Delta_4\). Thus no edge covering the opposite side of
\(PR\) can extend past \(R\). Once more \(\Delta_2\) must start with a
\(u\)-edge, all remaining edges are \(u\)-edges, and \(u\mid v\), a
contradiction.

The only nominal case left is that both \(P\) and \(Q\) are target corners.
Then \(PQ\) would be the whole target side, but \(|PQ|=c=36\) whereas the
target side lengths are 216 and 415. Hence this case cannot occur.

All cases are impossible, so \(S\) cannot contain exactly one \(c\)-edge.
Together with the first pigeonhole argument, it contains at least two. The
choice of \(S\) was arbitrary. \(\square\)

## Consequences for the two legs

Let \((x,y,z)\) count boundary edges of lengths \((30,11,36)\) on a leg.
Then

\[
 30x+11y+36z=216,qquad z\ge2.
\]

Reduction modulo 6 gives \(y\equiv0\pmod6\); write \(y=6k\).  Dividing by
6 gives

\[
 5x+11k+6z=36.
\]

Since \(z\ge2\), one has \(k\in\{0,1,2\}\).  Modulo 5,
\(k+z\equiv1\pmod5\):

- if \(k=0\), then \(2\le z\le6\) and \(z\equiv1\pmod5\), hence \(z=6\)
  and \(x=0\);
- if \(k=1\), then \(z\le4\) but \(z\equiv0\pmod5\), impossible;
- if \(k=2\), then \(z\le2\) but \(z\equiv4\pmod5\), impossible.

Thus each equal side is uniquely

\[
 (x,y,z)=(0,0,6),
\]

i.e. each leg is exactly \(c^6\).

## Consequences for the base

At a base corner the target angle is \(\theta\), and its sector inventory is
the single \(\theta\)-angle of one tile.  The two tile sides incident there
are \(v=30\) and \(c=36\).  The leg edge is already forced to be a
\(c\)-edge, so the edge of that corner tile on the base is a 30-edge.  This
happens at both base corners.  Therefore, if \((x,y,z)\) counts base edges of
lengths \((30,11,36)\), then

\[
 30x+11y+36z=415,qquad z\ge2,qquad x\ge2.
\]

Modulo 6, \(y\equiv5\pmod6\), so write \(y=5+6k\).  The equation becomes

\[
 5x+11k+6z=60.
\]

Modulo 5, \(k+z=5m\) for a positive integer \(m\).  Substitution gives

\[
 x+k=12-6m.
\]

The conditions \(x\ge2\), \(z\ge2\) force \(m=1\).  Hence

\[
 x=6-k,qquad y=5+6k,qquad z=5-k.
\]

Finally \(z\ge2\) gives \(k=0,1,2,3\).  In increasing order of \(x\), the
only base rows are therefore

\[
 (x,y,z)\in
 \{(3,23,2),(4,17,3),(5,11,4),(6,5,5)\}.
\]

## Human theorem versus finite replay

The human argument above proves the geometric statement \(z\ge2\) on every
target side, proves that the two legs are \(c^6\), and proves that the base
starts and ends with a 30-edge.  It then derives the four base rows by hand.

`n83_boundary_certificate.py` is an exact finite replay of the Diophantine
arithmetic.  In particular, it enumerates all nonnegative representations of
216 and 415 by \(30,11,36\), applies \(z\ge2\), and checks the four surviving
base rows.  Its later chord and coloring computations are separate refinements
and are not used in this boundary lemma.  The script does **not** prove the
one-\(c\)-edge geometric propagation; that is the human lemma above.

There is no undischarged numerical or angle hypothesis inside this boundary
reduction: every item of the specialized lemma has been verified explicitly
for N=83. There is, however, a certification-boundary caveat. The independent
apex-frontier manifest checker records “at least two \(c\)-edges per target
side” as an external hypothesis; it does not machine-check this planar lemma.
Thus the final N=83 exclusion is a computer-assisted proof whose human part is
this lemma and whose machine-checked part begins after the boundary reduction.
No logical gap is presently known in the planar argument above, including in
the presence of T-junctions, but formalizing it in a proof assistant would
remove this remaining human-versus-machine certification boundary.
