# Erdős Problem 634 — N=83 certificate package

Status date: 2026-08-29.

## Result certified by this package

There is no tiling of the triangle with side lengths

\[
(216,216,415)
\]

by 83 congruent copies (reflections allowed, T-junctions allowed) of the
triangle with side lengths

\[
(30,11,36).
\]

This excludes the `N=83` base-β prime candidate considered in the current
work on Erdős Problem 634. It does **not** solve Erdős Problem 634 as a whole,
and this package has not undergone journal peer review or proof-assistant
formalization.

## Proof architecture

The proof has one human geometric reduction and an exact, independently
replayed finite part.

1. `BOUNDARY_REDUCTION_N83.md` proves that every target side contains at
   least two tile edges of length 36. It allows reflections and T-junctions.
   Exact arithmetic then forces each equal side to be `36^6`; the base begins
   and ends with a 30-edge; and the only possible base edge-count rows are
   `(3,23,2)`, `(4,17,3)`, `(5,11,4)`, and `(6,5,5)` in `(30,11,36)` order.
2. `ep634_work/N83_apex_frontier.jsonl.gz` records every possible placement
   along the two forced legs and at the apex: `16 * 16 * 2 = 512` labelled
   states. Each state contains 13 tiles and one residual polygon of budget 70.
3. The frontier checker reconstructs every tile and residual in exact
   arithmetic over `Q(sqrt(119))`, and verifies that reflection partitions the
   512 states into 256 fixed-point-free two-element orbits.
4. `ep634_work/N83_apex_coverage.json` selects one refutation certificate for
   each orbit. The independent certificate checker re-derives every branch,
   polygon operation, area, boundary-support obligation, and terminal prune.
   It does not trust search status files or generator verdicts.

The selected cover contains exactly 256 trees and 3,879 nodes. Its node-count
histogram is:

- 192 trees with 1 node;
- 48 with 2 nodes;
- 4 with 3 nodes;
- 2 each with 26 and 36 nodes;
- 4 with 66 nodes;
- one each with 143, 437, 889, and 1,722 nodes.

## Verification

Requirements: a POSIX-compatible shell in a Linux/GNU-style environment,
`sha256sum`, and Python 3.9 or newer. The Python verification code uses only
the standard library and no floating-point geometry.

From the package root, run:

```sh
./verify_all.sh
```

The decisive lines are:

```text
PASS: exact N=83 boundary certificate
1410 checks, 0 failures
ACCEPT N83_APEX_FRONTIER seeds=512 reflection_orbits=256 sha256=938f0339268a7a3e9d3577730d17bd9620d08cab3fedd80845404cfc2639877c
ACCEPT N83_APEX_COVERAGE certificates=256 nodes=3879 orbits=256/256 double_covered=0 frontier_sha256=938f0339268a7a3e9d3577730d17bd9620d08cab3fedd80845404cfc2639877c
PASS N83_APEX_COVERAGE_FAIL_CLOSED cases=5
ERDOS634_N83_CERTIFICATE_AUDIT=PASSED
```

`SHA256SUMS.txt` covers every payload file other than the checksum list itself.

## Certification boundary

The finite search and coverage are fully replayable from this package. The
planar two-36-edge lemma is supplied as a human proof, not as a theorem in a
proof assistant. Two separate logic audits found no gap, including in
the T-junction cases. This distinction should remain explicit in any public
claim: the result is a computer-assisted proof, not a fully formal proof.

See `PROVENANCE.md` before redistributing the bundle.
