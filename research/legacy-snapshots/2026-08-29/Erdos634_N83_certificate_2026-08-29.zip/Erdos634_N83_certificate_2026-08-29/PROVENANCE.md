# Provenance and redistribution note

## Upstream exact checker

The independent core checker and its specification originated in Jan P.
Harries's public repository:

- repository: `https://github.com/jphme/math-problems.git`;
- base commit: `6a69b6646f67c874d0f8469c83ffebc13289b6c4`;
- upstream author recorded by Git: Jan P. Harries;
- upstream path:
  `progress634/anc/computation/tiling_search/check_refutation.py`;
- upstream checker SHA-256 at that commit:
  `52d74ab383892ce53c10d14d9daa541263589abd8d4b0f7eabf10851ea7fd99c`.

The checker included here is the working-tree version with a small local
`N83R47` instance registration added. Its SHA-256 before package checksum
generation is
`4c6c9c5f07c63c487cce01c984ca3c14319683cfec1e893c7d832280f48cbdbe`.
The dynamic N=83 frontier verifier does not trust that static registration: it
constructs each checked residual itself and temporarily registers it only
after independently validating the frontier manifest.

`CERT_SPEC.md` has the matching five-line `N83R47` description added. Its
upstream SHA-256 is
`ffaa8396c0bb0f83ea64567786e1755c067a9d4c29226a1656840b5412883bc7`,
and the packaged working-tree SHA-256 is
`a82861c4a0e694895df345958a4767ec80317dd3ee0d1672507e745395575c13`.
The included checker mutation suite is unchanged from the cited commit and
has SHA-256
`de71dbba20e7b2156fd12d8e014bbc8d33cc1377836c162939a4f6ccd384e81c`.

No license file was found at the root of the cited upstream commit. This
bundle therefore makes no new license grant for upstream-derived material.
Clarify permission or licensing with the upstream author before public
redistribution.

The upstream project materials disclose extensive AI assistance. This bundle
was also assembled with substantial AI assistance under Denis Paliy's
direction. In this package, “independent checker” means implementation
independence from the search/generator code; it does not assert human-only
authorship or review.

## N=83 generation provenance

The 256 selected proof trees were generated from the exact-search working
tree and then accepted by the separate checker. Generator verdicts and stale
batch status files are not included or trusted.

Relevant generation hashes from the frozen working tree were:

- `searcher2.py`:
  `e0967ce16b355eb5ed90a846e47514d9e04070d18f7f53bedc4d0c55dba73200`;
- `n83_apex_cert_batch.py`:
  `bf8d6e1965f3fab15073040d73096e062f37db7453cbe86b29864bfe55a31539`;
- `n83_apex_frontier_export.py`:
  `139b7de8143bde466e54cd851e00d96d7fdaf8be88140f6cdc7ae79a7709fd39`;
- `make_n83_apex_coverage.py`:
  `f9264383da8b68799c525bf60cef6582d0a31704892a1efa49402705ee6ec353`.

Those generator sources are intentionally not part of this minimal replay
bundle. The package claim depends on the independently checked certificates,
not on reproducing the search order that found them.

## Human geometric input

`BOUNDARY_REDUCTION_N83.md` is an N=83-specialized repair and expansion of the
two-c-edge argument associated with Michael Beeson's Lemma 6
(`lemma:zerolimits2`) in arXiv:1206.2229v3. The note states exactly which
printed hypothesis is replaced and supplies the complete specialized proof.

## Scope

This is a verification bundle for one candidate case. It is not a claim of a
complete solution of Erdős Problem 634, an attribution decision for a future
paper, or evidence of peer review.
