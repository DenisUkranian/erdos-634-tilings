#!/bin/sh
set -eu

PYTHONDONTWRITEBYTECODE=1
export PYTHONDONTWRITEBYTECODE

PACKAGE_ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$PACKAGE_ROOT"

sha256sum -c SHA256SUMS.txt
python3 ep634_work/n83_boundary_certificate.py
python3 math-problems/progress634/anc/computation/tiling_search/tests_check_refutation.py
python3 ep634_work/check_n83_apex_frontier.py \
  ep634_work/N83_apex_frontier.jsonl.gz
python3 ep634_work/check_n83_apex_coverage.py \
  ep634_work/N83_apex_frontier.jsonl.gz \
  ep634_work/N83_apex_coverage.json \
  --require-complete --progress 32
python3 ep634_work/test_n83_apex_coverage_fail_closed.py \
  ep634_work/N83_apex_frontier.jsonl.gz \
  ep634_work/N83_apex_coverage.json

printf '%s\n' 'ERDOS634_N83_CERTIFICATE_AUDIT=PASSED'
