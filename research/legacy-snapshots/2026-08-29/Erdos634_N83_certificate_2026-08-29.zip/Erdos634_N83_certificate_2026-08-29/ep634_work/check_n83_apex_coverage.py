#!/usr/bin/env python3
"""Independently replay a selected cover of the N=83 apex frontier.

The coverage manifest is deliberately small and untrusted.  This program
first reconstructs and checks all 512 frontier states (including the 256
two-element reflection orbits), then replays every listed
``erdos634-refutation-v1`` tree with the independent checker.  A reflection
orbit is covered when either of its two residuals has an accepted tree.

No finder result, batch status file, or generator verdict is trusted here.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import sys
from pathlib import Path


HERE = Path(__file__).resolve().parent
FRONTIER_CHECKER = HERE / "check_n83_apex_frontier.py"
FORMAT = "erdos634-n83-apex-coverage-v1"


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load %s" % path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


K = load_module("n83_apex_coverage_frontier", FRONTIER_CHECKER)


class Reject(Exception):
    pass


def sha256_file(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def require_keys(obj, keys, where):
    if not isinstance(obj, dict):
        raise Reject("%s is not an object" % where)
    if set(obj) != set(keys):
        raise Reject("%s keys are %r, expected %r" %
                     (where, sorted(obj), sorted(keys)))


def read_json(path):
    try:
        with Path(path).open("r", encoding="utf-8") as fh:
            obj = json.load(fh)
    except Exception as exc:
        raise Reject("coverage manifest is not valid JSON: %s" % exc)
    return obj


def safe_relative_path(base, text, where):
    if not isinstance(text, str) or not text:
        raise Reject("%s path is not a nonempty string" % where)
    rel = Path(text)
    if rel.is_absolute() or ".." in rel.parts:
        raise Reject("%s path must be relative and contain no '..'" % where)
    path = (base / rel).resolve()
    try:
        path.relative_to(base.resolve())
    except ValueError:
        raise Reject("%s path escapes the coverage directory" % where)
    return path


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("frontier", type=Path)
    ap.add_argument("coverage", type=Path)
    ap.add_argument("--require-complete", action="store_true")
    ap.add_argument("--manifest-progress", type=int, default=0)
    ap.add_argument("--cert-progress", type=int, default=0)
    ap.add_argument("--progress", type=int, default=32)
    args = ap.parse_args(argv)

    try:
        result = K.verify_manifest(args.frontier, args.manifest_progress)
        if len(result) != 5:
            raise Reject("frontier checker is not reflection-aware")
        _header, residuals, frontier_sha, pairs, _representatives = result

        doc = read_json(args.coverage)
        require_keys(doc, {"format", "frontier_sha256", "certificate_count",
                           "covered_orbit_count", "certificates"}, "coverage")
        if doc["format"] != FORMAT:
            raise Reject("coverage format is %r, expected %r" %
                         (doc["format"], FORMAT))
        if doc["frontier_sha256"] != frontier_sha:
            raise Reject("coverage frontier SHA-256 does not match checked bytes")
        records = doc["certificates"]
        if not isinstance(records, list):
            raise Reject("coverage certificates is not a list")
        if doc["certificate_count"] != len(records):
            raise Reject("coverage certificate_count does not match list length")
        if not isinstance(doc["covered_orbit_count"], int):
            raise Reject("coverage covered_orbit_count is not an integer")

        known = set(residuals)
        seen_seeds = set()
        seen_paths = set()
        accepted = set()
        total_nodes = 0
        base = args.coverage.resolve().parent

        for ordinal, rec in enumerate(records, 1):
            where = "certificate record %d" % ordinal
            require_keys(rec, {"seed", "path", "sha256", "nodes"}, where)
            seed = rec["seed"]
            if seed not in known:
                raise Reject("%s names unknown seed %r" % (where, seed))
            if seed in seen_seeds:
                raise Reject("duplicate certificate seed %s" % seed)
            seen_seeds.add(seed)
            path = safe_relative_path(base, rec["path"], where)
            path_key = str(path)
            if path_key in seen_paths:
                raise Reject("duplicate certificate path %s" % rec["path"])
            seen_paths.add(path_key)
            if not path.is_file():
                raise Reject("%s file does not exist: %s" % (where, rec["path"]))
            if not isinstance(rec["sha256"], str) or len(rec["sha256"]) != 64:
                raise Reject("%s has malformed SHA-256" % where)
            if not isinstance(rec["nodes"], int) or rec["nodes"] <= 0:
                raise Reject("%s has invalid node count" % where)

            nodes, digest = K.register_and_check_certificate(
                seed, residuals[seed], path, args.cert_progress)
            if nodes != rec["nodes"]:
                raise Reject("%s node count %d, expected %d" %
                             (where, nodes, rec["nodes"]))
            if digest != rec["sha256"]:
                raise Reject("%s SHA-256 %s, expected %s" %
                             (where, digest, rec["sha256"]))
            accepted.add(seed)
            total_nodes += nodes
            if args.progress and ordinal % args.progress == 0:
                print("... independently accepted %d/%d certificates" %
                      (ordinal, len(records)), file=sys.stderr, flush=True)

        covered_pairs = []
        missing_pairs = []
        double_covered = 0
        for a, b in pairs:
            count = int(a in accepted) + int(b in accepted)
            if count:
                covered_pairs.append((a, b))
                double_covered += count == 2
            else:
                missing_pairs.append((a, b))

        if doc["covered_orbit_count"] != len(covered_pairs):
            raise Reject("coverage covered_orbit_count=%d, independently found %d" %
                         (doc["covered_orbit_count"], len(covered_pairs)))
        if args.require_complete and missing_pairs:
            raise Reject("coverage is incomplete; missing orbit representatives: %s" %
                         ", ".join(a for a, _b in missing_pairs))

        print("ACCEPT N83_APEX_COVERAGE certificates=%d nodes=%d "
              "orbits=%d/256 double_covered=%d frontier_sha256=%s" %
              (len(records), total_nodes, len(covered_pairs),
               double_covered, frontier_sha))
        if missing_pairs:
            print("MISSING_ORBITS %d" % len(missing_pairs))
            for a, b in missing_pairs:
                print("MISSING %s partner=%s" % (a, b))
        return 0
    except (Reject, K.Reject, K.C.Reject) as exc:
        print("REJECT: %s" % exc)
        return 1
    except Exception as exc:
        print("REJECT: %s: %s" % (type(exc).__name__, exc))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
