#!/usr/bin/env python3
"""Exact finite arithmetic behind the N=83 boundary/color prune.

The tile is (a,b,c)=(30,11,36), the target has equal sides 216 and
base 415.  No floating-point arithmetic is used.
"""

from fractions import Fraction


A, B, C = 30, 11, 36
LEG, BASE = 216, 415
SIDES = (A, B, C)


def walks(length):
    out = []
    for x in range(length // A + 1):
        for y in range(length // B + 1):
            rem = length - x * A - y * B
            if rem >= 0 and rem % C == 0:
                out.append((x, y, rem // C))
    return sorted(out)


def semigroup_values(limit):
    return {
        x * A + y * B + z * C
        for x in range(limit // A + 1)
        for y in range(limit // B + 1)
        for z in range(limit // C + 1)
        if x * A + y * B + z * C <= limit
    }


def chord_solutions(limit_u, limit_v, cos_theta):
    """(u,v,d) with endpoints u,v from the common target corner."""
    su = semigroup_values(limit_u)
    sv = semigroup_values(limit_v)
    return sorted(
        (u, v, d)
        for u in su
        for v in sv
        for d in SIDES
        if u or v
        if u * u + v * v - 2 * u * v * cos_theta == d * d
    )


def reps(length):
    return [w for w in walks(length)]


leg_walks = walks(LEG)
base_walks = walks(BASE)
assert leg_walks == [(0, 0, 6), (5, 6, 0), (6, 0, 1)]
assert base_walks == [
    (0, 5, 10),
    (1, 35, 0),
    (2, 29, 1),
    (3, 23, 2),
    (4, 17, 3),
    (5, 11, 4),
    (6, 5, 5),
    (12, 5, 0),
]

# The repaired two-c-edge lemma forces z>=2 on every target side.
assert [w for w in leg_walks if w[2] >= 2] == [(0, 0, 6)]
base_two_c = [w for w in base_walks if w[2] >= 2]
assert base_two_c == [
    (0, 5, 10),
    (3, 23, 2),
    (4, 17, 3),
    (5, 11, 4),
    (6, 5, 5),
]

# Each base corner is one beta-tile.  Its leg edge is now c, hence its
# base edge is a; the base must contain an a at both ends.
base_corner_compatible = [w for w in base_two_c if w[0] >= 2]
assert base_corner_compatible == [
    (3, 23, 2),
    (4, 17, 3),
    (5, 11, 4),
    (6, 5, 5),
]

# Exact cross-side chord census.  At a base corner cos(beta)=415/432.
# At the apex the cosine follows directly from sides (216,216,415).
cos_beta = Fraction(415, 432)
cos_apex = Fraction(2 * LEG * LEG - BASE * BASE, 2 * LEG * LEG)
assert cos_apex == Fraction(-78913, 93312)
base_corner_chords = chord_solutions(BASE, LEG, cos_beta)
apex_chords = chord_solutions(LEG, LEG, cos_apex)

trivial = {
    (0, 11, 11), (0, 30, 30), (0, 36, 36),
    (11, 0, 11), (30, 0, 30), (36, 0, 36),
    # The beta-corner tile itself, with a and c on the target sides.
    (30, 36, 11), (36, 30, 11),
}
assert set(base_corner_chords) - trivial == {(104, 108, 30), (108, 104, 30)}
assert set(apex_chords) == {
    (0, 11, 11), (0, 30, 30), (0, 36, 36),
    (11, 0, 11), (30, 0, 30), (36, 0, 36),
}

# Once a leg is c^6, only multiples of 36 occur as its boundary vertices.
# Thus only (base distance, leg distance)=(104,108) remains.  Its base
# prefix consumes exactly a^2 b^4 and its leg prefix is c^3.
assert reps(104) == [(2, 4, 0)]
assert reps(108) == [(0, 0, 3)]

# Coloring count.  N=83 and M=11 give 47 black and 36 white tiles.
# Every boundary-edge tile is black.  At a Q=(A,B,G) boundary vertex the
# unique vertex-only tile is white; at a P=(3A,2B) vertex the three such
# tiles have colors W,B,W.  The middle apex tile is white.  Hence with E
# boundary edge occurrences and p P-vertices there are E-2+p white
# boundary incidences.  For a deliberately weak lower bound we allow a
# saving of two incidences at the base corners, without asserting that any
# particular partner tiles are forced or even simultaneously realizable.
# Apart from this allowance and the exceptional chord above, a white tile can
# supply only one boundary incidence.  Each exceptional bridge uses a^2 b^4, so its
# number h is bounded as below.  Taking p=0 gives the weakest lower bound.
WHITE = 36
survivors = []
rows = []
for x, y, z in base_corner_compatible:
    edge_occurrences = x + y + z + 2 * 6
    exceptional_bridge_cap = min(2, x // 2, y // 4)
    corner_partner_savings_cap = 2
    white_lower = edge_occurrences - 2 - corner_partner_savings_cap - exceptional_bridge_cap
    max_p = WHITE - white_lower
    rows.append(((x, y, z), edge_occurrences, exceptional_bridge_cap, white_lower, max_p))
    if white_lower <= WHITE:
        survivors.append((x, y, z))

assert rows == [
    ((3, 23, 2), 40, 1, 35, 1),
    ((4, 17, 3), 36, 2, 30, 6),
    ((5, 11, 4), 32, 2, 26, 10),
    ((6, 5, 5), 28, 1, 23, 13),
]
assert survivors == base_corner_compatible

print("PASS: exact N=83 boundary certificate")
print("  legs:", (0, 0, 6), "on each side")
print("  exceptional non-corner chord: base 104, leg 108, tile side 30")
print("  base rows: (counts, E, bridge cap, white lower bound, max #P)")
for row in rows:
    print("   ", row)
print("  no base count vector is excluded by coloring alone:", survivors)
