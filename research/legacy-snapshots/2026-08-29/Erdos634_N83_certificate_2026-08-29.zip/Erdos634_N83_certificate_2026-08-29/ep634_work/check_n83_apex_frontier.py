#!/usr/bin/env python3
"""Independent exact checker for the N=83 apex-frontier manifest.

The checker never imports the exporter or searcher2.py.  It imports only the
already independent CERT_SPEC checker for its fresh Q(sqrt(D)) arithmetic,
polygon intersection, triangulation and boundary-support implementation.

It proves, conditional on the separately proved >=2 c-edges-per-side lemma,
that the manifest is exactly the 16 x 16 x 2 full-leg/apex frontier.  For every
seed it independently reconstructs all 13 tiles, verifies their exact partition
of the N=83 target, and verifies that the sole residual has tile budget 70.

Optional ``--cert SEED=FILE`` arguments teach the independent v1 checker the
corresponding *already validated* residual target and then check that subtree
certificate without modifying check_refutation.py.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import importlib.util
import json
import sys
from fractions import Fraction as F
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
CHECKER = ROOT / "math-problems/progress634/anc/computation/tiling_search/check_refutation.py"
FORMAT = "erdos634-n83-apex-frontier-v1"


def load_independent_checker():
    spec = importlib.util.spec_from_file_location("n83_frontier_independent_core", CHECKER)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load %s" % CHECKER)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


C = load_independent_checker()


class Reject(Exception):
    pass


HEADER_KEYS = {
    "type", "format", "instance", "D", "tile_sides", "target", "hypothesis",
    "leg_word_count", "seed_count", "placed_tiles_per_seed", "residual_budget",
}
SEED_KEYS = {"type", "id", "right", "left", "middle", "residual",
             "residual_budgets"}
LEG_KEYS = {"word", "tiles"}
WORD_EDGE_KEYS = {"length", "from", "to"}
MIDDLE_KEYS = {"orientation", "tile"}


def require_keys(obj, keys, where):
    if not isinstance(obj, dict):
        raise Reject("%s is not an object" % where)
    if set(obj) != keys:
        raise Reject("%s keys are %r, expected %r" %
                     (where, sorted(obj), sorted(keys)))


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def parse_normal_point(obj, where):
    if not (isinstance(obj, list) and len(obj) == 2
            and all(isinstance(x, list) and len(x) == 2 for x in obj)):
        raise Reject("%s is not a CERT_SPEC point" % where)
    x, x_surd = C.parse_rational(obj[0][0]), C.parse_rational(obj[0][1])
    y_rat, y_surd = C.parse_rational(obj[1][0]), C.parse_rational(obj[1][1])
    if x_surd != 0 or y_rat != 0:
        raise Reject("%s is outside exporter normal form (x, w*sqrt(D))" % where)
    return (C.frat(x), C.fsurd(y_surd))


def parse_normal_poly(obj, where):
    if not isinstance(obj, list):
        raise Reject("%s is not a polygon list" % where)
    return [parse_normal_point(p, "%s point %d" % (where, i))
            for i, p in enumerate(obj)]


def point_coeff(p):
    if p[0][1] != 0 or p[1][0] != 0:
        raise Reject("internal: point outside normal coefficient plane")
    return (F(p[0][0], p[0][2]), F(p[1][1], p[1][2]))


def point_key(p):
    return point_coeff(p)


def same_point(p, q):
    return C.peq(p, q)


def same_poly(p, q):
    return len(p) == len(q) and all(same_point(a, b) for a, b in zip(p, q))


def normalize_cycle(poly):
    poly = list(poly)
    sign = C.fsign(C.area2(poly))
    if sign == 0:
        raise Reject("degenerate polygon during normalization")
    if sign < 0:
        poly.reverse()
    k = min(range(len(poly)), key=lambda i: point_key(poly[i]))
    return poly[k:] + poly[:k]


def add_point_vec(p, v):
    return C.fadd(p[0], v[0]), C.fadd(p[1], v[1])


def sub_points(p, q):
    return C.fsub(p[0], q[0]), C.fsub(p[1], q[1])


def scale_vec(v, scalar):
    k = C.frat(scalar)
    return C.fmul(v[0], k), C.fmul(v[1], k)


def dot(u, v):
    return C.fadd(C.fmul(u[0], v[0]), C.fmul(u[1], v[1]))


def cross(u, v):
    return C.fsub(C.fmul(u[0], v[1]), C.fmul(u[1], v[0]))


def norm2(v):
    return dot(v, v)


def distance2(p, q):
    return C.fred(norm2(sub_points(p, q)))


def ratio_fraction(u, v, where):
    r = C.fred(C.fdiv(u, v))
    if not C.f_is_rational(r):
        raise Reject("%s is not rational" % where)
    return C.f_to_fraction(r)


def expected_words():
    # A c-edge has endpoint angles A,B.  The base endpoint is B and the apex
    # endpoint is A, so the first and last orientations are BA; each of the four
    # internal edges independently has AB or BA.  (No G+G straight-junction
    # obstruction can occur because c has no G endpoint.)
    words = []
    for mask in range(16):
        w = [("B", "A")]
        for j in range(4):
            w.append(("B", "A") if (mask >> j) & 1 else ("A", "B"))
        w.append(("B", "A"))
        words.append(tuple(w))
    return sorted(words, key=word_code)


def word_code(word):
    return "_".join(a + b for a, b in word)


def parse_word(obj, where):
    if not isinstance(obj, list) or len(obj) != 6:
        raise Reject("%s must contain six c-edge records" % where)
    out = []
    for i, edge in enumerate(obj):
        require_keys(edge, WORD_EDGE_KEYS, "%s edge %d" % (where, i))
        if edge["length"] != "36":
            raise Reject("%s edge %d is not c=36" % (where, i))
        a, b = edge["from"], edge["to"]
        if (a, b) not in (("A", "B"), ("B", "A")):
            raise Reject("%s edge %d has invalid c-edge angle orientation" % (where, i))
        out.append((a, b))
    return tuple(out)


def leg_tile(tile, U, V, start_angle, turn):
    """Third vertex of a boundary c-edge tile, reconstructed independently."""
    angle_index = {"A": 0, "B": 1}[start_angle]
    inward_side = {"A": F(11), "B": F(30)}[start_angle]
    u = scale_vec(sub_points(V, U), F(1, 36))
    X = add_point_vec(U, scale_vec(tile.rot(angle_index, turn, u), inward_side))
    return normalize_cycle((U, V, X)), X


def reconstruct_leg(tile, base, apex, word, turn):
    points = [add_point_vec(base, scale_vec(sub_points(apex, base), F(k, 6)))
              for k in range(7)]
    tiles = []
    third = None
    for k, (start, end) in enumerate(word):
        if start == end:
            raise Reject("internal: invalid c orientation")
        tri, third = leg_tile(tile, points[k], points[k + 1], start, turn)
        # Independently confirm the opposite endpoint gets the recorded angle:
        # on a c-edge the labels are the complementary A,B pair.
        if end != ("B" if start == "A" else "A"):
            raise Reject("internal: endpoint angle mismatch")
        tiles.append(tri)
    return tiles, third


def reconstruct_middle(apex, left_seam, right_seam, orientation):
    u_left = scale_vec(sub_points(left_seam, apex), F(1, 11))
    u_right = scale_vec(sub_points(right_seam, apex), F(1, 11))
    if orientation == "bc":
        L = left_seam
        R = add_point_vec(apex, scale_vec(u_right, 36))
    elif orientation == "cb":
        L = add_point_vec(apex, scale_vec(u_left, 36))
        R = right_seam
    else:
        raise Reject("middle orientation must be bc or cb")
    return normalize_cycle((apex, L, R))


def parse_tile_list(obj, where):
    if not isinstance(obj, list):
        raise Reject("%s is not a list" % where)
    out = []
    for i, raw in enumerate(obj):
        tri = parse_normal_poly(raw, "%s tile %d" % (where, i))
        if len(tri) != 3:
            raise Reject("%s tile %d does not have three vertices" % (where, i))
        C.check_polygon(tri, "%s tile %d" % (where, i))
        if not same_poly(tri, normalize_cycle(tri)):
            raise Reject("%s tile %d is not in canonical CCW cycle order" % (where, i))
        out.append(tri)
    return out


def confirm_tile_shape(tri, where):
    lens2 = []
    for i in range(3):
        d2 = distance2(tri[i], tri[(i + 1) % 3])
        if not C.f_is_rational(d2):
            raise Reject("%s has a non-rational squared side" % where)
        lens2.append(C.f_to_fraction(d2))
    if sorted(lens2) != [F(121), F(900), F(1296)]:
        raise Reject("%s squared sides are %r, not 11^2,30^2,36^2" %
                     (where, sorted(lens2)))


def verify_angle_and_inventory(tile, target):
    # The min-c hypothesis plus exact side length arithmetic forces c^6.
    solutions = []
    for na in range(216 // 30 + 1):
        for nb in range(216 // 11 + 1):
            for nc in range(216 // 36 + 1):
                if 30 * na + 11 * nb + 36 * nc == 216 and nc >= 2:
                    solutions.append((na, nb, nc))
    if solutions != [(0, 0, 6)]:
        raise Reject("internal inventory audit failed: %r" % solutions)

    # Independently identify the apex corner figure.  First verify the target
    # apex angle is 3A using exact unit vectors.
    left, right, apex = target
    for name, base in (("left", left), ("right", right)):
        if not C.feq(distance2(base, apex), C.frat(216 * 216)):
            raise Reject("target %s leg does not have exact length 216" % name)
    u = scale_vec(sub_points(left, apex), F(1, 216))
    v = scale_vec(sub_points(right, apex), F(1, 216))
    target_cos, target_sin = C.fred(dot(u, v)), C.fred(cross(u, v))
    c3a, s3a = C.rot_compose(tile, (3, 0, 0))
    if not (C.feq(target_cos, c3a) and C.feq(target_sin, s3a)):
        raise Reject("target apex angle is not exactly 3A")

    # B is the smallest tile angle (largest cosine), and 12B has crossed pi;
    # hence a convex corner contains at most eleven tile angles.  Enumerate all
    # nonempty multisets of that size and require 3A to be the sole match.
    if not (C.fsign(C.fsub(tile.cos[1], tile.cos[0])) > 0
            and C.fsign(C.fsub(tile.cos[0], tile.cos[2])) > 0):
        raise Reject("tile-angle ordering B < A < G failed")
    cb, sb = C.F1, C.F0
    crossed_at = None
    for k in range(1, 13):
        cb, sb = (
            C.fsub(C.fmul(cb, tile.cos[1]), C.fmul(sb, tile.sin[1])),
            C.fadd(C.fmul(sb, tile.cos[1]), C.fmul(cb, tile.sin[1])),
        )
        cb, sb = C.fred(cb), C.fred(sb)
        if C.fsign(sb) <= 0 and crossed_at is None:
            crossed_at = k
    if crossed_at != 12:
        raise Reject("exact bound 11B < pi < 12B failed (crossed at %r)" % crossed_at)

    matches = []
    for na in range(12):
        for nb in range(12 - na):
            for ng in range(12 - na - nb):
                if na + nb + ng == 0:
                    continue
                co, si = C.F1, C.F0
                below = True
                for angle_index, count in enumerate((na, nb, ng)):
                    for _ in range(count):
                        co, si = (
                            C.fsub(C.fmul(co, tile.cos[angle_index]),
                                   C.fmul(si, tile.sin[angle_index])),
                            C.fadd(C.fmul(si, tile.cos[angle_index]),
                                   C.fmul(co, tile.sin[angle_index])),
                        )
                        co, si = C.fred(co), C.fred(si)
                        if C.fsign(si) <= 0:
                            below = False
                            break
                    if not below:
                        break
                if below and C.feq(co, target_cos) and C.feq(si, target_sin):
                    matches.append((na, nb, ng))
    if matches != [(3, 0, 0)]:
        raise Reject("apex angle multisets are %r, expected only (3,0,0)" % matches)


def verify_seed(raw, target, target_tris, tile, words, seen_ids):
    require_keys(raw, SEED_KEYS, "seed")
    if raw["type"] != "seed" or not isinstance(raw["id"], str):
        raise Reject("malformed seed type/id")
    sid = raw["id"]
    if sid in seen_ids:
        raise Reject("duplicate seed id %s" % sid)
    seen_ids.add(sid)
    require_keys(raw["right"], LEG_KEYS, "%s right" % sid)
    require_keys(raw["left"], LEG_KEYS, "%s left" % sid)
    require_keys(raw["middle"], MIDDLE_KEYS, "%s middle" % sid)
    rw = parse_word(raw["right"]["word"], "%s right word" % sid)
    lw = parse_word(raw["left"]["word"], "%s left word" % sid)
    if rw not in words or lw not in words:
        raise Reject("%s contains a word outside the exact 16-word DFA" % sid)
    mcode = raw["middle"]["orientation"]
    want_id = "AF_R%s_L%s_M%s" % (
        word_code(rw).replace("_", ""), word_code(lw).replace("_", ""), mcode)
    if sid != want_id:
        raise Reject("seed id %s does not match its words/orientation (%s)" % (sid, want_id))

    left, right, apex = target
    want_right, right_seam = reconstruct_leg(tile, right, apex, rw, +1)
    want_left, left_seam = reconstruct_leg(tile, left, apex, lw, -1)
    want_middle = reconstruct_middle(apex, left_seam, right_seam, mcode)
    got_right = parse_tile_list(raw["right"]["tiles"], "%s right" % sid)
    got_left = parse_tile_list(raw["left"]["tiles"], "%s left" % sid)
    got_middle = parse_normal_poly(raw["middle"]["tile"], "%s middle tile" % sid)
    C.check_polygon(got_middle, "%s middle tile" % sid)
    if not same_poly(got_middle, normalize_cycle(got_middle)):
        raise Reject("%s middle tile is not in canonical CCW cycle order" % sid)
    if len(got_right) != 6 or len(got_left) != 6:
        raise Reject("%s does not contain six tiles on each leg" % sid)
    for side, got, want in (("right", got_right, want_right),
                            ("left", got_left, want_left)):
        for i, (g, w) in enumerate(zip(got, want)):
            if not same_poly(g, w):
                raise Reject("%s %s tile %d differs from independent reconstruction" %
                             (sid, side, i))
    if not same_poly(got_middle, want_middle):
        raise Reject("%s middle tile differs from independent reconstruction" % sid)

    all_tiles = got_right + got_left + [got_middle]
    for i, tri in enumerate(all_tiles):
        confirm_tile_shape(tri, "%s tile %d" % (sid, i))
        if not C.contained_tri(tuple(tri), target, target_tris):
            raise Reject("%s tile %d is not contained in the target" % (sid, i))
    for i in range(len(all_tiles)):
        for j in range(i + 1, len(all_tiles)):
            overlap = C.area2_tri_cap_tri(tuple(all_tiles[i]), tuple(all_tiles[j]))
            if not C.fiszero(overlap):
                raise Reject("%s tiles %d and %d overlap with positive area %s" %
                             (sid, i, j, C.fstr(overlap)))

    if not isinstance(raw["residual"], list) or len(raw["residual"]) != 1:
        raise Reject("%s must have exactly one residual component" % sid)
    residual = parse_normal_poly(raw["residual"][0], "%s residual" % sid)
    residual_area = C.check_polygon(residual, "%s residual" % sid)
    if not same_poly(residual, normalize_cycle(residual)):
        raise Reject("%s residual is not in canonical CCW cycle order" % sid)
    residual_tris = C.triangulate(residual)
    if not C.contained_poly(residual_tris, residual_area, target, target_tris):
        raise Reject("%s residual is not contained in target" % sid)

    for i, tri in enumerate(all_tiles):
        overlap = C.area2_tri_cap_tris(tuple(tri), residual_tris)
        if not C.fiszero(overlap):
            raise Reject("%s tile %d overlaps residual with positive area %s" %
                         (sid, i, C.fstr(overlap)))
    total = residual_area
    for tri in all_tiles:
        total = C.fadd(total, C.area2(tri))
    if not C.feq(C.fred(total), C.area2(target)):
        raise Reject("%s tiles plus residual do not have target area" % sid)

    support = [(target[i], target[(i + 1) % len(target)])
               for i in range(len(target))]
    for tri in all_tiles:
        support.extend((tri[i], tri[(i + 1) % 3]) for i in range(3))
    unsupported = C.boundary_support(residual, support)
    if unsupported is not None:
        raise Reject("%s residual edge %d is not on target/tile boundary support" %
                     (sid, unsupported))

    budget = ratio_fraction(residual_area, tile.area2, "%s residual budget" % sid)
    if budget != 70 or raw["residual_budgets"] != ["70"]:
        raise Reject("%s residual budget is %s / record %r, expected 70" %
                     (sid, budget, raw["residual_budgets"]))
    return {
        "right_word": rw,
        "left_word": lw,
        "middle_orientation": mcode,
        "right_tiles": got_right,
        "left_tiles": got_left,
        "middle_tile": got_middle,
        "residual": residual,
    }


def reflect_point_n83(p):
    return C.fsub(C.frat(415), p[0]), p[1]


def reflect_poly_n83(poly):
    return normalize_cycle([reflect_point_n83(p) for p in poly])


def reflected_seed_id(state):
    other_middle = {"bc": "cb", "cb": "bc"}[state["middle_orientation"]]
    return "AF_R%s_L%s_M%s" % (
        word_code(state["left_word"]).replace("_", ""),
        word_code(state["right_word"]).replace("_", ""), other_middle)


def verify_reflection_orbits(states):
    """Check the exact x -> 415-x involution on every recorded seed.

    Reflection swaps the two base-to-apex leg words and their six-tile lists,
    flips bc <-> cb for the middle tile, and reflects the residual.  The middle
    orientation flip makes fixed points impossible, so the 512 seeds must form
    exactly 256 two-element orbits.
    """
    partner = {}
    for seed_id, state in states.items():
        mate_id = reflected_seed_id(state)
        mate = states.get(mate_id)
        if mate is None:
            raise Reject("reflection partner %s of %s is missing" % (mate_id, seed_id))
        if reflected_seed_id(mate) != seed_id:
            raise Reject("reflection id map is not an involution at %s" % seed_id)
        if mate_id == seed_id:
            raise Reject("reflection unexpectedly fixes seed %s" % seed_id)
        if mate["right_word"] != state["left_word"]:
            raise Reject("reflection %s -> %s does not swap left word to right" %
                         (seed_id, mate_id))
        if mate["left_word"] != state["right_word"]:
            raise Reject("reflection %s -> %s does not swap right word to left" %
                         (seed_id, mate_id))
        if mate["middle_orientation"] == state["middle_orientation"]:
            raise Reject("reflection %s -> %s does not flip middle orientation" %
                         (seed_id, mate_id))
        for i, tri in enumerate(state["right_tiles"]):
            if not same_poly(reflect_poly_n83(tri), mate["left_tiles"][i]):
                raise Reject("reflection %s right tile %d != %s left tile" %
                             (seed_id, i, mate_id))
        for i, tri in enumerate(state["left_tiles"]):
            if not same_poly(reflect_poly_n83(tri), mate["right_tiles"][i]):
                raise Reject("reflection %s left tile %d != %s right tile" %
                             (seed_id, i, mate_id))
        if not same_poly(reflect_poly_n83(state["middle_tile"]),
                         mate["middle_tile"]):
            raise Reject("reflection %s middle tile != %s middle tile" %
                         (seed_id, mate_id))
        if not same_poly(reflect_poly_n83(state["residual"]), mate["residual"]):
            raise Reject("reflection %s residual != %s residual" %
                         (seed_id, mate_id))
        partner[seed_id] = mate_id

    pairs = sorted((min(a, b), max(a, b)) for a, b in partner.items() if a < b)
    if len(pairs) != 256 or len({x for pair in pairs for x in pair}) != 512:
        raise Reject("reflection has %d two-orbits, expected 256" % len(pairs))
    representatives = [a for a, _b in pairs]
    if representatives != sorted(representatives) or len(set(representatives)) != 256:
        raise Reject("reflection representatives are not 256 sorted unique ids")
    return pairs, representatives


def verify_manifest(path: Path, progress=0):
    digest = sha256_file(path)
    C.set_field(119)
    tile = C.Tile([F(30), F(11), F(36)])
    relation = C.rot_compose(tile, (3, 2, 0))
    if not (C.feq(relation[0], C.frat(-1)) and C.fiszero(relation[1])):
        raise Reject("tile does not satisfy 3A+2B=pi")
    target = [
        (C.frat(0), C.frat(0)),
        (C.frat(415), C.frat(0)),
        (C.frat(F(415, 2)), C.fsurd(F(11, 2))),
    ]
    target_area = C.check_polygon(target, "independently constructed N83 target")
    if ratio_fraction(target_area, tile.area2, "target budget") != 83:
        raise Reject("independent target budget is not 83")
    target_tris = [tuple(target)]
    words = expected_words()
    verify_angle_and_inventory(tile, target)

    states = {}
    seen_ids = set()
    with gzip.open(path, "rt", encoding="utf-8") as fh:
        first = fh.readline()
        if not first:
            raise Reject("manifest is empty")
        try:
            header = json.loads(first)
        except Exception as exc:
            raise Reject("invalid header JSON: %s" % exc)
        require_keys(header, HEADER_KEYS, "header")
        fixed = {
            "type": "header", "format": FORMAT, "instance": "N83-base-beta",
            "D": 119, "tile_sides": ["30", "11", "36"],
            "hypothesis": {"lemma": "each target side has at least two c-edges",
                           "leg_length": "216", "forced_leg_inventory": {"c": 6}},
            "leg_word_count": 16, "seed_count": 512,
            "placed_tiles_per_seed": 13, "residual_budget": 70,
        }
        for key, value in fixed.items():
            if header[key] != value:
                raise Reject("header %s=%r, expected %r" % (key, header[key], value))
        got_target = parse_normal_poly(header["target"], "header target")
        if not same_poly(got_target, target):
            raise Reject("header target differs from independent N83 construction")

        for line_no, line in enumerate(fh, 2):
            if not line.strip():
                raise Reject("blank manifest line %d" % line_no)
            try:
                raw = json.loads(line)
            except Exception as exc:
                raise Reject("invalid JSON at line %d: %s" % (line_no, exc))
            state = verify_seed(raw, target, target_tris, tile, words, seen_ids)
            states[raw["id"]] = state
            if progress and len(seen_ids) % progress == 0:
                print("... verified %d/512 seeds" % len(seen_ids), file=sys.stderr)

    expected_ids = {
        "AF_R%s_L%s_M%s" % (word_code(rw).replace("_", ""),
                              word_code(lw).replace("_", ""), middle)
        for rw in words for lw in words for middle in ("bc", "cb")
    }
    if seen_ids != expected_ids:
        missing = sorted(expected_ids - seen_ids)
        extra = sorted(seen_ids - expected_ids)
        raise Reject("frontier id set mismatch: missing=%r extra=%r" %
                     (missing[:3], extra[:3]))
    reflection_pairs, representatives = verify_reflection_orbits(states)
    residuals = {seed_id: state["residual"] for seed_id, state in states.items()}
    return header, residuals, digest, reflection_pairs, representatives


def register_and_check_certificate(seed_id, residual, cert_path: Path, progress=0):
    """Use the existing independent v1 checker on a manifest-validated target."""
    # The manifest is in the original N83 coordinates.  CERT_SPEC requires
    # vertex 0 at the origin; translate by that vertex exactly.  This isometry
    # preserves tileability and is independently recomputed here.
    off = residual[0]
    residual = [(C.fsub(p[0], off[0]), C.fsub(p[1], off[1]))
                for p in residual]

    def builder(tile_sides):
        if tuple(tile_sides) != (F(30), F(11), F(36)):
            raise C.Reject("dynamic N83 frontier instance tile must be (30,11,36)")
        tile = C.Tile(tile_sides)
        co, si = C.rot_compose(tile, (3, 2, 0))
        if not (C.feq(co, C.frat(-1)) and C.fiszero(si)):
            raise C.Reject("dynamic N83 frontier tile fails 3A+2B=pi")
        return tile, residual, 70

    old = C.INSTANCES.get(seed_id)
    C.INSTANCES[seed_id] = (119, builder, False)
    try:
        instance, nodes, digest = C.check_certificate(
            str(cert_path), allow_test_instance=False, progress=progress)
    finally:
        if old is None:
            del C.INSTANCES[seed_id]
        else:
            C.INSTANCES[seed_id] = old
    if instance != seed_id:
        raise Reject("certificate instance %s != requested seed %s" % (instance, seed_id))
    return nodes, digest


def parse_cert_arg(arg):
    if "=" not in arg:
        raise argparse.ArgumentTypeError("certificate must be SEED_ID=PATH")
    seed, path = arg.split("=", 1)
    if not seed or not path:
        raise argparse.ArgumentTypeError("certificate must be SEED_ID=PATH")
    return seed, Path(path)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("manifest", type=Path)
    ap.add_argument("--progress", type=int, default=0,
                    help="report every N manifest seeds")
    ap.add_argument("--cert", action="append", default=[], type=parse_cert_arg,
                    metavar="SEED_ID=PATH",
                    help="also independently check a v1 subtree certificate")
    ap.add_argument("--cert-progress", type=int, default=0)
    ap.add_argument("--list-representatives", action="store_true",
                    help="print the 256 lexicographically minimal reflection representatives")
    args = ap.parse_args(argv)
    try:
        _header, residuals, digest, pairs, representatives = verify_manifest(
            args.manifest, args.progress)
        print("ACCEPT N83_APEX_FRONTIER seeds=512 reflection_orbits=256 sha256=%s" %
              digest)
        if args.list_representatives:
            mate = dict(pairs)
            for representative in representatives:
                print("REPRESENTATIVE %s partner=%s" %
                      (representative, mate[representative]))
        used = set()
        for seed_id, cert_path in args.cert:
            if seed_id in used:
                raise Reject("duplicate --cert seed %s" % seed_id)
            used.add(seed_id)
            if seed_id not in residuals:
                raise Reject("--cert names unknown seed %s" % seed_id)
            nodes, cert_digest = register_and_check_certificate(
                seed_id, residuals[seed_id], cert_path, args.cert_progress)
            print("ACCEPT SUBTREE %s nodes=%d sha256=%s" %
                  (seed_id, nodes, cert_digest))
    except (Reject, C.Reject) as exc:
        print("REJECT: %s" % exc)
        return 1
    except Exception as exc:
        print("REJECT: %s: %s" % (type(exc).__name__, exc))
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
