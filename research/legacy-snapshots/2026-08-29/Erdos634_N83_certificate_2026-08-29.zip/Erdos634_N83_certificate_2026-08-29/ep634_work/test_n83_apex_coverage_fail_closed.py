#!/usr/bin/env python3
"""Negative tests for ``check_n83_apex_coverage.py``.

Each mutation must be rejected.  Temporary coverage files are created beside
the canonical manifest so its relative certificate paths retain their normal
meaning; all temporary files are removed on exit.
"""

from __future__ import annotations

import argparse
import contextlib
import copy
import importlib.util
import io
import json
import os
import tempfile
from pathlib import Path


HERE = Path(__file__).resolve().parent
CHECKER = HERE / "check_n83_apex_coverage.py"


def load_checker():
    spec = importlib.util.spec_from_file_location("n83_coverage_negative_checker", CHECKER)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load %s" % CHECKER)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


V = load_checker()


def run_mutation(frontier, canonical, doc, name, mutate):
    changed = copy.deepcopy(doc)
    mutate(changed)
    fd, raw_path = tempfile.mkstemp(
        prefix=".n83-coverage-negative-", suffix=".json", dir=canonical.parent)
    path = Path(raw_path)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(changed, fh, sort_keys=True)
            fh.write("\n")
        capture = io.StringIO()
        with contextlib.redirect_stdout(capture), contextlib.redirect_stderr(capture):
            rc = V.main([str(frontier), str(path), "--require-complete",
                         "--progress", "0"])
        output = capture.getvalue().strip()
        if rc == 0 or not output.startswith("REJECT:"):
            raise AssertionError("%s did not fail closed: rc=%r output=%r" %
                                 (name, rc, output[-500:]))
        print("PASS reject %s" % name)
    finally:
        path.unlink(missing_ok=True)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("frontier", type=Path)
    ap.add_argument("coverage", type=Path)
    args = ap.parse_args(argv)
    canonical = args.coverage.resolve()
    with canonical.open("r", encoding="utf-8") as fh:
        doc = json.load(fh)

    cases = [
        ("wrong-frontier-hash",
         lambda d: d.__setitem__("frontier_sha256", "0" * 64)),
        ("wrong-certificate-count",
         lambda d: d.__setitem__("certificate_count", d["certificate_count"] + 1)),
        ("path-traversal",
         lambda d: d["certificates"][0].__setitem__("path", "../escape.jsonl.gz")),
        ("wrong-node-count",
         lambda d: d["certificates"][0].__setitem__(
             "nodes", d["certificates"][0]["nodes"] + 1)),
        ("duplicate-seed",
         lambda d: (d["certificates"].insert(1, copy.deepcopy(d["certificates"][0])),
                    d.__setitem__("certificate_count", d["certificate_count"] + 1))),
    ]
    for name, mutate in cases:
        run_mutation(args.frontier.resolve(), canonical, doc, name, mutate)
    print("PASS N83_APEX_COVERAGE_FAIL_CLOSED cases=%d" % len(cases))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
