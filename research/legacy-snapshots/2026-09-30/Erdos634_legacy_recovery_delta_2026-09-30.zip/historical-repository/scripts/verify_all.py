#!/usr/bin/env python3
"""Complete finite replay, including the September 30 research packages.

Copied research packages are replayed in temporary directories. Frozen reports
are evidence, not a replacement for fresh verification. No network is used.
"""
from __future__ import annotations
import argparse, hashlib, json, os, shutil, subprocess, sys, tempfile, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def require(ok: bool, why: str) -> None:
    if not ok: raise ValueError(why)

def execute(command: list[str], cwd: Path, log: Path) -> None:
    log.parent.mkdir(parents=True, exist_ok=True)
    with log.open('w', encoding='utf-8') as stream:
        try:
            proc = subprocess.run(command, cwd=cwd, stdout=stream, stderr=subprocess.STDOUT, timeout=1800)
        except subprocess.TimeoutExpired as exc:
            raise RuntimeError(f'INCOMPLETE: time limit; see {log}') from exc
    if proc.returncode:
        raise RuntimeError(f'Check failed (exit {proc.returncode}); see {log}')

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--jobs', type=int, choices=range(1,5), default=2)
    ap.add_argument('--output', type=Path, default=ROOT/'audit-output')
    args = ap.parse_args()
    require(__debug__ and not os.environ.get('PYTHONOPTIMIZE'), 'Use normal Python, without -O, -OO or PYTHONOPTIMIZE.')
    out = args.output.resolve();out.mkdir(parents=True, exist_ok=True)
    start = time.monotonic()
    execute([sys.executable, str(ROOT/'scripts/audit_repository.py'), '--report', str(out/'repository.json')], ROOT, out/'structure.log')
    print('STRUCTURAL_AUDIT=PASS', flush=True)
    # This checks the frozen root manifest before executing any mathematical suite.
    execute([sys.executable, str(ROOT/'scripts/reproduce.py')], ROOT, out/'legacy.log')
    legacy = json.loads((ROOT/'verification/replay.json').read_text())
    require(legacy.get('status') == 'PASS', 'Legacy replay did not pass')
    shutil.copy2(ROOT/'verification/replay.json', out/'legacy.json')
    print('LEGACY_SUITE=PASS', flush=True)
    with tempfile.TemporaryDirectory(prefix='erdos634-verify-') as tmp:
        work = Path(tmp)
        for name in ['n105', 'spectra', 'c-relations', 'uniform-reduction']:
            shutil.copytree(ROOT/'research'/name, work/name, ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        n = work/'n105'
        execute([sys.executable, 'verify_all.py', '--jobs', str(args.jobs)], n, out/'n105.log')
        nr = json.loads((n/'VERIFIED_RESULTS.json').read_text())
        expected = {'f1_8_7_13':120, 'eq_5_19_21':15, 'eq_7_13_15':1788, 'f1_5_16_19':120}
        require(nr.get('result') == 'ALL_PACKAGED_CHECKS_PASSED', 'N105 check did not pass')
        require({r['case']:r['certified_roots'] for r in nr['cases']} == expected, 'N105 root coverage mismatch')
        require(all(r['complete_fixed_target_exclusion'] for r in nr['cases']), 'Incomplete N105 target')
        require(nr.get('full_Erdos634_solved') is False, 'N105 scope changed')
        shutil.copy2(n/'VERIFIED_RESULTS.json', out/'n105.json')
        print('N105_FOUR_COMPLETE_CERTIFICATES=PASS', flush=True)
        s = work/'spectra'
        execute([sys.executable,'verify_certificate.py','construction_116640.json','--expand','--report',str(out/'construction-116640.json')], s, out/'construction-116640.log')
        sr = json.loads((out/'construction-116640.json').read_text())
        require(sr.get('result') == 'ACCEPT_EXACT_HIERARCHICAL_CONSTRUCTION', 'Construction did not pass')
        require(sr.get('expanded_tiles_checked') == 116640, 'Wrong expanded tile count')
        require(sr.get('expanded_coordinate_sha256') == '86710b7ea51c174e070bf1cc4cda6860815f9e9c790529008caca53d49bf0f23', 'Expanded coordinate digest mismatch')
        execute([sys.executable,'check_general_formulas.py'], s, out/'spectra-formulas.log')
        gr = json.loads((s/'general_checks.json').read_text())
        require(gr.get('result') == 'PASS_SUPPLEMENTARY_CHECKS', 'General formulas did not pass')
        shutil.copy2(s/'general_checks.json',out/'spectra-formulas.json')
        print('SPECTRA_AND_116640_EXPANDED_CONSTRUCTION=PASS', flush=True)
        c = work/'c-relations'
        execute([sys.executable,'check_relations.py','--max-v','40','--output',str(out/'c-relations.json')], c, out/'c-relations.log')
        cr = json.loads((out/'c-relations.json').read_text())
        require(cr.get('status') == 'PASS', 'c-relation arithmetic failed')
        print('C_RELATION_ARITHMETIC=PASS', flush=True)
        u = work/'uniform-reduction'
        execute([sys.executable,'verify_all.py'], u, out/'uniform-reduction.log')
        ur = json.loads((u/'VERIFIED_RESULTS.json').read_text())
        require(ur.get('result') == 'ALL_SUPPLEMENTARY_CHECKS_PASSED', 'Uniform reduction checks failed')
        require(ur.get('full_problem_solved') is False, 'Uniform reduction scope changed')
        require(ur.get('global_finite_exception_list_proved') is False, 'Global exception-list claim changed')
        shutil.copy2(u/'VERIFIED_RESULTS.json', out/'uniform-reduction.json')
        print('UNIFORM_REDUCTION_SUPPLEMENTARY_CHECKS=PASS', flush=True)
    result = {'result':'ALL_FINITE_SUITES_PASSED','scope':'Finite certificates and implementation checks. Published classifications and written universal proofs are not formalized by this run.',
              'N105_cases':[{k:r[k] for k in ['case','certified_roots','proof_states_replayed','certificate_sha256']} for r in nr['cases']],
              'construction_expanded_tiles':sr['expanded_tiles_checked'], 'spectra_sample_triples':gr['primitive_triples'],
              'c_relation_pairs':cr['primitive_pairs'], 'uniform_reduction_result':ur['result'], 'full_Erdos634_solved':False,'external_peer_review':False,
              'seconds':round(time.monotonic()-start,3)}
    (out/'summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2)); return 0

if __name__ == '__main__':
    try: raise SystemExit(main())
    except (ValueError, RuntimeError) as exc:
        print(str(exc),file=sys.stderr); raise SystemExit(1)
