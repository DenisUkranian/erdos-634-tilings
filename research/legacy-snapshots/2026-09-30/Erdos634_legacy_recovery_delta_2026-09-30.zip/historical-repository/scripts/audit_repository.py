#!/usr/bin/env python3
"""Structural audit of local repository files; not a mathematical proof.

No network calls and no automatic repairs. Current repository metadata must be
queried separately from GitHub: a local desired-settings file is not live state.
"""
from __future__ import annotations
import argparse, hashlib, json, re, sys
from pathlib import Path
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[1]
SKIP = {'.git', '__pycache__', '.pytest_cache', 'audit-output'}
TEXT = {'.md', '.tex', '.cff', '.py', '.yaml', '.yml', '.txt'}
BAD_PROJECT = re.compile(r'\b(?:Erd[oőö]s[\s\-_]*)?(?:problem\s*[#№]?\s*506\b|erdos[-_]506\b)', re.I)
SECRET = re.compile(r'(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|-----BEGIN [A-Z ]*PRIVATE KEY-----)')
LINK = re.compile(r'!?\[[^\]]*\]\(([^\s)]+)(?:\s+"[^"]*")?\)')

def audit(root: Path) -> dict:
    inventory, parse_errors, wrong_refs, broken, secrets, external = [], [], [], [], [], set()
    counts = {'python': 0, 'json': 0, 'markdown': 0, 'pdf': 0}
    for p in sorted(root.rglob('*')):
        rel = p.relative_to(root)
        if not p.is_file() or any(part in SKIP for part in rel.parts) or p.suffix == '.pyc':
            continue
        data = p.read_bytes()
        inventory.append({'path': rel.as_posix(), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
        if p.suffix == '.py':
            counts['python'] += 1
            try: compile(data, rel.as_posix(), 'exec')
            except Exception as e: parse_errors.append({'path': str(rel), 'error': str(e)})
        if p.suffix == '.json':
            counts['json'] += 1
            try: json.loads(data)
            except Exception as e: parse_errors.append({'path': str(rel), 'error': str(e)})
        if p.suffix == '.pdf': counts['pdf'] += 1
        if p.suffix in TEXT:
            try: text = data.decode('utf-8')
            except UnicodeDecodeError as e:
                parse_errors.append({'path': str(rel), 'error': str(e)}); continue
            for n, line in enumerate(text.splitlines(), 1):
                # Inspect research-facing prose, not a scanner's own test literals.
                if p.suffix in {'.md', '.tex', '.cff'} and BAD_PROJECT.search(line):
                    wrong_refs.append({'path': str(rel), 'line': n})
                if SECRET.search(line): secrets.append({'path': str(rel), 'line': n})
            if p.suffix == '.md':
                counts['markdown'] += 1
                for target in LINK.findall(text):
                    if target.startswith(('https://', 'http://')):
                        external.add(target); continue
                    if target.startswith(('mailto:', '#')): continue
                    filepart = unquote(target.split('#', 1)[0])
                    destination = (p.parent / filepart).resolve()
                    if not destination.is_relative_to(root.resolve()) or not destination.exists():
                        broken.append({'path': str(rel), 'target': target})
    desired = root / '.github/repository-metadata.json'
    settings = json.loads(desired.read_text()) if desired.exists() else None
    if settings and ('634' not in settings.get('description', '') or '506' in settings.get('description', '')):
        wrong_refs.append({'path': '.github/repository-metadata.json', 'line': 0})
    return {
        'result': 'PASS' if not (parse_errors or wrong_refs or broken or secrets) else 'FAIL',
        'scope': 'Local structural inventory, parse, relative-path and research-label checks only.',
        'files': len(inventory), 'counts': counts, 'inventory': inventory,
        'parse_errors': parse_errors, 'wrong_project_references': wrong_refs,
        'broken_relative_links': broken, 'possible_secrets': secrets,
        'external_urls_not_network_verified': sorted(external),
        'desired_metadata': settings, 'live_github_metadata_verified': False,
        'full_Erdos634_solved': False, 'universal_proofs_formally_verified': False,
    }

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--report', type=Path, default=ROOT/'audit-output/repository.json')
    args = ap.parse_args()
    result = audit(ROOT)
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in {'inventory','external_urls_not_network_verified'}}, ensure_ascii=False, indent=2))
    return 0 if result['result'] == 'PASS' else 1

if __name__ == '__main__': raise SystemExit(main())
