# Current frontier and historical N=105 investigation

**Research snapshot 0.2.0 — 30 September 2026**

The complete mathematical obligation ledger is now [What would complete Erdős problem 634?](full-problem-frontier.md).

## What is settled in the current project package

The [global N=105 proof](n105-global.md) now supplies the exhaustive reduction and complete certificates for all four residual targets. The count 21 and fixed tile (2,3,4) have their own [reduction](n21-global-reduction.md) and [table](first-tile-classification.md). The [two-piece construction](two-piece-construction.md) and [universal Group-1 annuli](universal-rational-scales.md) are retained. The [general spectra package](../research/spectra/PROOF.md) adds 60°/120° scale restrictions and large-scale constructions.

These results have internal exact checks and written proof dependencies, not external referee acceptance. The [prime manuscript](prime-case-dependencies.md) remains a separate candidate. None of these statements is an all-N classification.

## The remaining N105 investigation

This heading is retained so older internal links continue to work. Its former open checkpoint is **historical**: the (7,8,13), (5,16,19), (5,19,21) and (7,13,15) targets are all covered in the [complete current package](../research/n105/README.md). Older collar arguments retain only their stated local scope; the final global proof does not infer completeness from a collar or a timeout.

## Remaining mathematical work

Small-scale realizability across unbounded primitive parameters and a two-sided synthesis of every classified angular family remain open in this project. Sufficient large-scale bounds, the exact fixed-tile table and a proposed all-primes theorem do not decide all composite N. See the [family-by-family frontier](full-problem-frontier.md) for precise missing implications.
