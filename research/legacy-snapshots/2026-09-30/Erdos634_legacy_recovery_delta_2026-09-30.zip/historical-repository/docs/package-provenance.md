# Package provenance and superseded checkpoints

The imported repository source is the GitHub Actions artifact for audit-branch commit `af03bbd8e489d9e81e7299b940eea3e350e6b0da`, whose only difference from main commit `f1a5f7a861e06f00731ad5d2b6ab6bf0b2dbad84` is the added repository-audit workflow. All 121 artifact inventory hashes matched. Main itself has 120 tracked files at that snapshot.

The latest complete N=105 package, general-spectra package and c-relation arithmetic audit are integrated under `research/`. Source-archive digests are in [the provenance record](../verification/source-provenance-2026-09-30.json). Earlier partial search archives are not promoted to current results and are not required to replay the final proof. Original completed results already on main are retained.

Preparation corrections: the N=105 introduction now includes the classical twice-a-square family; both Markdown and PDF are corrected. This even family cannot produce 105. Certificate coordinates and refutation graphs are unchanged. The spectra PDF receives missing title/author metadata, with the same mathematical pages. Its LaTeX source receives matching metadata. Historical coverage tables are explicitly labelled as such.

The selected final fourth-target certificate contains and freshly replays 22,552 states. Together the four current certificates replay 42,137 states. Earlier packages can have different stored/visited-state totals; only the digest-associated current certificate is used. No increase in mathematical scope is inferred merely from a node total.

This prepared snapshot does not reproduce private correspondence. It does not include failed old pruning certificates as valid proofs, nor silently combine incomplete searches into a complete root cover. All finite replays remain separate from independent human review of universal geometric claims.

Publication state is not established by a prepared README, version string, or local metadata JSON. The remote repository and its About field must be read after successful authenticated writes.
