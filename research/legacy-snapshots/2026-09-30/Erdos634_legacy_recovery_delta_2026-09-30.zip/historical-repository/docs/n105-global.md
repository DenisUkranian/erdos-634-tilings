# Global N=105 exclusion — current project entry

The current package is [research/n105](../research/n105/README.md), with [PDF](../research/n105/PROOF_N105.pdf), [written reduction](../research/n105/PROOF_N105.md), [boundary lemmas](../research/n105/BASELINE_LEMMAS.md), four certificates and independently implemented replays.

The supplied computer-assisted argument excludes **any** triangle tiled by exactly 105 congruent triangles, conditional only on its explicitly stated published classification/rationality inputs and the written lemmas. It does not use the candidate all-primes manuscript. It has internal exact replay, not external referee acceptance or a proof-assistant formalization.

The complete boundary coverages are 120, 120, 15 and 1788 for the pairs (7,8,13)/(56,91,105), (5,16,19)/(80,95,105), (5,19,21)/(105,105,105), and (7,13,15)/(105,105,105). Each normalization is justified in the written proof. No incomplete search root is counted as refuted.

The historical collar notes retain useful local obstructions, but their statements that 105 is unresolved describe their 29 September checkpoint. Final certificates supersede the later partial 99/120, 119/120, 64/120 and 94/120 bookkeeping as well. The old false boundary-marking prune is not included as a proof premise.

During repository preparation the classical equilateral count list was corrected to include **twice a square**, an even family that cannot yield 105. The correction changes neither the global reduction's conclusion nor any certificate. Both the Markdown and rebuilt PDF carry the corrected list.

Run all finite checks from the repository root with `python scripts/verify_all.py --jobs 2`. Full Erdős problem 634 is still [separate](full-problem-frontier.md).
