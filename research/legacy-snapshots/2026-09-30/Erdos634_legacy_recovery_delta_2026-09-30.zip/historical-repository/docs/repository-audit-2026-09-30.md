# Repository integration audit — 30 September 2026

This report concerns the prepared local update, not a claim that GitHub has already received it. The desired About settings are in `.github/repository-metadata.json`; committing that file alone does not change repository settings.

The source snapshot was obtained from the successful GitHub Actions audit run 36699854537 at `af03bbd8e489d9e81e7299b940eea3e350e6b0da`. All 121 source file hashes matched its inventory. Main remained `f1a5f7a861e06f00731ad5d2b6ab6bf0b2dbad84`; its exact Git tree was reconstructed and matched `e4ae3d143139d24aa76382bfc1767d6aa118ebaf`. The extra branch file was the audit workflow, not the new research packages.

## Integration

The update retains the existing research, adds the complete [N=105 module](../research/n105/README.md), the [general spectra module](../research/spectra/README.md), the [c-relation arithmetic audit](../research/c-relations/audit.md), and the earlier [whole-side lemma](side-chain-lemma.md). Earlier collar and incomplete-boundary reports are labelled as historical rather than presented as the current frontier.

The N=105 proof's introductory list of classical equilateral count forms omitted twice a square. That family is now included in the Markdown and rebuilt seven-page PDF. It cannot equal the odd count 105, so no refutation certificate changes. The six-page spectra PDF metadata now states its title and author. Neither edit turns a candidate universal proof into an externally verified theorem.

README in both languages, the claim ledger, reproducibility instructions, version history, citation metadata, the file hash manifest and CI were synchronized. The all-primes manuscript remains version 0.1.0 and explicitly a candidate; the repository integration version is distinct.

## Executed checks

The current live suite was rerun successfully. The integrated local command `python scripts/verify_all.py --jobs 2` also passed: structural checks; the existing suite; all four complete N=105 certificates; the fully expanded 116,640-tile construction; supplementary spectra tests; and the c-relation audit. The frozen [combined report](../verification/integrated-local-replay-2026-09-30.json) records exact certificate hashes and counts.

The four N=105 replays visited 9,949 + 1,585 + 8,051 + 22,552 = **42,137 states**. The 22,552-state final certificate is identified by its own digest; earlier 22,435-state reports described a different retained certificate/replay and are not silently merged into this run.

All Python sources were parsed; all JSON files loaded; relative Markdown file targets checked; project-labelled prose and obvious credential patterns scanned. Four PDF manuscripts were inspected for text, title metadata and layout. External link destinations and Markdown fragment anchors are not all network-validated by the local scanner. These checks do not amount to a line-by-line formal proof audit of every mathematical assertion.

## Boundary of confidence

Finite certificate replay does not prove the cited classification theorems or formalize the written universal lemmas. All source contributions remain attributed. No external referee acceptance, priority ruling, complete all-N solution, or new remote-CI success is claimed. The remaining mathematical obligations are [listed separately](full-problem-frontier.md).
