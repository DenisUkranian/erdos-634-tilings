# Necessary complete exterior chains, including T-junctions

30 September 2026. Internal mathematical and computational note; no priority claim.

## Lemma

Fix a convex triangular target and a congruent triangular tile of integer side lengths. Suppose the length L of a specified target side is an integer. Fix any actual partial placement of pairwise interior-disjoint tiles inside the target.

Every complete tiling extending that placement induces a path through a finite catalogue of possible whole boundary-edge tiles on the specified side. Consequently:

1. If that catalogue has no compatible path covering the whole side, the partial placement cannot extend.
2. If a particular tile placement occurs on every such path, it must occur in every complete tiling extending the partial placement.

Here compatibility need only be a necessary condition. A surviving path is not asserted to be a tiling.

## Proof and exact catalogue

The supporting line of a convex target side cannot cut the interior of any tile. Every tile edge lying on that supporting line lies wholly on the target side. These whole edges partition the side. Starting at one target corner, their endpoints have distances equal to sums of integer tile lengths, hence are integers between 0 and L.

For each such starting distance s and each of the three possible edge lengths, list both possible inward placements of a congruent tile using the segment from s to s+length. Discard candidates leaving the target or overlapping the fixed partial placement. Already placed tiles that have a boundary edge are allowed as identical placements, not counted as overlapping copies. Exact whole-boundary junction and marked-edge necessary tests may discard further candidates.

A catalogue entry consists of a starting distance, an ending distance, and an actual tile placement. Draw a directed arc when one entry ends exactly where the next begins and the two placements have no positive-area overlap and pass the necessary marked-edge test. Because every edge has positive length, this graph is acyclic. Add source entries starting at 0 and sink entries ending at L.

An actual extension supplies exactly such a source-to-sink chain. We deliberately do not require all nonconsecutive candidate tiles to be mutually compatible: this enlarges the admissible path set and is therefore safe for nonexistence and mandatory-tile deductions. Interior T-junctions are not excluded. No guessed continuation of an interior seam is used.

If no source-to-sink path exists, an extension cannot exist. If a tile belongs to every permitted path, it belongs to every path induced by an extension. This proves both conclusions.

## Two implementations of forced placement

The search retains catalogue entries that lie on at least one full path. For each open unit interval (j,j+1) along the side, it collects the tile placements that can cover that interval on such a path. A singleton is mandatory.

The separate checker attaches to each reachable entry the intersection of tile-label sets across every source-to-that-entry path, followed by the current entry's tile label. Intersecting these sets across all sink entries gives the tiles present on every complete path. This is ordinary finite-set intersection on an acyclic graph, using exact geometry to establish catalogue entries and transitions.

Mandatory tiles obtained on different sides must coexist. If two distinct mandatory tiles overlap, the partial placement is impossible.

## Instances and verification boundary

Coordinates use the oblique basis (1,0),(1/2,sqrt(3)/2). The first target has vertices (0,0),(56,0),(-49,105); its tile sides are 7,8,13. All placement computations and intersections are rational in this basis.

Within the bounded continuation of initial configuration 834, the search found 146 distinct valid partial placements for which a complete exterior chain is impossible. The file `side_obstructions.json` lists them explicitly; `verify_side_obstructions.py` validates their geometry and recomputes the chain obstruction independently. It imports the clipping checker, not the search engine or its chain routine.

The 146 local obstructions do not cover all possible descendants of root 834. The full root remains INCOMPLETE. Neither the bounded run, nor a surviving catalogue path, proves that a 105-tile dissection exists.

The regression comparison additionally checked 40 partial states with two methods, including 3 no-path states and 3 states with mandatory additional tiles. Such finite regression comparisons are diagnostics, not a substitute for the mathematical lemma or exact replay of each recorded obstruction.
