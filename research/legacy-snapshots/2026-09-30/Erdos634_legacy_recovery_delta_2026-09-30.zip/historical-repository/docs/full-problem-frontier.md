# What would complete Erdős problem 634?

**30 September 2026. This is a mathematical obligation ledger, not a proof that the remaining obligations are satisfied.**

## The exact target

Determine the set

$$\mathcal A=\{N\in\mathbb Z_{>0}:\text{some nondegenerate triangle is tiled by }N\text{ congruent triangles}\}.$$

The tile and the outer triangle are both allowed to vary. Reflections and arbitrary T-junctions are allowed. The [problem statement](https://www.erdosproblems.com/634) asks for all N; neither one fixed tile, all primes, nor a single composite decides this infinite classification.

A full answer needs a criterion C(N) with two implications: every C(N) has a genuine construction, and every tiling forces C(N). It may be proved directly at the global level; an exact classification of every fixed-tile spectrum is a sufficient route, not logically the only possible route. A finite computation or a statement that a necessary condition is decidable is not an implemented all-N classification here.

## What is present, and the exact mathematical gap

| Family / task | What the current project supplies | What is not supplied |
|---|---|---|
| Classical and similar-tile cases | Cited known count forms, with squares, sums of two squares and the relevant 2, 3 and 6 times-square constructions retained. | Final all-N assembly must include every allowed commensurable/right-tile case, without silently dropping an even family. |
| All primes | Candidate p=2, p=3 or p≡1 mod 4, based on the W and beta scale-one geometric arguments. | Independent rigorous review of those inductions and their dependencies. Even their acceptance would not decide composite counts. |
| The single count 105 | Complete project computer-assisted exclusion, with four finite certificates and an exhaustive written reduction. | This is not a theorem about every composite or every square multiple of 105. No reverse scaling implication is available. |
| Fixed tile (2,3,4) | Complete project table for that tile, with attribution and explicit certificates. | Different primitive tiles need not have the same minimal scales or exception pattern. |
| 3α+2β=π, primitive tile (uv,v²−u²,v²) | Exact other-scalene family QP k². For W, beta, theta and alpha, explicit sufficiently-large-scale constructions and necessary count forms QT², PT², bT² and bQK² are recorded in the annular notes. | Exact low-scale realizability uniformly over every coprime 0<u<v. In particular, scale-one nonexistence does not decide scales 2, 3, etc. |
| Equilateral targets, primitive irrational-angle 60°/120° tiles | Necessary S=abm and N=abm². Sufficient m≥3(q+1) or m≥3(q+2), q=floor(max(a,b)/min(a,b)). | The exact possible multipliers below the sufficient threshold. The threshold is not asserted optimal or necessary. |
| 120° F1 and isosceles ratio forms | Necessary b(a+b)m² and b(a+2b)m², with existing attribution; constructions transfer from equilateral targets at large m. | Small multipliers, for all ordered primitive norm triples. A transfer construction is not a compulsory decomposition of arbitrary tilings. |
| Other scalene 120° shapes | Classification and explicit necessary product formulas occur in the N=105/prime dependency notes; source construction results are referenced. | A complete necessity-and-sufficiency synthesis of all their scales, including low-scale exceptions. They cannot be omitted just because F1 was hardest at 105. |
| Double-angle isosceles tile γ=2α | Cited count restrictions and a written no-squarefree-count argument. | Its remaining admissible composite counts must be included in the all-N synthesis or globally covered/excluded by another proved argument. |

Here b=v²−u², Q=2v²−u² and P=3v²−u² in Group 1. A fixed-tile necessary form is not a sufficient construction.

## Why finitely many exceptions per tile are not enough

For a fixed primitive tile the large-scale construction leaves a finite interval of smaller multipliers. But the primitive parameters range over infinitely many tiles. Their union need not be a finite global exception set. Completing the problem therefore requires a uniform theorem for those residual instances, or another global characterization that proves which N occur without individually classifying every tile.

Similarly, N∈A implies k²N∈A by subdivision. The converse does not follow: a small-scale obstruction cannot be propagated upward as nonexistence. The known scale-2 and scale-3 constructions in some families illustrate why the direction of implication matters.

## Four proof obligations for an all-N claim

1. **Exhaustive reduction.** A version-specific ledger covers every classified angular family, every permitted interchange of side labels, every scale and every arithmetic exception. Withdrawn claims are not imported through a theorem citation.
2. **Sharp realization criterion.** The remaining low-scale regime is decided by a proved criterion, or bypassed by an independent all-N theorem. Integer edge counts, direction invariants and compatible local fans alone are not tiling existence.
3. **Two-sided certificate.** Each positive class has actual nonoverlapping constructions; each negative class has a universal argument or a finite, proved-exhaustive reduction with validated refutations. Bounds on parameters and recursion termination are proved, not chosen experimentally.
4. **Assembly and verification.** The implications are combined without confusing fixed tile, fixed target, invariant-admissible spectrum and global count spectrum. Formalization or external review would strengthen confidence, but neither can fill an unwritten mathematical step.

## Specific next mathematical targets

The highest leverage is a theorem for small multipliers across an entire parameter family, not another isolated N. One route is to characterize when the required boundary chains force a genuine extendable macro partition. Any converse must prove that this partition is compulsory, rather than infer it from a construction that happens to work.

The 116,640-tile example at multiplier 9 for (45,32,67) rules out using the displayed v4 cutoff 12 as a necessary condition for that fixed tile. It does **not** provide the corrected sharp cutoff for every tile. Its source comparison is version-specific.

## Sources and limitations

- [Problem definition](https://www.erdosproblems.com/634).
- Beeson–Zhang, [Rationality of certain triangle tilings](https://arxiv.org/abs/2604.01314), for the rationality input; the project proof notes record the exact theorem versions used.
- Zhang, [Tiling Triangles with 2π/3 Angles](https://arxiv.org/abs/2512.22696), for constructive sporadic-family context. The project's counterexample comparison is to v4, not a claim about every later version.
- [Group-1 annuli](universal-rational-scales.md), [general spectra](../research/spectra/PROOF.md), [global 105 proof](../research/n105/PROOF_N105.md), [prime dependencies](prime-case-dependencies.md).

No full all-integer solution, external referee acceptance, or priority ruling is asserted by this repository update.


## Later uniform reduction

The [uniform-reduction note](../research/uniform-reduction/PROOF.md) adds an explicit finite arithmetic overlist for each fixed N, a finite geometric branching argument, and squarefree residue-class obstructions. It does not prove that the exceptional scales over all primitive tiles form a finite global set. The (8,7,13) tile on (91,91,154) remains a recorded unresolved fixed instance in that note. Adding more translation-invariant length-linear edge weights alone cannot prove its Group-1 scale-one exclusions: explicit formal orientation witnesses satisfy their full edge signatures without supplying a spatial dissection.
