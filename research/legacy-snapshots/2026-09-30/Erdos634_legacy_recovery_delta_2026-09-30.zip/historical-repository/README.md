# Erdős Problem 634 — congruent triangle tilings

**Denis Paliy** · Research with ChatGPT assistance

[Status](STATUS.md) · [Reproduce](REPRODUCIBILITY.md) · [Remaining work](docs/full-problem-frontier.md) · [Citation](CITATION.cff)

Which positive integers N permit a triangle to be dissected into N congruent triangles? Reflections and arbitrary T-junctions are allowed.

**The full classification is not claimed.** Written proofs, candidate arguments, positive constructions, and finite exclusion certificates have distinct verification scopes. The results below have project-internal checks, not external referee acceptance or complete proof-assistant formalization.

## Results and evidence

| Result | Material and scope |
|---|---|
| Global N=105 exclusion | [Manuscript](research/n105/PROOF_N105.pdf), [written reduction](research/n105/PROOF_N105.md), [four complete certificates and checkers](research/n105/README.md). The global conclusion also depends on the listed classification theorems and geometric lemmas. |
| Prime-count classification candidate | [Manuscript](paper/prime-case-candidate.pdf) and [dependency ledger](docs/prime-case-dependencies.md). Universal W/beta forcing arguments remain a separate candidate requiring mathematical review. |
| Primitive scales and eventual constructions | [General spectra](research/spectra/PROOF.md), including the exact [116,640-tile construction](research/spectra/README.md). Necessary arithmetic restrictions are distinguished from sufficient geometric constructions. |
| Uniform reduction and residue-class obstructions | [Manuscript](research/uniform-reduction/paper.pdf), [proof](research/uniform-reduction/PROOF.md), [code and reproduction](research/uniform-reduction/README.md). Includes squarefree obstructions, a per-N finite candidate list, and formal edge-signature limitations; not an all-N classification. |
| All five rational target shapes at sufficiently large scales | [Two-annulus construction](docs/universal-rational-scales.md) and [explicit seeds](docs/explicit-theta-seeds.md). Small scales remain unclassified in general. |
| Constructions, fixed-tile analysis, and N=21 | [322-tile construction](docs/two-piece-construction.md), [all targets for tile (2,3,4)](docs/first-tile-classification.md), and [N=21 reduction](docs/n21-global-reduction.md). Prior work is credited. |
| Chain-length checks | [c-relation arithmetic audit](research/c-relations/audit.md) and [whole-side chain lemma](docs/side-chain-lemma.md). |

## Reproduce

Python 3.10 or newer; mathematical checks use the standard library:

```bash
python scripts/verify_all.py --jobs 2
```

The command checks the original suite, all four N=105 certificates, the expanded positive construction, chain arithmetic, and the later uniform-reduction tests. It writes fresh reports to `audit-output/`; it does not publish anything. Do not use `-O`, `-OO`, or `PYTHONOPTIMIZE`.

The [recovery inventory](docs/recovery-2026-09-30.md) identifies the source packages and explains which historical reports have been superseded. No incomplete search is counted as an exclusion.

## Authorship and reuse

Denis Paliy directed the investigation. ChatGPT assisted with exploration, drafting, programming and checks; see [AI_USAGE_DISCLOSURE.md](AI_USAGE_DISCLOSURE.md). No research priority is adjudicated.

Original software: [MIT](LICENSE). Documentation and figures: [CC BY 4.0](LICENSE-DOCUMENTATION.md). Third-party works retain their rights. [Corrections and independent review](CONTRIBUTING.md) are welcome.
