# Recovery result — 30 September 2026

## Actual remote state

GitHub main was read at commit `47331354525e35515858ef96740866e1d4b3c300`. Its Description is already correct: `Erdős Problem 634 - congruent triangle tilings.`. The current default-branch README explicitly says the later complete N=105 package has not yet been incorporated. No remote write or final-main CI is claimed by this recovery.

## Prepared and checked here

The integrated tree contains 215 files. It includes the original research, the four complete N=105 finite certificates and their written reduction, the general-spectra work and expanded 116,640-tile construction, c-relation arithmetic, and the later uniform-reduction package. A short English README replaces the old duplicated landing pages. Source package hashes and canonical locations are recorded in `repository/verification/recovery-provenance.json` and `repository/docs/recovery-2026-09-30.md`.

The fresh combined run finished with `ALL_FINITE_SUITES_PASSED`:

| Component | Outcome |
|---|---|
| Repository structure and local file links | PASS |
| Earlier published finite suite | PASS |
| Four complete fixed-target N=105 certificates | PASS |
| Expanded 116,640-tile construction and general formula controls | PASS |
| Sharp c-relation arithmetic | PASS |
| Later uniform-reduction supplementary checks | PASS |

The copied tree also matches its frozen source-file hashes. This is not external peer review, a proof-assistant formalization of the written hypotheses, or a new all-integer solution of Problem 634. The retained N=154 search is not changed from INCOMPLETE into an exclusion.

## Publication

`publish.py` is based on the actually observed main commit, not the earlier obsolete base. It uses an existing authorized Git login, refuses a changed main, performs a clean-copy replay before push, and never force-pushes or modifies Description. Seven local unit tests passed; an authenticated remote push was not executed in this environment.

Run `python publish.py` to verify package integrity without network access. Explicit publication is `python publish.py --publish`. See `START_HERE.md`. A successful package check is not a successful GitHub publication.
