# Erdős 634 — recovered, integrated source snapshot

This is a prepared source snapshot, not evidence of a new GitHub commit.

## Contents

`repository/` contains the canonical N=105 package (four complete fixed-target certificates plus its written global reduction), general-spectra proofs and the full compressed 116,640-tile coordinate list, the sharp c-relations audit, the later uniform-reduction package, and the earlier manuscripts/constructions/checks. The short landing page is English-only. Duplicate Russian summaries are not restored.

`checks/` contains fresh outputs from the combined verification performed during recovery. `PAYLOAD_MANIFEST.json` freezes the included bytes. The code checks finite evidence and implementation controls, not every handwritten theorem or external classification input.

## GitHub state observed during recovery

Repository: `DenisUkranian/erdos-634-tilings`.

Main commit: `47331354525e35515858ef96740866e1d4b3c300`.

Description: `Erdős Problem 634 - congruent triangle tilings.`

The current main landing page still says the later complete N=105 package has not been incorporated. No publication is claimed by this ZIP. Historical staging blobs and a successful staging workflow are not a completed import.

## Inspect or publish

Requirements for publication: Python 3.10+, Git, and an existing Git login that can push this repository, including the workflow updates. Neither a raw token nor a password is handled by these scripts. Do not send credentials in chat.

To check package hashes without making a network request:

```text
python publish.py
```

To replay all mathematical implementation checks locally:

```text
cd repository
python scripts/verify_all.py --jobs 2
```

To explicitly publish from this package directory using the existing Git login:

```text
python publish.py --publish
```

The publisher clones into a temporary directory, checks the exact expected main commit before and after verification, copies the frozen files, stages them, runs the combined finite replay, and then makes a normal commit and push. It never force-pushes, deletes the repository, rewrites history, or updates Description. A changed main or failed check causes it to stop before push. The temporary clone is retained. `PUBLISH_RESULT.json` records whether push and read-back succeeded. A successful local replay or local commit does not by itself mean GitHub was updated; remote CI must be checked separately.

The publisher's seven local unit tests cover payload integrity, unsafe paths, a changed main, and preserving unrelated files. They are not an authenticated remote-push test.

## Mathematical status

This recovery adds no claim of a full solution. The uniform-reduction note does not supply a global finite exception list; the recorded N=154 fixed instance remains INCOMPLETE. The prime-case manuscript is a separate candidate. See `repository/docs/full-problem-frontier.md`.
