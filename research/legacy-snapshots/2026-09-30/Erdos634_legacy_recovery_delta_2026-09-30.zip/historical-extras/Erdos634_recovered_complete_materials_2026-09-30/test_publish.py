import importlib.util,json,hashlib,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
S=importlib.util.spec_from_file_location('publisher',Path(__file__).with_name('publish.py'))
M=importlib.util.module_from_spec(S);S.loader.exec_module(M)
class TestPublish(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.root=Path(self.t.name);self.old=M.HERE;M.HERE=self.root
  p=self.root/'repository';p.mkdir();(p/'a.txt').write_text('example')
  self.manifest={'repository':M.REPOSITORY,'base_commit':M.BASE,'verification_result':'ALL_FINITE_SUITES_PASSED','files':{'repository/a.txt':hashlib.sha256(b'example').hexdigest()}}
  self.save()
 def save(self): (self.root/'PAYLOAD_MANIFEST.json').write_text(json.dumps(self.manifest))
 def tearDown(self): M.HERE=self.old;self.t.cleanup()
 def test_valid(self):self.assertEqual(M.verify_package()['base_commit'],M.BASE)
 def test_mutated(self):
  (self.root/'repository/a.txt').write_text('altered')
  with self.assertRaises(ValueError):M.verify_package()
 def test_unsafe(self):
  for path in ('../out','/tmp/out','.git/config','repository/../../escape','repository\\a.txt'):
   with self.assertRaises(ValueError):M.safe_file(self.root,path)
 def test_wrong_repo(self):
  self.manifest['repository']='other/repo';self.save()
  with self.assertRaises(ValueError):M.verify_package()
 def test_failed_verification(self):
  self.manifest['verification_result']='INCOMPLETE';self.save()
  with self.assertRaises(ValueError):M.verify_package()
 def test_overlay_preserves_unrelated(self):
  c=self.root/'checkout';c.mkdir();(c/'keep.txt').write_text('untouched');(c/'README.ru.md').write_text('duplicate')
  M.copy_payload(c,self.manifest)
  self.assertEqual((c/'keep.txt').read_text(),'untouched');self.assertFalse((c/'README.ru.md').exists());self.assertEqual((c/'a.txt').read_text(),'example')
 def test_changed_main_no_write(self):
  with patch.object(M,'remote_head',return_value='changed'),patch.object(M,'run') as run:
   with self.assertRaises(ValueError):M.publish(self.manifest,2)
   run.assert_not_called()
if __name__=='__main__':unittest.main(verbosity=2)
