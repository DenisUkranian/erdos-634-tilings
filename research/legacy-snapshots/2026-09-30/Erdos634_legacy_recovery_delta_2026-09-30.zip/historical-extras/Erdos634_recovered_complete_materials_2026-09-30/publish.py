#!/usr/bin/env python3
"""Publish this exact audited payload using an existing Git login.

Default: local hash verification only. --publish clones the specified repository,
refuses a changed main, installs the payload, replays its checks, then performs an
ordinary fast-forward push. No token handling, force push, or metadata edits.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
REPOSITORY = 'DenisUkranian/erdos-634-tilings'
BASE = '47331354525e35515858ef96740866e1d4b3c300'
URL = 'https://github.com/' + REPOSITORY + '.git'


def safe_file(root: Path, name: str) -> Path:
    rel = Path(name)
    if rel.is_absolute() or not rel.parts or any(x in ('..', '.git') for x in rel.parts) or '\\' in name:
        raise ValueError('Unsafe payload path: ' + name)
    p = root / rel
    if p.is_symlink() or not p.resolve().is_relative_to(root.resolve()):
        raise ValueError('Unsafe symbolic link/path: ' + name)
    return p


def verify_package() -> dict:
    m = json.loads((HERE / 'PAYLOAD_MANIFEST.json').read_text(encoding='utf-8'))
    if m.get('repository') != REPOSITORY or m.get('base_commit') != BASE:
        raise ValueError('Unexpected repository/base in package')
    if m.get('verification_result') != 'ALL_FINITE_SUITES_PASSED':
        raise ValueError('This package lacks a completed combined replay')
    for name, digest in m['files'].items():
        p = safe_file(HERE, name)
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest() != digest:
            raise ValueError('Missing or altered file: ' + name)
    return m


def run(args: list[str], *, cwd: Path | None = None, stream: bool = False, timeout: int = 1200) -> str:
    result = subprocess.run(args, cwd=cwd, text=True, encoding='utf-8',
                            stdout=None if stream else subprocess.PIPE,
                            stderr=None if stream else subprocess.PIPE,
                            timeout=timeout,
                            env={**os.environ, 'GIT_TERMINAL_PROMPT': '0'})
    if result.returncode:
        raise RuntimeError(f'Command failed: {args[0]} {args[1]} (exit {result.returncode}). '
                           'Check the local command output and your existing Git authorization.')
    return result.stdout or ''


def remote_head() -> str:
    text = run(['git', 'ls-remote', URL, 'refs/heads/main'], timeout=60).strip()
    if not text:
        raise RuntimeError('Main branch not returned')
    return text.split()[0]


def copy_payload(checkout: Path, manifest: dict) -> list[str]:
    names = []
    for name in manifest['files']:
        if not name.startswith('repository/'):
            continue
        rel = name[len('repository/'):]
        src, dst = safe_file(HERE, name), safe_file(checkout, rel)
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)
        names.append(rel)
    # A deliberate removal already requested by the owner. Do not delete any
    # other remote files, old branches, archives, or research evidence.
    obsolete = safe_file(checkout, 'README.ru.md')
    if obsolete.exists():
        obsolete.unlink()
    return names


def publish(m: dict, jobs: int) -> dict:
    if not shutil.which('git'):
        raise RuntimeError('Git is not installed')
    if remote_head() != BASE:
        raise ValueError('Main changed since this payload was prepared. No remote write was made; rebase and re-audit first.')
    work = Path(tempfile.mkdtemp(prefix='erdos634-import-'))
    checkout = work / 'repository'
    print('Clean working copy:', checkout, flush=True)
    run(['git', 'clone', '--single-branch', '--branch', 'main', URL, str(checkout)], timeout=180)
    if run(['git', 'rev-parse', 'HEAD'], cwd=checkout).strip() != BASE:
        raise ValueError('Main changed during clone; no remote write was made')
    names = copy_payload(checkout, m)
    # Stage the frozen payload before replay writes temporary/local reports.
    run(['git', 'add', '--all'], cwd=checkout)
    print('Running fresh finite checks before any push...', flush=True)
    run([sys.executable, 'scripts/verify_all.py', '--jobs', str(jobs)], cwd=checkout, stream=True, timeout=1800)
    report = json.loads((checkout / 'audit-output/summary.json').read_text(encoding='utf-8'))
    if report.get('result') != 'ALL_FINITE_SUITES_PASSED':
        raise ValueError('Fresh verification failed; no push performed')
    if remote_head() != BASE:
        raise ValueError('Main changed during verification; no push performed')
    run(['git', '-c', 'user.name=Denis Paliy', '-c',
         'user.email=120090909+DenisUkranian@users.noreply.github.com',
         'commit', '-m', 'Integrate N105, constructive spectra and uniform reduction with complete finite replay'], cwd=checkout)
    commit = run(['git', 'rev-parse', 'HEAD'], cwd=checkout).strip()
    result = {'repository': REPOSITORY, 'base_commit': BASE, 'commit': commit,
              'local_checks_passed': True, 'push_command_succeeded': False,
              'main_readback_verified': False, 'remote_ci_checked': False,
              'description_modified': False, 'full_problem_solved': False}
    receipt = HERE / 'PUBLISH_RESULT.json'
    receipt.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    try:
        # No force, no force-with-lease, no ref deletion, no history rewrite.
        run(['git', 'push', 'origin', 'HEAD:refs/heads/main'], cwd=checkout, stream=True, timeout=180)
        result['push_command_succeeded'] = True
        result['main_readback_verified'] = remote_head() == commit
        if not result['main_readback_verified']:
            raise RuntimeError('Push succeeded but main read-back differs. Inspect the receipt and repository history.')
    finally:
        receipt.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--publish', action='store_true', help='Replay then push, using an existing authorized Git login')
    parser.add_argument('--jobs', type=int, choices=(1, 2, 3, 4), default=2)
    args = parser.parse_args()
    if not __debug__ or os.environ.get('PYTHONOPTIMIZE'):
        raise ValueError('Run without Python optimization flags')
    m = verify_package()
    print('Payload integrity: PASS', flush=True)
    if not args.publish:
        print('Local verification only. No GitHub changes were made.')
        return 0
    print(json.dumps(publish(m, args.jobs), indent=2))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, RuntimeError, subprocess.TimeoutExpired) as exc:
        print(str(exc), file=sys.stderr)
        print('Not a confirmed complete publication. PUBLISH_RESULT.json records any successful push; the temporary clone is retained.', file=sys.stderr)
        raise SystemExit(1)
