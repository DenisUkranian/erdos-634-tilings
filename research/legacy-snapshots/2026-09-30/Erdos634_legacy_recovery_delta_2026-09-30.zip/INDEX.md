# Exact historical source preservation — Erdős 634 / 30 September 2026

This bundle preserves all source bytes that are not already *byte-for-byte identical* in the current main repository, along with a full manifest of the 30 September recovery snapshot.

- Exactly 215 ordinary repository file snapshots were audited against the `main` tree at commit 5a4b2aa9c5e3839767b23879716bffd8bc3d65cb (10 October).
- 142 snapshots match that commit by Git blob SHA-1, and remain in the Git history.
- 38 source paths no longer exist in the current tree; they are preserved here.
- 35 source paths exist but changed since the snapshot; the old bytes are preserved here.
- All other original recovery extras, such as logs and package provenance, are preserved here.

This is a **historical archive** of previous work, not an endorsement of any superseded proof or old claim. Never replace the current README, STATUS, scripts, or workflows with snapshots found inside this ZIP. See MANIFEST.json for every byte hash and exact path.

Original recovery ZIP (held in ChatGPT Library): SHA256 9c653b4329f2819f1fd71372a7b987171a680564f5d58e0877f8efb68e75640d.
