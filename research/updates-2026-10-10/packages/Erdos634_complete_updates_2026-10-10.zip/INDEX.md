# Erdős Problem 634 — Research supplements, 9–10 October 2026

This archive is a lossless collection of ten research ZIP packages from Denis Paliy's research archive, extracted under individually labelled source directories; `MANIFEST.json` lists every extracted file, its SHA-256 and source container.

It supplements, rather than replaces, the existing `DenisUkranian/erdos-634-tilings` main tree as it stood on 8 October 2026 (commit 3a0ad269f645850ed9fd01bbd76a08c9b456032e).

## Contents
- Audit Phase 1 (9 October): claim ledger, replay scripts, fresh certificates and stress tests, 7 source-package snapshots; reverse-apex text quarantined.
- Audit Phase 2 (10 October): boundary support proofs and controls, independent exact polygon geometry, W/beta construction-level review, newly found counterexamples to overly strong boundary-marking and short-atom continuation rules.
- Group-1 W/beta: all integral fixed-tile scales M>=v constructions (sufficiency only), including symbolic scripts, checked tilings and large witnesses.
- Complete square class 14: an internally checked global 56 impossibility, with positive tilings at m>=3, conditional on the exhaustive global reduction documented in the proof.
- The earlier golden-cone proof and explicit witnesses (retained for provenance, superseded in the sufficient range by the all-M>=v proof).
- Scale-one incomplete searches, positive and negative controls, and W92/beta92 boundary search evidence. `INCOMPLETE` must never be read as `UNSAT`.
- F3 14430: independent boundary analysis, finite currents, witnesses that do NOT constitute tilings, and the exclusion of height occupancy 61 at nonexceptional levels.
- Prime-sector and effective-density investigations, and reproducibility programs.

## Mathematical status at 10 October 2026
**NOT SOLVED IN FULL.** In particular the F3 count 14430, small W/beta multipliers in general, 92, and global sufficiency remain unresolved. Prime-count reverse-apex induction is an unvalidated candidate and must not be used to deduce the claimed classification. All audit PASS values are scoped finite/symbolic tests, not external review or mechanized proofs. General W/beta is a sufficient construction; it does not say smaller scales are impossible.

## Important omitted heavyweight data
A separate previously saved 441,709,276-byte Library ZIP `Erdos634_135_Verified_Certificate.zip` (8 October 2026) is not embedded here: it would dwarf the fresh research packages. The October 8 repository already includes finite-check data and scripts for the class-15/135 investigation; independent revalidation of that entire heavyweight source is beyond this sync.

## Verification
1. Check each extracted `sources/` file against `MANIFEST.json` SHA-256 and its declared source entry.
2. Consult the original `REPORT.md` and `notes/` inside the Phase 1 and Phase 2 directories before interpreting a PASS.
3. Re-run finite audits using each package's README/`reproduce.py`, respecting optional SymPy/NumPy/Numba dependencies and the declared scope of each run.
4. Check GitHub branch/main independently after syncing; a successful push alone does not prove mathematical correctness.
