bool cyclic(Line& l){
 int n=l.sides.size()-1;if(n<=0)return false;l.ok.assign(n+1,0);
 if(l.full){int base=l.full==1?0:3;
 vector<char> F(n+1),U(n+1);F[0]=1;U[n]=1;
 for(int i=0;i<n;i++)if(F[i])for(int k=0;k<3;k++)if(l.sides[i]&(1<<(k+base)))F[i+sz[k]]=1;
 if(!F[n])return true;
 for(int i=n-1;i>=0;i--)for(int k=0;k<3;k++)if((l.sides[i]&(1<<(k+base)))&&U[i+sz[k]]){U[i]=1;if(F[i])l.ok[i]|=1<<(k+base);}return false;
 }
 // State i,d: upper-bank frontier i, lower-bank frontier i+d.
 int w=2*c+1;vector<uint8_t> f((n+1)*w),u(f.size());
 auto st=[&](int i,int d){return i*w+d+c;};
 for(int i=0;i<=n;i++){int lo=max(-c,-i),hi=min(c,n-i);for(int d=lo;d<=hi;d++){
  int k=st(i,d);if(!d)f[k]=1;if(!f[k])continue;
  bool upper=d>=0;int t=upper?i:i+d;int mask=l.sides[t]>>(upper?0:3);
  for(int j=0;j<3;j++)if(mask&(1<<j)){int m=sz[j];if(upper)f[st(i+m,d-m)]=1;else f[st(i,d+m)]=1;}
 }}
 for(int i=n;i>=0;i--){int lo=max(-c,-i),hi=min(c,n-i);for(int d=hi;d>=lo;d--){
  int k=st(i,d);if(!f[k])continue;if(!d)u[k]=1;
  bool upper=d>=0;int t=upper?i:i+d;int base=upper?0:3;int mask=l.sides[t]>>base;
  for(int j=0;j<3;j++)if(mask&(1<<j)){int m=sz[j];int z=upper?st(i+m,d-m):st(i,d+m);if(u[z]){u[k]=1;l.ok[t]|=1<<(j+base);}}
 }}return false;
}
