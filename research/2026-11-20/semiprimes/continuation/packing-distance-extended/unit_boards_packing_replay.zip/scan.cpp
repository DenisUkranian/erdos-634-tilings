#include <algorithm>
#include <array>
#include <vector>
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <cmath>
#include <string>
using namespace std;
struct P{int x,y;};
P operator+(P x,P y){return {x.x+y.x,x.y+y.y};}
P operator-(P x,P y){return {x.x-y.x,x.y-y.y};}
P operator*(int n,P x){return {n*x.x,n*x.y};}
P mul(P x,P y){return {x.x*y.x-x.y*y.y,x.x*y.y+x.y*y.x+x.y*y.y};}
long long cr(P p,P q){return (long long)p.x*q.y-(long long)p.y*q.x;}
int a,b,c,A,B,sz[3],xupper;
P v[6]={{1,0},{0,1},{-1,1},{-1,0},{0,-1},{1,-1}};
struct Line{vector<uint8_t> sides,ok;int full=0,lo=0;};
#include "dp.inc"
vector<char> coin;
P phys(int h,P p){return h?P{c*B,0}+mul({a,b},p):c*p;}
P other(int h,P p){P q=h?phys(1,p):mul({a+b,-b},p-P{B,0});return (q.x%c||q.y%c)?P{100000,100000}:P{q.x/c,q.y/c};}
bool inside(P p){return p.x>=0&&p.y>=0&&(long long)A*p.x+(long long)B*p.y<=(long long)c*A*B;}
bool legal(P p){if(!inside(p))return false;
 if(!p.y&&(p.x%c||!coin[p.x/c]||!coin[B-p.x/c]))return false;
 if(!p.x&&(p.y%c||!coin[p.y/c]||!coin[A-p.y/c]))return false;
 if((long long)A*p.x+(long long)B*p.y==(long long)c*A*B){
  if((long long)p.y*c%A)return false;int off=(long long)p.y*c/A;
  if(!coin[off]||!coin[c*c-off])return false;}
 return true;}
int li(P p,int j){return j==0?p.y:j==1?p.x:p.x+p.y;}
int xx(P p,int j){return j==0?p.x:p.y;}
struct Frame{int lx,ux,ly,uy,w,n,lo[3];vector<uint16_t>mask;vector<Line> banks[3];vector<uint8_t>insideP,legalP;vector<int>link; 
 int id(P p)const{return (p.x-lx)*w+p.y-ly;}
 P pt(int id)const{return {id/w+lx,id%w+ly};}
 bool bounds(P q)const{return q.x>=lx&&q.x<=ux&&q.y>=ly&&q.y<=uy;}
 Line& bank(P p,int j){return banks[j][li(p,j)-lo[j]];}
 void build(int h){
  P pts[3]={{0,0},{B,0},{0,A}};if(h)for(auto &p:pts){p=mul({a+b,-b},p-P{B,0});p={p.x/c,p.y/c};}
  lx=ly=10000;ux=uy=-10000;for(auto p:pts){lx=min(lx,p.x-2);ly=min(ly,p.y-2);ux=max(ux,p.x+2);uy=max(uy,p.y+2);}
  w=uy-ly+1;n=w*(ux-lx+1);mask.assign(n,0);insideP.resize(n);legalP.resize(n);link.assign(n,-1);
  for(int j=0;j<3;j++){
   lo[j]=li({lx,ly},j);int nline=li({ux,uy},j)-lo[j]+1;
   banks[j].resize(nline);
   vector<int>start(nline,99999),end(nline,-99999);
   for(int i=0;i<n;i++){P p=pt(i),ph=phys(h,p);if(!inside(ph))continue;insideP[i]=1;legalP[i]=legal(ph);int q=li(p,j)-lo[j];start[q]=min(start[q],xx(p,j));end[q]=max(end[q],xx(p,j));}
   for(int k=0;k<nline;k++)if(end[k]>=start[k]){banks[j][k].lo=start[k];banks[j][k].sides.resize(end[k]-start[k]+1);}
  }
  if(!h){bank({0,0},0).full=1;bank({0,0},1).full=2;}
 }
}g[2];
int offid[2][12],eidx[2][12],partner[2][12],third[2][12];
struct Tm{int j,s,k;P u,w;int m1,m2,m3;};Tm tm[12];
long long val[2];int teeth[200];vector<array<P,3>> fixedT;
bool sep(const array<P,3>&q,const array<P,3>&r){
 int s=cr(q[1]-q[0],q[2]-q[0])>0?1:-1;
 for(int i=0;i<3;i++)if(max({s*cr(q[(i+1)%3]-q[i],r[0]-q[i]),s*cr(q[(i+1)%3]-q[i],r[1]-q[i]),s*cr(q[(i+1)%3]-q[i],r[2]-q[i])})<=0)return true;
 return false;
}
bool hitsFixed(int h,P p,Tm t){
 P x=phys(h,p+t.u),y=phys(h,p),z=phys(h,p+t.w);
 // All teeth are in the narrow band adjoining the sloped exterior.
 long long wall=(long long)A*x.x+(long long)B*x.y;
 if(max({wall,(long long)A*y.x+(long long)B*y.y,(long long)A*z.x+(long long)B*z.y})<(long long)c*A*B-2LL*a*b*c*c)return false;
 int from=max(0,min({x.y,y.y,z.y})*c/A-3);int to=min(c-1,max({x.y,y.y,z.y})*c/A+3);
 // Physical coordinates are multiplied by c; the tooth index is y/A.
 from=max(0,min({x.y,y.y,z.y})/A-4);to=min(c-1,max({x.y,y.y,z.y})/A+4);
 array<P,3> tr={x,y,z};for(int i=from;i<=to;i++){if(!sep(tr,fixedT[i])&&!sep(fixedT[i],tr))return true;}return false;
}
void setup(){
 g[0].build(0);g[1].build(1);
 for(int idx=0;idx<12;idx++){int j=idx/2,s=idx%2?1:-1,k=(j+s+6)%6;tm[idx]={j,s,k,-a*v[j],b*v[k],1<<(0+3*(s*(j<3?1:-1)<0)),1<<(1+3*(s*(k<3?1:-1)<0)),1<<(2+3*(s*(j<3?1:-1)>0))};}
 // E_i->E_{i+1} is positive boundary traversal; j=4 gives short A->apex->B and long B->A.
 for(int i=0;i<c;i++){P E=i*P{-b,a+b};P Y=E+P{-b,a+b};P q=Y+a*v[4];fixedT.push_back({phys(1,Y),phys(1,q),phys(1,E)});}
 for(int h=0;h<2;h++){
  auto &f=g[h];auto &otherf=g[1-h];for(int id=0;id<f.n;id++){
   if(!f.legalP[id])continue;P p=f.pt(id),q=other(h,p);if(otherf.bounds(q))f.link[id]=otherf.id(q);
   for(int k=0;k<12;k++){
    auto t=tm[k];P A0=p+t.u,B0=p+t.w;if(!f.bounds(A0)||!f.bounds(B0)||!f.legalP[f.id(A0)]||!f.legalP[f.id(B0)])continue;
    P ph=phys(h,p),pa=phys(h,A0),pb=phys(h,B0);
    bool on = h==1&&t.j==4&&t.s==1&&((long long)A*pa.x+(long long)B*pa.y==(long long)c*A*B)&&((long long)A*pb.x+(long long)B*pb.y==(long long)c*A*B);
    if(!on&&hitsFixed(h,p,t))continue;
    f.mask[id]|=1<<k;val[h]++;
   }
  }
 }
}
inline bool onbase(int h,P p,Tm t){
 if(h!=1||t.j!=4||t.s!=1)return false;P start=p+t.w;return (long long)(a+b)*start.x+(long long)b*start.y==0&&start.y%(a+b)==0;
}
bool arcs(int h,int id,P p,int k,bool mark){
 auto& f=g[h];auto&t=tm[k];int j=t.j,s=t.s,l=t.k;P A0=p+t.u,B0=p+t.w;
 auto use=[&](Frame &u,P a,P b,int tr,int bit){int axis=tr%3;auto&row=u.bank(a,axis);int x=min(xx(a,axis),xx(b,axis))-row.lo;
 if(mark){row.sides[x]|=bit;return true;}else return bool(row.ok[x]&bit);};
 if(!use(f,A0,p,j,t.m1)||!use(f,p,B0,l,t.m2))return false;
 if(h+s==1-h&&f.link[f.id(A0)]>=0){auto &u=g[1-h];P aa=u.pt(f.link[f.id(A0)]);return use(u,aa,aa+c*v[j],j,t.m3);}
 if(onbase(h,p,t)){P E=p+t.w;int i=E.y/(a+b);if(i>=0&&i<c){teeth[i]++;return true;}}
 P r=p+(t.u+t.w);return f.bounds(r)&&(f.mask[f.id(r)]&(1<<((k+6)%12)));
}
#include "fans.inc"
int main(int argc,char**argv){
 a=atoi(argv[1]);b=atoi(argv[2]);c=atoi(argv[3]);A=a*(a+2*b);B=b*(2*a+b);sz[0]=a;sz[1]=b;sz[2]=c;
 coin.resize(max({A,B,c*c})+1);coin[0]=1;for(int k=1;k<(int)coin.size();k++)for(int e:sz)if(k>=e&&coin[k-e])coin[k]=1;
 setup();initFans();
 vector<array<int,4>> ref;const char* path=getenv("REF");if(path){FILE *fin=fopen(path,"r");if(!fin)abort();int h,x,y,k;while(fscanf(fin,"%d%d%d%d",&h,&x,&y,&k)==4)ref.push_back({h,x,y,k});fclose(fin);}
 printf("initial %lld %lld\n",val[0],val[1]);fflush(stdout);
 for(int round=0;;round++){
  for(int h=0;h<2;h++)for(int j=0;j<3;j++)for(auto &r:g[h].banks[j])fill(r.sides.begin(),r.sides.end(),0);
  fill(teeth,teeth+c,0);
  for(int h=0;h<2;h++){auto&f=g[h];for(int i=0;i<f.n;i++)if(f.mask[i]){P p=f.pt(i);for(int m=f.mask[i];m;m&=m-1){int k=__builtin_ctz(m);arcs(h,i,p,k,true);}}}
  for(int h=0;h<2;h++)for(int j=0;j<3;j++)for(auto &r:g[h].banks[j])if(cyclic(r)){printf("IMPOSSIBLE outer line level=%d axis=%d\n",h,j);return 0;}
  fill(teeth,teeth+c,0);long long unchanged=0;
  for(int h=0;h<2;h++){auto&f=g[h];for(int i=0;i<f.n;i++)if(f.mask[i]){P p=f.pt(i);for(int m=f.mask[i];m;m&=m-1){int k=__builtin_ctz(m);if(arcs(h,i,p,k,false))unchanged++;else{f.mask[i]^=1<<k;val[h]--;}}}}
  int fd=fanSweep();unchanged-=fd;int count=0;for(int i=0;i<c;i++)if(teeth[i])count++;int bad=0;for(auto t:ref){int h=t[0],k=t[3];P p{t[1],t[2]};if(!g[h].bounds(p)||!(g[h].mask[g[h].id(p)]&(1<<k)))bad++;}printf("absent %d/%zu, fan removed %d; ",bad,ref.size(),fd);
  printf("sweep %d retained %lld %lld teeth %d of %d\n",round,val[0],val[1],count,c);fflush(stdout);if(count!=c){puts("IMPOSSIBLE outside base");return 0;}static long long prev=-1;if(prev==unchanged){if(getenv("DUMP")){for(int h=0;h<2;h++)for(int i=0;i<g[h].n;i++)if(g[h].mask[i]){P p=g[h].pt(i);printf("A %d %d %d %u\n",h,p.x,p.y,g[h].mask[i]);}}break;}prev=unchanged;
 if((round+1)==atoi(getenv("SWEEPS")?getenv("SWEEPS"):"100000")&&getenv("MASKOUT")){
  string path=getenv("MASKOUT"),tmp=path+".tmp";FILE *f=fopen(tmp.c_str(),"wb");fwrite(&round,4,1,f);
  for(int h=0;h<2;h++){int sizes[5]={g[h].lx,g[h].ux,g[h].ly,g[h].uy,g[h].w};fwrite(sizes,4,5,f);fwrite(g[h].mask.data(),2,g[h].mask.size(),f);}fclose(f);rename(tmp.c_str(),path.c_str()); return 0;
 }
 }
}
