#include <unordered_map>
struct KKey{uint64_t m[2];bool operator==(KKey const&z)const{return m[0]==z.m[0]&&m[1]==z.m[1];}};
struct HKey{size_t operator()(KKey k)const{return (k.m[0]*0x9e3779b97f4a7c15ULL)^(k.m[1]*0x2c1b3c6d98712563ULL);}};
using Mask=array<uint64_t,2>;
unordered_map<KKey,Mask,HKey> cacheFans;
int seq[4][6],ws[2][36],wl[2][36];
int ray(int h,int j){return seq[h+1][(j+6)%6];}
void initFans(){
 vector<pair<P,int>> vv;
 for(int h=-1;h<=2;h++){P e=h==-1?c*P{a+b,-b}:h==0?P{c*c,0}:h==1?c*P{a,b}:mul({a,b},{a,b});for(int j=0;j<6;j++){vv.push_back({e,6*(h+1)+j});e={-e.y,e.x+e.y};}}
 auto hp=[](P z){return z.y>0||(z.y==0&&z.x>=0);};
 sort(vv.begin(),vv.end(),[&](auto x,auto y){if(hp(x.first)!=hp(y.first))return hp(x.first)>hp(y.first);return cr(x.first,y.first)>0;});
 for(int i=0;i<24;i++)seq[vv[i].second/6][vv[i].second%6]=i;
 for(int h=0;h<2;h++)for(int k=0;k<12;k++){auto t=tm[k];int j=t.j,s=t.s,l=t.k;
  int eb[3][2]={{ray(h,j),ray(h+s,j)},{ray(h,l),ray(h,j+3)},{ray(h+s,j+3),ray(h,l+3)}};
  for(int z=0;z<3;z++){if(s<0)swap(eb[z][0],eb[z][1]);int d=(eb[z][1]-eb[z][0]+24)%24;if(!d||d>=12)abort();ws[h][k+12*z]=eb[z][0];wl[h][k+12*z]=d;}
 }}
Mask fanOK(Mask m,int typ,int present){
 KKey key={{m[0]|((uint64_t)typ<<40),m[1]|((uint64_t)present<<40)}};auto it=cacheFans.find(key);if(it!=cacheFans.end())return it->second;
 uint32_t step[24]={};
 for(int h=0;h<=1;h++){for(uint64_t k=m[h];k;k&=k-1){int z=__builtin_ctzll(k);step[ws[h][z]]|=1u<<wl[h][z];}
 if(present&(1<<h))for(int j=0;j<6;j++)step[ray(h,j)]|=1u<<12;}
 int lo=0,hi=48;
 if(typ){int bd[7][2]={{0,0},{ray(0,0),ray(0,3)},{ray(0,4),ray(0,1)},{ray(2,1),ray(2,4)},{ray(0,0),ray(0,1)},{ray(2,1),ray(0,3)},{ray(0,4),ray(2,4)}};
 lo=bd[typ][0];hi=bd[typ][1];if(hi<lo)hi+=24;}
 uint64_t reach[49]={};for(int k=hi;k>=lo;k--){reach[k]=1ULL<<k;for(unsigned v=step[k%24];v;v&=v-1){int z=k+__builtin_ctz(v);if(z<=hi)reach[k]|=reach[z];}}
 Mask ans={0,0};
 for(int h=0;h<2;h++)for(uint64_t r=m[h];r;r&=r-1){int u=__builtin_ctzll(r),p=ws[h][u],q=p+wl[h][u];
  if(!typ){if((reach[q]>>(p+24))&1)ans[h]|=1ULL<<u;}
  else{if(p<lo){p+=24;q+=24;}if(q<=hi&&((reach[lo]>>p)&1)&&((reach[q]>>hi)&1))ans[h]|=1ULL<<u;}
 }
 if(cacheFans.size()>200000)cacheFans.clear();cacheFans.emplace(key,ans);return ans;
}
int fanSweep(){
 int drop=0;
 for(int base=0;base<2;base++){auto &f=g[base];
 for(int id=0;id<f.n;id++){
  if(!f.legalP[id]||(base==1&&f.link[id]>=0))continue;
  int ids[2]={-1,-1};ids[base]=id;ids[1-base]=f.link[id];
  Mask m={0,0};int places[2][36],present=0;
  for(int h=0;h<2;h++)if(ids[h]>=0){present|=1<<h;auto &u=g[h];P w=u.pt(ids[h]);
   for(int k=0;k<12;k++){P pos[3]={w-tm[k].u,w,w-tm[k].w};for(int z=0;z<3;z++){int i=z*12+k;if(!u.bounds(pos[z]))continue;int d=places[h][i]=u.id(pos[z]);if(u.mask[d]&(1<<k))m[h]|=1ULL<<i;}}
  }
  if(!(m[0]|m[1]))continue;P p=phys(base,f.pt(id));bool diag=(long long)A*p.x+(long long)B*p.y==(long long)c*A*B;
  int typ=0;if(!p.y&&!p.x)typ=4;else if(!p.y&&diag)typ=5;else if(!p.x&&diag)typ=6;else if(!p.y)typ=1;else if(!p.x)typ=2;else if(diag)typ=3;
  auto a=fanOK(m,typ,present);for(int h=0;h<2;h++)for(uint64_t r=m[h]&~a[h];r;r&=r-1){int z=__builtin_ctzll(r),k=z%12;g[h].mask[places[h][z]]&=~(1<<k);val[h]--;drop++;}
 }}
 return drop;
}
