"""Verify a finite endpoint/overlap certificate over arbitrary triangle placements."""
import json
import sys
from collections import Counter
from fractions import Fraction as F
from functools import lru_cache
from math import gcd
from pathlib import Path


def plus(p,q):return p[0]+q[0],p[1]+q[1]
def minus(p,q):return p[0]-q[0],p[1]-q[1]
def prod(p,q):return p[0]*q[0]-p[1]*q[1],p[0]*q[1]+p[1]*q[0]+p[1]*q[1]
def turn(p):return -p[1],p[0]+p[1]
def det(p,q):return p[0]*q[1]-p[1]*q[0]
def norm(p):return p[0]*p[0]+p[0]*p[1]+p[1]*p[1]
def scalar(n,p):return n*p[0],n*p[1]
def canon(t):return tuple(sorted(t))
def orient(t):
    p,q,r=t
    return (p,q,r) if det(minus(q,p),minus(r,p))>0 else (p,r,q)
def edgeaxis(p,q):
    dx,dy=minus(q,p);x=F(dx).numerator*F(dy).denominator;y=F(dy).numerator*F(dx).denominator
    g=gcd(x,y); x//=g;y//=g
    return (-x,-y) if x<0 or (x==0 and y<0) else (x,y)
def crosses(t,v):
    for x,o in ((orient(t),v),(orient(v),t)):
        for j,p in enumerate(x):
            d=minus(x[(j+1)%3],p)
            if max(det(d,minus(u,p)) for u in o)<=0:return False
    return True


def verify(filename,packing):
    data=json.loads(Path(filename).read_text());a,b,c=data.get('sides',(33,7,37)); N=(a+2*b)*(2*a+b)
    B=b*(2*a+b);A=a*(a+2*b); board=((0,0),(B,0),(0,A))
    def decode(p):x,y,k=p;return F(x,c**k),F(y,c**k)
    def contained(p):return p[0]>=0 and p[1]>=0 and A*p[0]+B*p[1]<=A*B
    def signed_rows(t):
        t=orient(t)
        for j,p in enumerate(t):
            q=t[(j+1)%3];axis=edgeaxis(p,q)
            yield (p,axis),1
            yield (q,axis),-1
    @lru_cache(None)
    def unit(h,j):
        if h<0:z=prod(unit(h+1,0),(F(a+b,c),F(-b,c)))
        elif h>0:z=prod(unit(h-1,0),(F(a,c),F(b,c)))
        else:z=(1,0)
        for _ in range(j%6):z=turn(z)
        return z
    def triangle_variants(h,j):
        # Start one arbitrary side at the origin, use both signs, then locate
        # the third point by the cosine law and either sign of its altitude.
        u=unit(h,j);orth=(-u[0]-2*u[1],2*u[0]+u[1]) # sqrt(3) times +90-degree rotation
        for length,other,last in ((a,b,c),(a,c,b),(b,a,c),(b,c,a),(c,a,b),(c,b,a)):
            for sign in (1,-1):
                q=scalar(sign*length,u)
                off=F(sign*(length*length+other*other-last*last),2*length)
                high=F(a*b,2*length)
                for side in (1,-1):
                    r=plus(scalar(off,u),scalar(side*high,orth))
                    yield q,r
    # Finite row supports fix all their candidate tiles, regardless of orientation.
    weights=Counter();candidates=set()
    for x,y,k,h,j,w in data['rows']:
        p=decode((x,y,k));axis=edgeaxis((0,0),unit(h,j));weights[p,axis]+=w
        for q,r in triangle_variants(h,j):
            v=plus(p,q);t=plus(p,r)
            if contained(v) and contained(t) and contained(p):candidates.add(canon((p,v,t)))
    pair_coeff=Counter();rhs_pair=0
    for u,v,value in data['overlaps']:
        assert value<=0;u=canon(map(decode,u));v=canon(map(decode,v));assert u!=v and crosses(u,v)
        for t in (u,v):
            assert all(map(contained,t))
            assert sorted(norm(minus(t[j],t[(j+1)%3])) for j in range(3))==sorted((a*a,b*b,c*c))
            candidates.add(t);pair_coeff[t]+=value
        rhs_pair+=value
    def feature(t):
        for i,p in enumerate(t):
            for q in t:
                if q==p:continue
                for r in t:
                    if r==q or r==p:continue
                    hit=signatures.get((minus(p,q),minus(r,p)))
                    if hit is not None:
                        h,j,s=hit
                        rel=prod(minus(p,((0,0) if h==0 else (B,0))),unit(-h,0))
                        if any(Fraction(v).denominator!=1 for v in rel):return None
                        return (h,int(rel[0]),int(rel[1]),j,s)
        return None
    from fractions import Fraction
    signatures={(scalar(a,unit(h,j)),scalar(b,unit(h,j+s))):(h,j,s)
        for h in (0,1) for j in range(6) for s in (-1,1)}
    reference={canon(tuple(tuple(map(F,p)) for p in t)) for t in packing
               if all(F(x).denominator<=c for p in t for x in p)}
    reference={t for t in reference if feature(t) is not None}
    assert len(reference)==({3431:3399,5063:5059}[N])
    candidates.update(reference)
    import array,struct,os
    masks=[]
    if os.getenv('MASK'):
        with open(os.environ['MASK'],'rb') as f:
            iteration=struct.unpack('<i',f.read(4))[0]
            for h in (0,1):
                lx,ux,ly,uy,w=struct.unpack('<5i',f.read(20));assert w==uy-ly+1
                tab=array.array('H');tab.fromfile(f,(ux-lx+1)*w)
                if sys.byteorder!='little':tab.byteswap()
                masks.append((lx,ux,ly,uy,w,tab))
            assert not f.read(1)
        print('Applied',iteration+1,'complete pruning sweeps')
    target=sum(s*weights[key] for key,s in signed_rows(board))
    lam=data.get('global_weights',[0]*6);pop=data.get('pop',0)
    if any(lam):
        assert N==5063 and pop in (3741,3827)
        assert all(lam[h]+abs(lam[2+2*h+k])<=data['scale'] for h in (0,1) for k in (0,1))
        target+=sum(v*w for v,w in zip(lam,(N-pop,pop,0,-22,-86,43)))
    adjustment=0;scale=data['scale'];kept=0
    for t in candidates:
        tag=feature(t)
        if tag is None:continue
        h,x,y,j,s=tag
        if masks:
            lx,ux,ly,uy,w,bits=masks[h]
            if not(lx<=x<=ux and ly<=y<=uy and bits[(x-lx)*w+y-ly] & (1<<(2*j+(s==1)))):continue
        kept+=1
        cost=-scale if t in reference else scale
        tc=sum(s*weights[key] for key,s in signed_rows(t))+pair_coeff[t]+lam[h]+s*(-1)**j*lam[2+2*h+(s==1)]
        adjustment+=min(0,cost-tc)
    value=F(target+rhs_pair+adjustment,scale)
    retained=(N-value)//2
    print('N',N,'checked legal support',kept,'exact objective',value,
          'at least',len(reference)-retained,'omitted from canonical reference,',
          'at least',N-retained,'new placements in the two-translate case')
    if 'expected' in data:assert value==F(*data['expected'])
    return value

def rebuild_reference(sides, folder):
    sys.path.insert(0, str(folder.resolve()))
    if sides == (33, 7, 37):
        from check_3427 import build
        return build(folder)
    assert sides == (35, 13, 43)
    from check_inventory import replay
    _, placements, selected = replay(*sides, json.loads((folder / 'inventory_certificate.json').read_text())['5063'])
    return [[(F(x, 43), F(y, 43)) for x, y in placements[i]] for i in sorted(selected)]


if __name__ == '__main__':
    if not __debug__:
        raise SystemExit('Run without -O.')
    # Pass the sibling packing directory when the files are copied outside the repository.
    certpath = Path(sys.argv[1]); folder = Path(sys.argv[2]) if len(sys.argv)>2 else Path(__file__).resolve().parent / 'source' / 'packing'
    data = json.loads(certpath.read_text()); sides = tuple(data['sides'])
    reference = rebuild_reference(sides, folder)
    verify(certpath, reference)
