from pathlib import Path
import json
from fractions import Fraction
D=json.loads((Path(__file__).resolve().parent/'source'/'certificate_143.json').read_text())
p=lambda x,y:(x[0]+y[0],x[1]+y[1])
m=lambda x,y:(x[0]-y[0],x[1]-y[1])
sc=lambda k,x:(k*x[0],k*x[1])
def mul(x,y):return x[0]*y[0]-x[1]*y[1],x[0]*y[1]+x[1]*y[0]+x[1]*y[1]
out=[]
for patch in D['blocks']:
 V=patch['points'];O=V[0];tri=len(V)==3
 r,k=(patch['scale'],)*2 if tri else (patch['rows'],patch['cols'])
 u=sc(Fraction(1,r),m(V[1],O));v=sc(Fraction(1,k),m(V[-1],O))
 for i in range(r):
  for j in range(k-i if tri else k):
   z=p(p(O,sc(i,u)),sc(j,v));A=p(z,u);B=p(z,v);C=p(A,v)
   if tri or patch['diagonal']=='difference':
    out.append((z,A,B))
    if not tri or i+j+1<k:out.append((A,B,C))
   else:out.extend(((z,A,C),(z,B,C)))
log=Path(__import__('sys').argv[1]).read_text(); masks={}
for l in log.splitlines():
 if l.startswith('A '):
  _,h,x,y,mask=l.split();masks[int(h),int(x),int(y)]=int(mask)
U=((1,0),(0,1),(-1,1),(-1,0),(0,-1),(1,-1))
ok=[]
for tri in out:
 found=False
 for i in range(3):
  apex=tri[i]
  for k in (1,2):
   au=sc(Fraction(1,5),m(apex,tri[(i+k)%3]));bv=sc(Fraction(1,3),m(tri[(i+3-k)%3],apex))
   for h,g in ((0,(7,0)),(1,(5,3))):
    for j in range(6):
     if au!=mul(g,U[j]):continue
     for s in (-1,1):
      if bv!=mul(g,U[(j+s)%6]):continue
      q=sc(Fraction(1,7),apex) if h==0 else sc(Fraction(1,49),mul(m(apex,(273,0)),(8,-3)))
      if q[0].denominator==1 and q[1].denominator==1 and masks.get((h,int(q[0]),int(q[1])),0)&(1<<(2*j+(s==1))): found=True
 ok.append(found)
print('All verified placements retained:',sum(ok),'/',len(ok));assert all(ok) and len(ok)==143
