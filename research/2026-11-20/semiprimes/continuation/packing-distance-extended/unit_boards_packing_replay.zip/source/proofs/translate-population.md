# Population in individual translates of an extreme orientation lattice

Consider the primitive odd F2 board in the normalization of
[the whole-board theorem](https://github.com/DenisUkranian/erdos-634-tilings/blob/aff4ab39ec4365fd72f29aab9f7beb04adc817f4/research/2026-11-20/semiprimes/FULL_BOARD.md), with $R=\mathbb Z[\rho]$,
$z=(a+b\rho)/c$ and $E_h=z^hR$.
The three vertices of a tile of short height $h$ lie in one translate
of $E_h$, since its short-edge vectors lie in $E_h$.
Denote the number of tiles in such a translate $S$ by $m_h(S)$.

**Two-height theorem.** If the occupied short heights are 1 and 2, then

* every $m_1(S)$ is divisible by $c$;
* every $m_2(S)$ except $m_2(E_2)$ is divisible by $c$, and
  $m_2(E_2)\equiv N\pmod c$;
* every positive count in the divisible classes is at least $2c$.

For the first two mixed boards, at least 296 (respectively 344) tiles
belong specifically to the base translate $E_1$.
Of the $2c$ possible pairs of a height and a translate,
at most 43 of 74 can occur at 3431 and at most 56 of 86 at 5063.
These statements allow all T-junctions. They provide necessary
conditions on this orientation range.

## Cancellation separately in each translate

Fix $h$ and one translate $S$.
A maximal connected straight run of tile edges of height $h$ has,
on each bank, a partition into whole tile edges.
All endpoints on this run differ from either end by integer lengths,
because the three tile side lengths are integers. The same holds for a
one-bank run on the board boundary. Consequently every endpoint on
the run belongs to the same translate of $E_h$. Runs on the same
infinite supporting line may be treated individually.

For $h=1$, sum the positively oriented boundaries of the selected
tiles. Their long edges of height zero cancel in pairs inside the
board. Indeed at height zero all edges are long, the two partitions
of an interior run have equal steps $c$, and paired edges have the
same endpoints and hence the same $E_1$-translate. On the base the
$c$ teeth have consecutive long edges and share a translate. The
first contains zero, so this translate is $E_1$. Their combined
exterior contribution is the entire vector $B=c^2\in cE_1$, since
$c/z=a+b-b\rho$. Their other long edges have height 2 and length
$c$. On every run at height 1 belonging to $S$, the sum of the
selected short edges is the negative of the other incident sides,
all of which are long with length $c$. There is no exterior short
edge at this height. Thus the selected boundary is represented by a
closed chain of vectors in
$$
  c(E_1+E_2)\subset E_1.
$$

For $h=2$, all outward long edges of height 3 cancel internally in
the same way. The remaining long edges have height 1. On a run of
height 2 the selected short edges reduce to the opposite long edges
and the exterior boundary, if present. Both external sides of height
2 have all their subdivision endpoints in $E_2$, since $O,C,B\in E_2$
and all lengths in each boundary partition are integers. Thus for
$S\ne E_2$ the selected boundary is again a closed chain with vectors
in $c(E_1+E_2)\subset E_2$.

This lattice has index $c$ in either $E_1$ or $E_2$, by
[the median-path lattice calculation](https://github.com/DenisUkranian/erdos-634-tilings/blob/aff4ab39ec4365fd72f29aab9f7beb04adc817f4/research/2026-11-20/semiprimes/continuation/paths/TWO_PATHS.md). For example if
$z=\lambda/\eta$ is in lowest Eisenstein terms, then
$R+zR=\eta^{-1}R$ and $\lambda,\eta$ have norm $c$.
Each closed directed walk of the chain has all its vertices in one
translate of the index-$c$ lattice; the determinant area formula
gives its signed area in $(c\sqrt3/4)\mathbb Z$. A finite integral
closed chain is a sum of such walks, regardless of overlaps. Summing
and comparing with $m_h(S)ab\sqrt3/4$ proves divisibility since
$(ab,c)=1$. The exceptional residue follows by subtracting all
other classes from $N$.

To exclude the value $c$ in a divisible class, apply the
[common-sign line-count proof](https://github.com/DenisUkranian/erdos-634-tilings/blob/aff4ab39ec4365fd72f29aab9f7beb04adc817f4/research/2026-11-20/semiprimes/LINE_COUNTS.md) to just the short
edges assigned to it. On each of its height-$h$ runs the outer
length is zero, and all complementary edges have length $c$.
Summing these congruences gives $c\mid G_{h,S}$, where $G_{h,S}$
is the sum of the signs of its tiles. If $m_h(S)=c$, parity gives
$G_{h,S}=\pm c$. For each infinite supporting line, sum over those
runs belonging to $S$; the same congruence for short $a,b$-edges
and the same intersection bound as in that proof apply. This is
exactly the contradiction with $c$ common-sign tiles used there.
At $h=1$ there is no short-height exterior run for any translate.
At $h=2$ all the relevant exterior runs belong to the exceptional
translate.

## Count of occupied translates

The complete two-height vertex lattice is $E_1+E_2$. Relative to
either $E_h$ it has index $c$. There are consequently $2c$
available pairs of a short height and a translate. The base estimate
in [the phase-current theorem](https://github.com/DenisUkranian/erdos-634-tilings/blob/aff4ab39ec4365fd72f29aab9f7beb04adc817f4/research/2026-11-20/semiprimes/continuation/paths/SUPERLINEAR.md) still holds when
restricted to $E_1$: choose all the axis endpoint weights to be
zero outside $E_1$. Opposite contributions on a subdivided side
telescope; an entire length-$c$ edge of height 1 has equal endpoint
weights, since the translation by that vector preserves the class and
the phase. Along the short edges only tiles in $E_1$ contribute,
and all base teeth are present there. Thus its exact first two bounds
exceed $7c$; the translate divisibility gives $m_1(E_1)\ge8c$
on both boards.

Let $r_1,r_2$ count occupied translates at heights 1 and 2, and
let $j=N\bmod c$ lie in $[1,c-1]$. Both distinguished translates
occur. The full two-height current identity gives $G_1=c$; therefore
$n_1/c$ is odd since $c$ is odd and $G_1\equiv n_1\pmod2$.
It follows that
$$
 n_1\ge [9+2(r_1-1)]c,\qquad n_2\ge j+2(r_2-1)c.
$$
The controls $(N,c,j)=(3431,37,27),(5063,43,32)$ give
$r_1+r_2\le2+\lfloor(N-j-9c)/(2c)\rfloor=43,56$.

## One-sided extension

If 1 is the minimum occupied short height, the proof for each $E_1$
translate goes through unchanged in the presence of higher tiles.
The complementary edges on a height-1 run can only be long, so
additional heights create no new term. If 2 is the maximum occupied
short height, its proof works unchanged for every $S\ne E_2$ in the
presence of lower heights. Thus the translate divisibility, exclusion
of $m=c$ and, when the minimum is 1, the localized base phase bound
also apply in these larger families. The count of $2c$ available
translates above used both height bounds.

## Across the middle gap, without bounds on the other heights

Suppose short height 1 is absent. Take the complete gap interface
from $O$ to $B$ given by [the interface theorem](https://github.com/DenisUkranian/erdos-634-tilings/blob/aff4ab39ec4365fd72f29aab9f7beb04adc817f4/research/2026-11-20/semiprimes/INTERFACE.md).
It has $I\ge a+b$ steps in $czR$. Every vertex of the interface
belongs simultaneously to $E_0$ and $E_2$: the step $cz$ and the
rescaled step $c/z$ are both Eisenstein integers. Hence all $I$ forced
bank tiles on the low and high sides belong respectively to the
distinguished translates $E_0$ and $E_2$.

Apply the preceding extreme-height cancellation within the low region
(maximum short height 0) and the high region (minimum short height 2).
The outward long edges on the gap either match across it or cancel
in pairs internally. No outward edge from a nondistinguished
translate can lie on the gap. The original exterior short runs at the
relevant height belong to the distinguished translate as well.
Thus every nondistinguished translate at either height has population
divisible by $c$. The full-board divisibility gives
$m_0(E_0)\equiv0$ and $m_2(E_2)\equiv N\pmod c$.

The two distinguished translates satisfy the following stronger bounds.

| $N$ | Low count $m_0(E_0)$ | High count $m_2(E_2)$ |
|---:|---:|---:|
| 3431 | $\ge I+1145397/10001$, hence $\ge185$ | $\ge I+1197203/10001$, hence $\ge175$ |
| 5063 | $\ge I+1299643/10001$, hence $\ge215$ | $\ge I+1308911/10001$, hence $\ge204$ |

To compute the boundary current of a bank use physical coordinates
divided by $z^2$ for the high region and complex-conjugated physical
coordinates for the low region. The selected short axes now belong to
$R$ and the selected region is on the left going from $O$ to $B$.
A gap step is $c\bar z\rho^j$ in these coordinates, with its obtuse
apex at displacement $a\rho^j$ from its start: this follows from the
two explicit bank placements of the interface theorem. For the upper
bank the net inventory of gap directions is $a$ steps $j=0$ and $b$
steps $j=-1$, counting each direction minus its opposite; for the
lower bank conjugation turns the second direction into $j=1$.

Write $\phi(x+y\rho)=bx+(a+b)y\pmod c$ on integral points. Every
gap vertex has phase zero. Indeed $c\bar z=(a+b)-b\rho$ and
$c\bar z\rho=b+a\rho$ both have phase zero, by the norm equation.
For three odd functions $f_i$ on $\mathbb Z/c\mathbb Z$, $i$ modulo
3, assign the endpoint weight $f_i(\phi(P))$ on the short axis
$\rho^i$ when $P\in R$, and zero otherwise. Use the end weight minus
the start weight on oriented segments. Weights on other axes are zero.
This definition respects all subdivisions. Every long edge on a
selected short axis contributes zero, since its length is $c$.
Consequently only short-height tiles in the indicated distinguished
translate have any contribution.

In the above coordinate frame, for $s=\pm1$ let $W(j,s,r)$ be the
CCW weight of the tile with its short segments
$a\rho^j,b\rho^{j+s}$ in that order at an apex of phase $r$;
one multiplies the sum along these two segments by $s$ to obtain
the positive boundary orientation. A gap tooth has weight
$w_j=W(j,-1,\phi(a\rho^j))$. Oddness gives $w_{j+3}=-w_j$.
Hence the gap teeth have total current
$G=aw_0+bw_{-1}$ in the high case and $G=aw_0+bw_1$ in the low
case, regardless of the number or order of detours. Every other
tile with $s=-1$ is paired across its long edge: no tile has short
height 1, and the two sides of any interior height-1 run partition
it into the same full lengths $c$. The same-height partner is the
half-turn mate and its apex is displaced by
$-a\rho^j+b\rho^{j-1}$. The pair belongs to the same translate.

The current on the boundary of the entire selected region is $H=0$
in the low case: the gap itself has a different axis height and the
base vector has phase-zero endpoints. In the high case the exterior
chain $B\to C\to O$ has
$H=f_1(\phi(C))-f_0(\phi(C))$, where $C=(ap,0)$ and
$B=(ap,-bq)$ has phase zero. Again the gap has zero edge current
on this boundary; the tooth contributions come from their short sides.

The [integer tables](gap_translate_weights.json) provide odd functions
and an integer $D>0$ for each case. The [exact checker](check_gap_translates.py)
checks $W(j,+1,r)\le D$ at all phases and the sum over a paired
$s=-1$ tile and its mate is at most $2D$. This gives
$H-G\le D(m-I)$. Substituting the four exact bounds above and the
translate congruences proves the rounded counts. All steps apply to
arbitrary tile orientations within the two parts of the gap tiling.
