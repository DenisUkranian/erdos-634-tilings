# Placement changes on the 3431 and 5063 unit boards

The question is whether the F2 triangle can be tiled by congruent copies of a triangle with side lengths $(a,b,c)$ and a 120-degree angle opposite $c$. For 3431 the lengths are $(33,7,37)$, and for 5063 they are $(35,13,43)$. The reference packings cover all but four tile areas. This package bounds the distance from each specified packing to every possible complete tiling. It allows arbitrary rotations, reflections and partial edge contacts in the complete tiling.

| Unit count | Reference count | At least this many original placements must be omitted | At least this many new placements must be used |
|---:|---:|---:|---:|
| 3431 | 3427 | 70 | 74 |
| 5063 | 5059 | 82 | 86 |

In the two-class subproblems the actual certified lower bounds on new placements are 75 and 90. For the unrestricted result the threshold is 74 or 86 when a new height or translate occurs. In each case omissions equal additions minus four.

These bounds concern individual placements, including their positions. Neither bound decides existence.

## Why two translates suffice for testing a proposed small change

Use axial coordinates in the basis $(1,\rho)$, where $\rho=e^{i\pi/3}$, and put $R=\mathbb Z[\rho]$, $z=(a+b\rho)/c$. The board vertices are $0,H=b(2a+b),V=a(a+2b)\rho$. The two axes through zero have height zero. A heading of height $h$ is $\rho^jz^h$. Both short sides of each tile have the same height. The opposite side has height one greater or smaller. The outside side $HV$ has height two. The distinguished short-height translates are $R$ at zero and $H+zR$ at one.

We use the project's [whole-board population theorem](source/proofs/height-population.md), [line-count lemma](source/proofs/line-counts.md) and [extreme-translate theorem](source/proofs/translate-population.md). Some of those notes number the levels in reverse order. In the frame here every occupied height other than zero has population a multiple of $c$ of at least $2c$. If the only heights are zero and one, each other translate of either height also costs at least $2c$. The exceptional translate in this assertion is the exterior lattice $R$, which is one of our two allowed translates.

At 5063 all 5059 reference tiles are in the two distinguished classes. A tiling with fewer than 86 placements outside that packing can contain no new short height, and then no new translate. It contains both reference heights because removing either reference population would exceed the change budget.

At 3431 exactly 3399 reference placements belong to the distinguished classes. The [position-and-height restriction](source/proofs/outliers.md) excludes twenty outliers from any full tiling. Retaining even one of the other eight requires at least 290 reference omissions. Thus a tiling with fewer than 74 new placements retains none of the 28 outliers. The population and translate restrictions then force the same two-class model. The [underlying phase theorem](source/proofs/branches.md) is also included.

For reproducibility, the verifier expands the source construction of each packing and recovers these two-class subsets from the vertex coordinates. It tests an actual $a$-edge and its adjacent $b$-edge against the twelve directed templates per height and checks the integral coordinates of the obtuse vertex in the stated translate.

## A finite inequality for the remaining placements

Orient all triangle boundaries counterclockwise. At a specified point and unoriented line direction, count $+1$ for the starting point of an oriented edge and $-1$ for its end. In a completed tiling the counts sum to the outside counts at each such row. Subdividing an interval at a T-junction introduces opposite endpoint contributions and preserves the identity.

Give one canonical reference tile cost $-1$ and every other unit placement cost $+1$. For a tiling with $R_0$ retained reference placements the total cost is $N-2R_0$. The two JSON certificates give scaled integer weights $y$ on endpoint rows and nonpositive weights $w$ on pairs of overlapping candidate interiors. Each overlap can use at most one of its two placements. Write $b$ for the outside endpoint demands and $C_t$ for the signed cost of placement $t$, using the certificate scale. Let $p_t$ be its endpoint-weight sum plus the weights of all overlaps incident to it. Every zero-one tiling selection satisfies

$$
  \operatorname{cost}\cdot\operatorname{scale}
  \ \ge\ y^Tb+\sum w+\sum_t\min(0,C_t-p_t).
$$

The final sum requires just the reference triangles, the triangles in overlap pairs and the triangles incident to a nonzero endpoint row. All remaining coefficients have positive cost and zero weight. For each row the checker fixes the point and direction, chooses all six ordered assignments of the three lengths and both signs of the direction and altitude, and constructs the third vertex by the cosine law. It checks containment, the two-translate restriction, and every claimed overlap with exact rational arithmetic. The term for an impossible placement can be dropped because its selection variable is zero.

## Additional geometric pruning for 5063

The two outer axes require whole boundary intervals. The side $HV$ has length $c^2$ and height two. With only short heights zero and one, each of its $c$ successive intervals of length $c$ is the long side of a unique height-one tile. The opposite choice of hand would have short height three. All 43 teeth are therefore fixed. A proposed placement overlapping such a tooth can be removed.

The scan enumerates all twelve templates at every possible integral obtuse vertex in each of the two translates. It clips them to the three board half-planes. A vertex lying on an outside side splits that side into lengths in the additive semigroup generated by $a,b,c$. Every such boundary vertex is an endpoint in the boundary partition, since a boundary tile edge passing through the point would occupy the whole interior half-neighborhood.

On a maximal straight run of tile sides the two banks partition the same segment into whole edges. Every endpoint offset along the run is consequently integral. A long side at the other short height can meet a short side there only if its endpoints belong to that height's translate. If no short side can meet this run, both partitions use only whole $c$-edges and agree from their common endpoint. Except for a boundary tooth, the tile needs its half-turn mate across the entire edge. The hand of the mate is fixed by the two allowed short heights. The same argument applies at either external height where short sides are absent.

For every line carrying possible short edges, the checker records the surviving whole intervals on each bank. On an internal line, a selected interval must belong to a pair of entire bank partitions with a common start and a common end. The dynamic program in [dp.inc](dp.inc) tracks the two frontiers and advances the bank behind. Their difference is at most $c$. Forward and backward reachability retains only intervals on a complete pair of partitions. On an outside axial line it requires a partition of the entire side by the inner bank. Missing support for either short edge, the long edge or its required mate eliminates a placement.

At every candidate vertex the [angle check](fans.inc) also requires that its tile sector occur in an angular partition of the board's local sector. The 24 oriented rays at heights $-1,0,1,2$ are sorted by exact determinants. The allowed sectors come from the currently surviving placements anchored at that vertex. The scan also permits a straight half-plane sector along each direction of an allowed short-height lattice containing the vertex. This includes every genuine T-junction. Indeed, if neither bank of that straight run can use short sides, the two banks match into entire long edges, leaving no place for a tile vertex in their relative interiors. At a T-junction on a mixed run, all endpoints there are integer offsets on the same line and hence belong to the translate of its short sides. These tests can keep extra placements. Each deletion uses a necessary condition.

The 5063 certificate uses only the first 25 complete sweeps. The complete 143-tile positive control in the accompanying staircase certificate survives all sweeps to stabilization. The Python price checker regenerates the placements touched by its nonzero weights independently of the C++ placement enumeration and checks the survivor masks in the two respective integer frames.

## Replay

Run `python3 replay.py` in this directory on little-endian Linux with a C++17 compiler available as `c++`. The replay uses the Python standard library and temporary files for the compiled checker and the mask. It checks the file digests before the computation. No linear-programming solver is needed. The displayed rational certificate values are checked exactly before reporting the integer bounds.

The reference constructors and supporting project proofs are bundled under `source/`. The packings come from the [public semiprime research directory](https://github.com/DenisUkranian/erdos-634-tilings/tree/main/research/2026-11-20/semiprimes/continuation/packing). The translate-population note was distributed in the project archive `Erdos634_3431_5063_2026-11-20.zip`. The replay checks the new finite computations. It takes the stated population lemmas as mathematical inputs. This record has received internal checks and has no independent referee or proof-assistant verification.
