"""Verify the two conditional inequalities and the unrestricted bound arithmetic."""
import hashlib
import json
from fractions import Fraction
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

root=Path(__file__).resolve().parent
if not __debug__:
    raise SystemExit('Run with Python assertions enabled.')
for entry in (root/'SHA256SUMS').read_text().splitlines():
    digest,name=entry.split('  ',1)
    if hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest:
        raise ValueError('Digest mismatch: '+name)
subprocess.run([sys.executable,root/'source/proofs/verify.py'],check=True)
if sys.byteorder!='little':
    raise SystemExit('The binary mask format in this replay requires a little-endian host.')
with TemporaryDirectory() as tmp:
    build=Path(tmp)
    exe=build/'scan'
    subprocess.run([os.getenv('CXX','c++'),'-O3','-std=c++17',root/'scan.cpp','-o',exe],check=True)
    env=os.environ.copy()
    for key in ('MASK','MASKOUT','SWEEPS','REF','DUMP'):env.pop(key,None)
    with (build/'control.log').open('w') as out:
        subprocess.run([exe,'5','3','7'],env=dict(env,DUMP='1'),stdout=out,check=True)
    subprocess.run([sys.executable,root/'positive_control.py',build/'control.log'],check=True)
    mask=build/'5063.mask'
    subprocess.run([exe,'35','13','43'],env=dict(env,MASKOUT=str(mask),SWEEPS='25'),check=True)
    for n,threshold,fullref,expected in [(3431,74,3427,70),(5063,86,5059,82)]:
        cert=root/(str(n)+'.json')
        subprocess.run([sys.executable,root/'verify_prices.py',cert],env=(dict(env,MASK=str(mask)) if n==5063 else env),check=True)
        value=Fraction(*json.loads(cert.read_text())['expected'])
        max_retained=(n-value)//2
        minimum_new=min(threshold,n-max_retained)
        omitted=minimum_new-(n-fullref)
        assert omitted==expected
        print(n,'at least',omitted,'reference omissions and',minimum_new,'new placements',flush=True)
