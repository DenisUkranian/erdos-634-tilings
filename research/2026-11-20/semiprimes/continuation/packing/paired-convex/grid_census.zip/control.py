import json
from fractions import Fraction as F
from collections import Counter,defaultdict
from math import gcd,lcm
from pathlib import Path
from twogridconvex import check
from uniformconvex import det,norm,sub,edges

check(901,'case.json',33,7,37)
x=json.loads(Path('twogrid901_1.json').read_text());d=lcm(37,x['denominator'])
cells=[[(p[0]*(d//x['denominator']),p[1]*(d//x['denominator']))for p in t]for t in x['triangles']]
boundary=[(a*(d//37),b*(d//37))for a,b in ((0,0),(1320,-231),(1369,0),(1089,231))]
assert len(cells)==2
for t in cells:
 assert sorted(norm(sub(q,p))for p,q in edges(t))==[(d*k)**2 for k in (7,33,37)]
events=defaultdict(Counter)
for w,t in [(1,t)for t in cells]+[(-1,boundary)]:
 if sum(det(p,q)for p,q in edges(t))<0:t=t[::-1]
 for p,q in edges(t):
  e=sub(q,p);g=gcd(*e);axis=(e[0]//g,e[1]//g)
  if axis<(0,0):axis=(-axis[0],-axis[1])
  row=events[axis,det(axis,p)];row[p]+=w;row[q]-=w
assert all(not any(e.values())for e in events.values())
print('Two-grid control: exact metric and boundary verification succeeded.')
