#include <algorithm>
#include <array>
#include <fstream>
#include <iostream>
#include <map>
#include <queue>
#include <vector>
#include <set>
#include <cmath>
using namespace std;
using Z=long long;struct P{Z x,y;auto operator<=>(const P&)const=default;};
P operator-(P a,P b){return {a.x-b.x,a.y-b.y};}
Z det(P a,P b){return a.x*b.y-a.y*b.x;}Z orient(P a,P b,P c){return det(b-a,c-a);}
using Poly=vector<P>;
Poly hull(Poly s){
 sort(s.begin(),s.end());s.erase(unique(s.begin(),s.end()),s.end());Poly h;
 for(auto p:s){while(h.size()>1&&orient(h[h.size()-2],h.back(),p)<=0)h.pop_back();h.push_back(p);}
 int mid=h.size();for(int i=s.size()-2;i>=0;i--){auto p=s[i];while((int)h.size()>mid&&orient(h[h.size()-2],h.back(),p)<=0)h.pop_back();h.push_back(p);}h.pop_back();return h;
}
Z area(const Poly&t){Z a=0;for(int i=0;i<t.size();i++)a+=det(t[i],t[(i+1)%t.size()]);return a;}
struct Box{Z l,r,b,h;};
Box box(const Poly&t){Box x={t[0].x,t[0].x,t[0].y,t[0].y};for(auto p:t){x.l=min(x.l,p.x);x.r=max(x.r,p.x);x.b=min(x.b,p.y);x.h=max(x.h,p.y);}return x;}
bool far(const Box&a,const Box&b){return a.r<=b.l||a.l>=b.r||a.h<=b.b||a.b>=b.h;}
bool sep(const Poly&t,const Poly&u){for(int i=0;i<t.size();i++){auto p=t[i],e=t[(i+1)%t.size()]-p;bool yes=true;for(auto v:u)if(det(e,v-p)>0){yes=false;break;}if(yes)return true;}return false;}
int a,b,c,N;Z unit,hole;vector<Poly> tiles;vector<Box> boxes;vector<vector<int>> G;
struct Node{int n;Poly h;vector<bool> cells;bool operator<(Node const &u)const{return n>u.n;}};
set<Poly> visited,entered;priority_queue<Node> work;long long attempts;
void close(Poly h,vector<bool>s){
 if(!entered.insert(h).second)return;attempts++;int n=count(s.begin(),s.end(),true);bool changed;
 do{auto ext=h;changed=false;auto b=box(h);
  for(int j=1;j<N;j++)if(!s[j]&&!far(b,boxes[j])&&!sep(h,tiles[j])&&!sep(tiles[j],h)){
   s[j]=true;n++;ext.insert(ext.end(),tiles[j].begin(),tiles[j].end());
  }
  auto p=hull(ext);if(p!=h){changed=true;h=move(p);if(!entered.insert(h).second)return;}
 }while(changed);
 if(area(h)!=(n-1)*unit+hole)return;
 if(!visited.insert(h).second)return;
 cout<<(n-1+hole/unit)<<' '<<h.size();for(auto p:h)cout<<' '<<p.x<<' '<<p.y;cout<<'\n';
 work.push({n,move(h),move(s)});
}
int main(int argc,char**v){ifstream f(v[1]);f>>a>>b>>c>>N;unit=Z(a)*b*c*c;int limit=atoi(v[2]);
 for(int i=0;i<N;i++){int k;f>>k;Poly t(k);for(auto&p:t)f>>p.x>>p.y;if(area(t)<0)reverse(t.begin(),t.end());tiles.push_back(t);boxes.push_back(box(t));f>>k;G.emplace_back(k);for(auto&j:G.back())f>>j;}
 hole=area(tiles[0]);vector<bool>s(N);s[0]=true;close(hull(tiles[0]),s);
 int done=0;while(!work.empty()&&done<limit){auto state=work.top();work.pop();done++;if(done%1000==0){cout.flush();cerr<<done<<" visited "<<visited.size()<<" pending "<<work.size()<<" tested "<<attempts<<" area "<<state.n-1+hole/unit<<endl;}
  set<int>adj;for(int i=0;i<N;i++)if(state.cells[i])for(int j:G[i])if(!state.cells[j])adj.insert(j);
  for(int j:adj){auto h=state.h;h.insert(h.end(),tiles[j].begin(),tiles[j].end());close(hull(h),state.cells);}
 }cout.flush();cerr<<done<<" done, unique "<<visited.size()<<" pending "<<work.size()<<endl;
}
