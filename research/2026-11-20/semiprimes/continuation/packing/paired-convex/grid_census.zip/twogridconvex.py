from uniformconvex import *
from functools import cache
from fractions import Fraction as F
from collections import defaultdict
from itertools import combinations
from math import ceil
import sys
def check(n,file,a,b,c):
    model=json.load(open(file));U=[tuple(sorted(tuple(v)for v in t))for t in model['U']];M=model['matching'];planes={};result=seen=qualified=valid=0
    @cache
    def templates(A):
        L=isqrt(norm(A));assert L*L==norm(A);out={}
        for l,s,h in permutations((a,b,c)):
            for sg in (1,-1):
                E=scale(F(c*l,L),A);G=mul(scale(F(c,L),A),(F(l*l+s*s-h*h-sg*a*b,2*l),F(sg*a*b,l)))
                dirs=tuple(sorted(q if q>(0,0) else (-q[0],-q[1])for q in (E,G,sub(E,G))))
                out[dirs]=(E,G)
        return [(k,*v)for k,v in out.items()]
    class Grid:
        def __init__(self,O,E,G):
            self.O=O;self.E=E;self.G=G
            self.d=lcm(*(v.denominator for v in (*E,*G)));self.e=tuple(map(int,scale(self.d,E)));self.g=tuple(map(int,scale(self.d,G)));self.D=det(self.e,self.g)
            self.orient=1 if self.D>0 else -1;self.D=abs(self.D);self.fam={axis(self.g):0,axis(self.e):1,axis(sub(self.e,self.g)):2};self.cache={}
        def co(self,p):
            r=self.cache.get(p)
            if not r:
                z=sub(p,self.O);r=(self.orient*self.d*det(z,self.g),self.orient*self.d*det(self.e,z));self.cache[p]=r
            return r
        def node(self,p):u,v=self.co(p);return u%self.D==0 and v%self.D==0
        def plane(self,t):
            coords=[self.co(p)for p in t];lat=[m%self.D==v%self.D==0 for m,v in coords];supports=[]
            for u,v in edges(coords):
                supports.append(any(u[j]==v[j]and u[j]%self.D==0 for j in range(2))or(sum(u)==sum(v)and sum(u)%self.D==0))
            return (coords,lat,supports)
        def fill(self,t):
            t=list(t)
            if sum(det(p,q) for p,q in edges(t))<0:t.reverse()
            def inside(p):return all(det(sub(q,u),sub(p,u))>=0 for u,q in edges(t))
            B=[(int(m//self.D),int(v//self.D))for m,v in (self.co(p)for p in t)]
            def world(z):return add(self.O,add(scale(z[0],self.E),scale(z[1],self.G)))
            out=[]
            for i in range(min(p[0]for p in B),max(p[0]for p in B)):
                for j in range(min(p[1]for p in B),max(p[1]for p in B)):
                    for w in [[(i,j),(i+1,j),(i,j+1)],[(i+1,j),(i+1,j+1),(i,j+1)]]:
                        v=list(map(world,w));pt=tuple(sum(z[k]for z in v)/3 for k in (0,1))
                        if inside(pt):out.append(tuple(sorted(v)))
            return out
    allplanes=defaultdict(list)
    def grid(O,dirs,E,G):
        for p in allplanes[dirs]:
            if p.node(O):return p
        p=Grid(O,E,G);allplanes[dirs].append(p);return p
    def save(t,g1,g2,s1,s2,ar,idx):
        nonlocal valid,result
        def inside(p):return all(det(sub(q,u),sub(p,u))>=0 for u,q in edges(t))
        cells=g1.fill(s1)+g2.fill(s2);assert len(set(cells))==len(cells)==ar;new=set(cells)
        full=[cell for cell in U if not all(inside(p)for p in cell)]+cells
        assert len(full)==model['area'];valid+=1
        if not all(U[i]in (S:=set(full))or U[j]in S for i,j in M):return
        q=lcm(*(F(z,c).denominator for u in full for p in u for z in p));tri=[[[int(F(z,c)*q)for z in p]for p in u]for u in full]
        result+=1;fname='twogrid%d_%d.json'%(n,result);Path(fname).write_text(json.dumps({'denominator':q,'triangles':tri}));print('YES',n,idx,ar,fname,flush=True)
    for idx,line in enumerate(open('convex%d.out'%n)):
        ar,k,*v=map(int,line.split());t=list(zip(v[::2],v[1::2]));d=[axis(sub(y,x))for x,y in edges(t)]
        grids=set()
        for i,O in enumerate(t):
            for dirs,E,G in templates(d[i]):
                q=grid(O,dirs,E,G)
                if d[i-1] in q.fam:grids.add(q)
        stats={g:g.plane(t)for g in grids}
        for g1,g2 in combinations(grids,2):
            co,nodes,streets=stats[g1];c2,n2,s2=stats[g2]
            if not all(x or y for x,y in zip(nodes,n2))or not all(x or y for x,y in zip(streets,s2)):continue
            qualified+=1
            def levels(row,j):return row[j]if j<2 else sum(row)
            for sa in g1.fam.keys()&g2.fam.keys():
                z=[levels(v,g1.fam[sa]) for v in co];iz=g1.D
                for step in range(min(z)//iz+1,(max(z)+iz-1)//iz):
                    cut=step*iz;sign=[s-cut for s in z]
                    for side in (1,-1):
                        sg=[side*x for x in sign]
                        if any((v>=0 and not nodes[i])or(v<=0 and not n2[i])for i,v in enumerate(sg)):continue
                        if any((max(v,sg[(i+1)%k])>0 and not streets[i])or(min(v,sg[(i+1)%k])<0 and not s2[i])for i,v in enumerate(sg)):continue
                        cand={};ok=True
                        for i,x in enumerate(sg):
                            j=(i+1)%k;y=sg[j]
                            if x*y>=0:continue
                            den=x-y
                            for coord,plane in ((co,g1),(c2,g2)):
                                if any((x*coord[j][u]-y*coord[i][u])%(den*plane.D) for u in range(2)):ok=False;break
                            if not ok:break
                            cand[i]=tuple(F(x*t[j][u]-y*t[i][u],den)for u in range(2))
                        if not ok:continue
                        A=[];B=[]
                        for i,x in enumerate(sg):
                            if x>=0:A.append(t[i])
                            if x<=0:B.append(t[i])
                            if i in cand:A.append(cand[i]);B.append(cand[i])
                        save(t,g1,g2,A,B,ar,idx);seen+=1
                        if result:return
        if idx%1000==999:print('progress',n,idx+1,'compatible plane pairs',qualified,'geometric splits',valid,flush=True)
    print('DONE',n,idx+1,'compatible plane pairs',qualified,'geometric splits',valid,'successes',result,flush=True)
if __name__=='__main__':
 n=int(sys.argv[1]);check(n,'pair_all.json' if n==3431 else 'pair5063.json',*( (33,7,37)if n==3431 else(35,13,43)))
