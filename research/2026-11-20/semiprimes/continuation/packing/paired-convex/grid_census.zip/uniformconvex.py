from fractions import Fraction as F
from pathlib import Path
from math import gcd,isqrt,lcm
from itertools import permutations
from collections import Counter
import json
def sub(p,q):return p[0]-q[0],p[1]-q[1]
def add(p,q):return p[0]+q[0],p[1]+q[1]
def det(p,q):return p[0]*q[1]-p[1]*q[0]
def norm(p):return p[0]**2+p[0]*p[1]+p[1]**2
def mul(p,q):x,y=p;u,v=q;return x*u-y*v,x*v+y*u+y*v
def scale(k,p):return (k*p[0],k*p[1])
def edges(p):return zip(p,p[1:]+p[:1])
def axis(p):
 d=gcd(p[0],p[1]);x,y=p[0]//d,p[1]//d
 return (x,y) if (x,y)>(0,0) else (-x,-y)
def solve(n,file,a,b,c):
 model=json.load(open(file));U=[tuple(sorted(tuple(x)for x in t))for t in model['U']];uindex=set(U);built=0;total=0;cand=0;simple=Counter();axes={};Asiz=Counter()
 for line in open('convex%d.out'%n):
  parts=list(map(int,line.split()));ar,k,*points=parts;t=list(zip(points[::2],points[1::2]));total+=1;simple[k]+=1
  ds=[axis(sub(v,u))for u,v in edges(t)];ss=set(ds)
  if len(ss)>3:continue
  A=ds[0];L=isqrt(norm(A));assert L*L==norm(A)
  if A not in axes:
   planes=[]
   for l,s,h in permutations((a,b,c)):
    for sg in (1,-1):
     E=scale(F(c*l,L),A)
     G=mul(scale(F(c,L),A),(F(l*l+s*s-h*h-sg*a*b,2*l),F(sg*a*b,l)))
     den=lcm(*(v.denominator for v in (*E,*G)));ei,gi=tuple(map(int,scale(den,E))),tuple(map(int,scale(den,G)));D=det(ei,gi)
     planes.append((E,G,den,ei,gi,D,{axis(ei),axis(gi),axis(sub(ei,gi))}))
   axes[A]=planes
  for E,G,den,ei,gi,D,dirs in axes[A]:
   if not ss<=dirs:continue
   O=t[0]
   def lattice(p):
    z=scale(den,sub(p,O));m,mm=divmod(det(z,gi),D);q,qq=divmod(det(ei,z),D)
    if mm or qq:return None
    return (m,q)
   lp=list(map(lattice,t))
   if None in lp:continue
   cand+=1;Asiz[ar]+=1
   def isinside(p):return all(det(sub(v,u),sub(p,u))>=0 for u,v in edges(t))
   inside={i for i,v in enumerate(U) if all(isinside(z)for z in v)}
   okold={i for i in inside if all(lattice(z)!=None for z in U[i]) and {axis(sub(e,f)) for e,f in edges(U[i])}<=dirs}
   if any(i in inside-okold and j in inside-okold for i,j in model['matching']):continue
   def toWorld(z):return add(O,add(scale(z[0],E),scale(z[1],G)))
   points=[]
   for i in range(min(p[0]for p in lp),max(p[0]for p in lp)):
    for j in range(min(p[1]for p in lp),max(p[1]for p in lp)):
     for w in [[(i,j),(i+1,j),(i,j+1)],[(i+1,j),(i+1,j+1),(i,j+1)]]:
      v=list(map(toWorld,w));center=tuple(sum(z[k]for z in v)/3 for k in (0,1))
      if isinside(center):points.append(v)
   assert len(points)==ar
   result=[t for i,t in enumerate(U)if i not in inside]+points
   assert len(result)==model['area']
   q=lcm(*(F(z,c).denominator for t in result for v in t for z in v))
   out=[[[int(F(x,c)*q),int(F(y,c)*q)]for x,y in t]for t in result]
   fname='uniform%d_%d.json'%(n,built);Path(fname).write_text(json.dumps({'denominator':q,'triangles':out}))
   print('CONSTRUCTION',fname,ar);built+=1
   if built>=1:return
 print(n,'complete convex sets assessed',total,'corners',simple,'legal uniform grids',cand,'areas',Asiz,'solutions',built,flush=True)
if __name__=='__main__':
 solve(3431,'pair_all.json',33,7,37)
 solve(5063,'pair5063.json',35,13,43)
