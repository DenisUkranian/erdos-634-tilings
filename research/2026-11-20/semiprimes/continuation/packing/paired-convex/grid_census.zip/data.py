from pathlib import Path
import json
from collections import defaultdict
from math import gcd
for n,fn,sides in [(3431,'pair_all.json',(33,7,37)),(5063,'pair5063.json',(35,13,43))]:
 data=json.load(open(fn));key=lambda t:tuple(sorted(map(tuple,t)))
 U=[key(t) for t in data['U']];h=data['H'];poly=[h]+U;bc=defaultdict(list)
 for i,t in enumerate(poly):
  for a,b in zip(t,t[1:]+t[:1]):
   a,b=tuple(a),tuple(b);dx=b[0]-a[0];dy=b[1]-a[1];g=gcd(dx,dy);d=(dx//g,dy//g)
   if d<(0,0):d=tuple(-z for z in d)
   bc[d,d[0]*a[1]-d[1]*a[0]].append((min(a,b),max(a,b),i))
 G=[set()for t in poly]
 for rows in bc.values():
  rows.sort()
  for j,(a,b,i) in enumerate(rows):
   for v,w,k in rows[j+1:]:
    if v>=b:break
    if k!=i:G[i].add(k);G[k].add(i)
 with open('convex%d.dat'%n,'w')as f:
  print(*sides,len(poly),file=f)
  for t,ne in zip(poly,G):print(len(t),*(v for p in t for v in p),len(ne),*sorted(ne),file=f)
