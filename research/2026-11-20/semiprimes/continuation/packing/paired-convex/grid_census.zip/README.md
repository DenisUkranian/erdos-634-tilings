# Exhaustion of convex paired repairs with one or two uniform grids

The input data and the two paired-repair regions are described and verified in the companion convex-repairs archive. The coordinates here are axial, multiplied by 37 or 43 respectively.

For each board take all old paired cells U and the hole H, allowing any subset of U. The search enumerates every region with nonempty interior of the form H plus some of those cells whose union is convex. There are 2380 geometrically placed regions at 3431 and 11095 at 5063. These counts distinguish absolute placement. They also exhaust these choices inside the full nonconvex paired pentagons.

None of these 13475 convex regions is a union of whole cells of one uniform triangular lattice. None can be cut by a straight line into two positive-area polygons, each tiled by whole cells of its own uniform lattice of the unit triangle. The grids may be independently translated, rotated, or reflected. Here a uniform lattice is the plane triangulation by translates and half-turns of one copy of the given triangle. These exclusions already hold before imposing the pair-retention constraints. The original-board problem and repairs using additional grids remain open.

## Reproduce

Python 3.10 or later and a C++20 compiler suffice. Run with assertions enabled in this directory. The region files are also included as recorded results.

```sh
python3 data.py
c++ -std=c++20 -O3 convexall.cpp -o convexall
./convexall convex3431.dat 100000 > replay3431.out
./convexall convex5063.dat 100000 > replay5063.out
python3 compare_regions.py
python3 uniformconvex.py
python3 twogridconvex.py 3431
python3 twogridconvex.py 5063
python3 control.py
```

## Enumeration proof

H and U have disjoint open interiors, and their whole union is exactly the simple paired pentagon. Start with H. For the current selected cells, take their convex hull with H. Adjoin every old cell whose open interior intersects the hull interior. Repeat until the hull no longer grows. If its area exceeds the sum of the areas of the selected cells and H, it has entered the exterior of the paired pentagon and no convex superset contained in the pentagon can extend this candidate. For every valid convex set, try adjoining every old cell with a shared boundary segment of positive length before taking closure again.

Closure is independent of the order of absorption. Every convex union containing the seed must contain each absorbed cell in its entirety, since the old cell interiors are mutually disjoint and also disjoint from H. Every target convex union is reachable. Starting from the closure of H inside the target, if there are unselected target cells, at least one shares a positive-length boundary segment with the selected region. This follows by joining interior points with a generic polygonal path inside the convex target, avoiding the finite set of vertices. Closing after adding that cell stays inside the target and strictly increases the number of selected cells. The search memoizes the convex hull vertices and continues until its pending queue is empty. All intersection and area comparisons use exact integers. `compare_regions.py` additionally checks that the independently regenerated sets of absolute polygon boundaries agree with the archived outputs.

## Enumerating single grids and straight cuts

Each genuine polygon corner in one uniform grid is a lattice vertex. Once a unit triangle side is placed along a supporting axis, its side length, the ordered other lengths, and the choice of half-plane determine the shape. The program enumerates all of these choices. In the coordinates of two side vectors E and G, lattice vertices are the integer pairs, and mesh edges belong to lines with fixed integral first coordinate, second coordinate, or sum of coordinates.

A nondegenerate straight chord of a strictly convex polygon leaves at least one original polygon corner strictly between its endpoints on each boundary arc. Each piece therefore has an uncut polygon corner lying at a grid vertex, with both original incident rays among the three mesh directions. Use every such corner to enumerate all possible grid phases and orientations for the two pieces. Grids equal up to a translation by a lattice vector and a relabeling of their three unoriented edge vectors are identified.

For two selected grids each original vertex must be a lattice point in at least one of them, and each original side must lie on a grid line of at least one. For each surviving pair, each cut direction must be a mesh direction of both grids. Enumerate the finitely many grid-line levels within the projected polygon in that direction. For either choice of sides check all retained vertices, each retained edge segment, and the chord endpoints against the exact grid-line directions and integer-coordinate conditions in the corresponding grids. Inside a convex polygon made of mesh edges, these conditions suffice to fill it by whole mesh cells. The code uses rational arithmetic for all geometry. Exactly 283 and 660 pairs of grids, respectively, pass the preliminary vertex and side tests. Every prospective split fails a later test. One-grid cases are checked separately.

The positive control consists of two unit triangles related by reflection across their common longest side. The resulting kite is filled by two distinct grids, and its four boundary vertices and both triangle metrics are independently verified by `control.py`.
