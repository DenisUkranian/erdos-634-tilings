from pathlib import Path
for n,count in ((3431,2380),(5063,11095)):
    expected=Path(f'convex{n}.out').read_text().splitlines()
    actual=Path(f'replay{n}.out').read_text().splitlines()
    assert len(expected)==len(actual)==len(set(actual))==count
    assert set(actual)==set(expected)
    print(n,count,'absolute convex regions')
