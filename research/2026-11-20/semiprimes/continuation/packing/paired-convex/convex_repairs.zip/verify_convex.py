"""Verify the two convex subregions and lift an exact candidate to the original board."""
import argparse
import json
import tempfile
from pathlib import Path
from math import lcm
from fractions import Fraction
import verify_pentagon as small
import verify_5063 as big
from packing_replay import gradtri,pos,area,det,sub,edges,verify_boundary,disjoint


def check(n,candidate,output):
    if n==3431:
        module=small
        den=37
        sides=(7,33,37)
        scale=18
        cut=(16863,6204)
        area_convex=739
        remaining=201
    else:
        module=big
        den=43
        sides=(13,35,43)
        scale=20
        cut=(37765,17080)
        area_convex=1607
        remaining=521
    exterior,old,pairs=module.geometry()
    a,b,c,d,e=module.PENTAGON
    assert det(sub(c,b),sub(cut,b))==0
    assert min(b,c)<cut<max(b,c)
    triangle=pos([cut,c,d])
    convex=[a,b,cut,d,e]
    small.simple(convex)
    assert all(det(sub(convex[i],convex[i-1]),sub(convex[(i+1)%5],convex[i]))>0 for i in range(5))
    unit=sides[0]*sides[1]*den**2
    assert area(triangle)==scale**2*unit and area(convex)==area_convex*unit
    verify_boundary([(1,triangle),(1,convex),(-1,module.PENTAGON)])
    frozen={small.key(t) for t in gradtri(triangle,scale)}
    assert len(frozen)==scale**2 and frozen<=set(old)
    assert set(t for t in old if not disjoint(pos(t),triangle))==frozen
    small.certify_tiling(frozen,triangle,den,scale**2,sides)
    left=[(i,j) for i,j in pairs if old[i] not in frozen and old[j] not in frozen]
    assert len(left)==remaining
    print(f'{n}: convex pentagon area {area_convex}, {remaining} remaining pair constraints; {len(frozen)} old cells retained in the detached triangle.')
    if not candidate:
        return
    data=json.loads(candidate.read_text())
    input_den=data['denominator']
    assert type(input_den) is int and input_den>0
    assert all(type(z) is int for t in data['triangles'] for p in t for z in p)
    l=lcm(den,input_den)
    proposed=[small.key(small.scaled(t,l//input_den)) for t in data['triangles']]
    small.certify_tiling(proposed,small.scaled(convex,l//den),l,area_convex,sides)
    values=set(proposed)
    assert all(small.key(small.scaled(old[i],l//den)) in values or small.key(small.scaled(old[j],l//den)) in values for i,j in left)
    for t in frozen:
        proposed.append(small.key(small.scaled(t,l//den)))
    with tempfile.TemporaryDirectory() as folder:
        path=Path(folder)/'pentagon.json'
        path.write_text(json.dumps({'denominator':l,'triangles':proposed}))
        small.lift(path,output,exterior,old,pairs,base=den,sides=sides,delta0=module.DELTA,
                   board=module.BOARD,polygon=module.PENTAGON,count=area_convex+scale**2,full_count=n)


if __name__=='__main__':
    if not __debug__:
        raise SystemExit('Run without -O.')
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('board',type=int,choices=[3431,5063])
    parser.add_argument('candidate',type=Path,nargs='?')
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    if args.output and not args.candidate:
        parser.error('--output requires a candidate')
    check(args.board,args.candidate,args.output)
