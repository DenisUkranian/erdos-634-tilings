"""Check the full-board 5063 paired-repair geometry and lift a candidate pentagon tiling."""
import argparse
import json
from pathlib import Path
from verify_pentagon import HERE,PACKING,key,move,simple,lift
from check_inventory import replay
from check_boards import check_holes
from packing_replay import area,det,edges,norm,pos,sub,verify_boundary

BOARD = [(0,0),(46397,0),(0,91805)]
DELTA = (-11180,13545)
HOLE = [(35217,13545),(34400,13545),(34400,12986),(35905,12986),(35905,12427),(36465,12635)]
PENTAGON = [(11180,0),(46397,0),(16185,59780),(25285,26180),(11180,20941)]
UNIT = 35*13*43**2


def geometry():
    data=json.loads((HERE/'pair5063.json').read_text())
    cert=json.loads((PACKING/'inventory_certificate.json').read_text())
    board,all_cells,selected=replay(35,13,43,cert['5063'])
    assert list(map(tuple,board))==BOARD and len(selected)==5059
    exterior={key(all_cells[i]) for i in selected}
    assert len(exterior)==5059
    check_holes(board,[all_cells[i] for i in selected])
    assert data['area']==2007 and tuple(data['offset'])==DELTA and list(map(tuple,data['H']))==HOLE
    simple(HOLE)
    assert area(HOLE)==2*UNIT
    verify_boundary([(1,pos(t)) for t in exterior]+[(1,HOLE),(1,move(HOLE,DELTA)),(-1,BOARD)])
    cells=list(map(key,data['U']))
    expected={t for t in exterior if key(move(t,DELTA)) in exterior}
    assert len(cells)==len(set(cells))==2005 and set(cells)==expected
    lookup={t:i for i,t in enumerate(cells)}
    pairs=[(i,lookup[u]) for i,t in enumerate(cells) if (u:=key(move(t,DELTA))) in lookup]
    assert len(pairs)==len(data['matching'])==602
    assert set(pairs)==set(map(tuple,data['matching']))
    assert len({i for pair in pairs for i in pair})==1204
    simple(PENTAGON)
    assert area(PENTAGON)==2007*UNIT
    assert [norm(sub(q,p)) for p,q in edges(PENTAGON)]==[(43*x)**2 for x in (819,1204,700,403,487)]
    assert [i for i,b in enumerate(PENTAGON) if det(sub(b,PENTAGON[i-1]),sub(PENTAGON[(i+1)%5],b))<0]==[3]
    assert set(edges(PENTAGON))=={(tuple(a),tuple(b)) for a,b in data['edges']}
    verify_boundary([(1,pos(t)) for t in cells]+[(1,HOLE),(-1,PENTAGON)])
    print('5059 exterior cells with two area-2 holes; 2005 translated partners; 602 constraints.')
    print('Pentagon area 2007; cyclic side lengths 819, 1204, 700, 403, 487; vertex 4 is reflex.')
    return exterior,cells,pairs


if __name__=='__main__':
    if not __debug__:
        raise SystemExit('Run without -O.')
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('candidate',type=Path,nargs='?')
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    if args.output and not args.candidate:
        parser.error('--output requires a pentagon tiling')
    data=geometry()
    if args.candidate:
        lift(args.candidate,args.output,*data,base=43,sides=(13,35,43),delta0=DELTA,
             board=BOARD,polygon=PENTAGON,count=2007,full_count=5063)
