"""Verify a placement budget by exact enumeration of all rigid triangles meeting a weighted endpoint."""
import json,sys
from fractions import Fraction as F
from pathlib import Path
from collections import defaultdict
from math import gcd,isqrt
root=Path(__file__).resolve().parent
if len(sys.argv)>2:
    repo=Path(sys.argv[2]).resolve()
else:
    options=[q for base in [root,*root.parents] for q in (base,base/'research/2026-11-20/semiprimes',base/'previous/research/2026-11-20/semiprimes')]
    repo=next(q for q in options if (q/'continuation/packing/check_3427.py').is_file())
sys.path.insert(0,str(repo/'continuation/packing'))
from check_3427 import build
from packing_replay import area,det,sub,edges,disjoint
def mul(p,q):x,y=p;z,w=q;return (x*z-y*w,x*w+y*z+y*w)
def add(p,q):return (p[0]+q[0],p[1]+q[1])
def times(s,p):return(s*p[0],s*p[1])
def tris_on(axis):
    dx,dy=axis
    n=isqrt(dx*dx+dx*dy+dy*dy);assert n*n==dx*dx+dx*dy+dy*dy
    result=set()
    for sense in (-1,1):
        u=F(sense*dx,n),F(sense*dy,n)
        for l,s,k in [(x,y,z) for x in (33,7,37) for y in (33,7,37) for z in (33,7,37) if len({x,y,z})==3]:
            for side in (-1,1):
                q=times(l,u);third=mul(u,(F(l*l+s*s-k*k-side*231,2*l),F(side*231,l)))
                if det(q,third)>0:row=(q,third,1)
                else:row=(q,third,-1)
                result.add(row)
    assert len(result)==24;return result
def verify(filename):
    d=json.loads(Path(filename).read_text());N=3431;board=((0,0),(511,0),(0,1551));scale=d['scale'];assert scale%100==0
    exists=lambda p:p[0]>=0 and p[1]>=0 and 1551*p[0]+511*p[1]<=511*1551
    original={tuple(sorted(t)) for t in build(repo/'continuation/packing')[:3399]}
    taxes=defaultdict(int);required=0;shapes={};alltris=set(original)
    for x,y,px,dpx,py,dpy,w in d['weights']:
        A=(x,y);assert A>(0,0) and gcd(x,y)==1
        o=F(px,dpx*37),F(py,dpy*37)
        if A not in shapes:shapes[A]=tris_on(A)
        for q,r,sgn in shapes[A]:
            t=tuple(sorted((o,add(o,q),add(o,r))))
            if all(map(exists,t)):
                alltris.add(t);taxes[t]+=sgn*w
        for p,q in edges(board):
            if det(sub(q,p),A)==0:required+=w*(int(o==p)-int(o==q))
    valsum=0
    decode=lambda t:tuple(sorted((F(x,d['D']*37),F(y,d['D']*37)) for x,y in t))
    for a,b,v in d['pairs']:
        ts=[decode(a),decode(b)]
        assert v>=0
        for t in ts:
            ns=[x*x+x*y+y*y for x,y in (sub(p,q) for p,q in edges(t))]
            assert all(map(exists,t)) and sorted(ns)==[49,1089,1369]
            alltris.add(t);taxes[t]+=v
        x,y=ts;assert not disjoint(x if area(x)>0 else x[::-1],y if area(y)>0 else y[::-1])
        valsum+=v
    probes=d.get('probes',[])
    if probes:
        from collections import defaultdict as group
        from math import lcm
        buckets=group(list);grid=d['D']*37
        for px,qx,py,qy,w in probes:
            xx,yy=F(px,qx*37),F(py,qy*37);assert w>=0
            bucket=(int(xx//37),int(yy//37));m=lcm(xx.denominator,yy.denominator)
            buckets[bucket].append((int(xx*m)*grid,int(yy*m)*grid,m,w));valsum+=w
        for t in alltris:
            raw=[tuple(v*grid for v in p) for p in t];assert all(z.denominator==1 for p in raw for z in p)
            ps=[tuple(map(int,p)) for p in raw];ps=ps if area(ps)>0 else ps[::-1]
            planes=[(q[0]-p[0],q[1]-p[1],det(sub(q,p),p)) for p,q in edges(ps)]
            for bx in range(min(p[0] for p in ps)//(grid*37),max(p[0] for p in ps)//(grid*37)+1):
                for by in range(min(p[1] for p in ps)//(grid*37),max(p[1] for p in ps)//(grid*37)+1):
                    for x,y,m,w in buckets.get((bx,by),[]):
                        if all(dx*y-dy*x>m*k for dx,dy,k in planes):taxes[t]+=w
    mass=d['mass_lambda'];assert mass>=0
    adj=sum(max(0,(scale if t in original else -scale//100)-mass-taxes[t]) for t in alltris)
    expected=(100*(required+valsum+mass*N+adj)//scale+N)//101
    print('Repriced candidates',len(alltris),'exterior reference maximum',expected,flush=True)
    assert (required,adj,expected)==(d['target'],d['residual'],d['bound'])
if __name__=='__main__':
    if not __debug__:
        raise SystemExit('Run without -O.')
    verify(sys.argv[1])
