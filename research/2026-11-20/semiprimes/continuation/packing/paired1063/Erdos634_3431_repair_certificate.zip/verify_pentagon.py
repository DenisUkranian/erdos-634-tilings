"""Rebuild the paired-repair pentagon and optionally lift an exact candidate tiling."""
import argparse
import json
import sys
from pathlib import Path
from math import lcm

HERE = Path(__file__).resolve().parent
PACKING = HERE / 'research/2026-11-20/semiprimes/continuation/packing'
sys.path.insert(0, str(PACKING))
from check_3427 import build
from packing_replay import add, area, det, edges, norm, pos, sub, verify_boundary

DELTA = (-4662, 6105)
BOARD = [(0, 0), (511*37, 0), (0, 1551*37)]
HOLE = [(14208, 4033), (15429, 4033), (16485, 4257), (14245, 6105), (14208, 6105)]
PENTAGON = [(4662, 0), (18907, 0), (7665, 34122), (11823, 10362), (4662, 8843)]
UNIT = 231*37**2


def key(points):
    return tuple(sorted(map(tuple, points)))


def move(shape, delta):
    return [add(point, delta) for point in shape]


def scaled(shape, factor):
    return [(factor*x, factor*y) for x,y in shape]


def simple(shape):
    """Check every nonadjacent segment pair, including collinear or endpoint contact."""
    lines = list(edges(shape))
    assert len(set(shape)) == len(shape)
    for i, (a,b) in enumerate(lines):
        for c,d in lines[i+1:]:
            if a in (c,d) or b in (c,d):
                continue
            if any(max(min(a[k],b[k]),min(c[k],d[k])) > min(max(a[k],b[k]),max(c[k],d[k])) for k in (0,1)):
                continue
            ab,cd = sub(b,a),sub(d,c)
            assert det(ab,sub(c,a))*det(ab,sub(d,a)) > 0 or det(cd,sub(a,c))*det(cd,sub(b,c)) > 0


def geometry():
    data = json.loads((HERE/'pair_all.json').read_text())
    assert tuple(data['offset']) == DELTA and list(map(tuple,data['H'])) == HOLE
    reference = build(PACKING)[:3399]
    grid = [scaled(t,37) for t in reference]
    assert all(v.denominator == 1 for t in grid for p in t for v in p)
    exterior = {key((int(x),int(y)) for x,y in t) for t in grid}
    assert len(exterior) == 3399
    simple(HOLE)
    assert area(HOLE) == 16*UNIT
    verify_boundary([(1,pos(t)) for t in exterior] + [(1,HOLE),(1,move(HOLE,DELTA)),(-1,BOARD)])
    cells = list(map(key,data['U']))
    expected = {t for t in exterior if key(move(t,DELTA)) in exterior}
    assert len(cells) == len(set(cells)) == 1047 and set(cells) == expected
    index = {t:i for i,t in enumerate(cells)}
    pairs = [(i,index[successor]) for i,t in enumerate(cells) if (successor:=key(move(t,DELTA))) in index]
    assert len(pairs) == len(set(map(tuple,data['matching']))) == len(data['matching']) == 226
    assert set(pairs) == set(map(tuple,data['matching']))
    assert len({i for pair in pairs for i in pair}) == 452
    simple(PENTAGON)
    assert area(PENTAGON) == data['area']*UNIT == 1063*UNIT
    assert [norm(sub(b,a)) for a,b in edges(PENTAGON)] == [(37*x)**2 for x in [385,814,594,217,239]]
    reflex = [i for i,b in enumerate(PENTAGON) if det(sub(b,PENTAGON[i-1]),sub(PENTAGON[(i+1)%5],b)) < 0]
    assert reflex == [3]
    assert set(edges(PENTAGON)) == {(tuple(a),tuple(b)) for a,b in data['edges']}
    verify_boundary([(1,pos(t)) for t in cells] + [(1,HOLE),(-1,PENTAGON)])
    print('3399 exterior cells with two area-16 holes; 1047 translated partners; 226 constraints.')
    print('Pentagon area 1063; cyclic side lengths 385, 814, 594, 217, 239; vertex 4 is reflex.')
    return exterior, cells, pairs


def certify_tiling(cells, boundary, denominator, count):
    assert len(cells) == len(set(cells)) == count
    lengths = [(denominator*s)**2 for s in (7,33,37)]
    for t in cells:
        assert len(t) == 3 and sorted(norm(sub(q,p)) for p,q in edges(t)) == lengths
    verify_boundary([(1,pos(t)) for t in cells] + [(-1,boundary)])


def lift(candidate, output, exterior, cells, pairs):
    data = json.loads(candidate.read_text())
    den = data['denominator']
    assert type(den) is int and den>0
    triangles = data['triangles']
    assert all(type(z) is int for t in triangles for p in t for z in p)
    common = lcm(37,den)
    factor = common//37
    proposed = [key(scaled(t,common//den)) for t in triangles]
    certify_tiling(proposed,scaled(PENTAGON,factor),common,1063)
    proposal = set(proposed)
    old = {key(scaled(t,factor)) for t in exterior}
    lower = [key(scaled(t,factor)) for t in cells]
    assert all(lower[i] in proposal or lower[j] in proposal for i,j in pairs)
    missing = set(lower)-proposal
    added = proposal-set(lower)
    delta = scaled([DELTA],factor)[0]
    upper = {key(move(t,delta)) for t in missing}
    assert missing.isdisjoint(upper) and missing|upper <= old
    result = sorted(list(old-missing-upper)+list(added)+[key(move(t,delta)) for t in added])
    certify_tiling(result,scaled(BOARD,factor),common,3431)
    print('Verified 3431 congruent triangles covering the full board exactly.')
    if output:
        with output.open('x') as out:
            json.dump({'denominator':common,'triangles':result},out,separators=(',',':'))


if __name__=='__main__':
    if not __debug__:
        raise SystemExit('Run without -O.')
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('candidate',type=Path,nargs='?')
    parser.add_argument('--output',type=Path,help='New file for the verified full-board tiling')
    args=parser.parse_args()
    if args.output and not args.candidate:
        parser.error('--output requires a pentagon tiling')
    geometry_data=geometry()
    if args.candidate:
        lift(args.candidate,args.output,*geometry_data)
