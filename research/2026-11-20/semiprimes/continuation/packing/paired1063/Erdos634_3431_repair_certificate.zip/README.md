# Exact reference distance and a constructive reduction for the 3431 board

For a triangle tiled by 3431 congruent triangles of sides 7, 33 and 37, take the outer axial coordinates to be (0,0), (511,0) and (0,1551). The two coordinate axes meet at 60 degrees. The verified reference packing uses 3427 tiles and leaves four tile areas uncovered. Existence of a complete tiling remains open.

* Every complete tiling must omit at least **74** members of the 3427 reference packing and introduce at least **78** other placements.
* A smaller sufficient construction asks for a tiling of a single nonconvex pentagon of area **1063** in tile units. Its tiling must retain one or both specified original placements in each of 226 disjoint pairs. The provided program turns any such tiling into a verified 3431-tile full-board certificate.

## Replay

Python 3.10 or later suffices. Run from the extracted directory with assertions enabled. No optimizer or external package is needed.

```sh
python3 replay_reference.py certificate.json
python3 research/2026-11-20/semiprimes/continuation/phase-height/verify.py
python3 verify_pentagon.py
```

The first and third commands independently reconstruct the reference packing. The first command checks the exact integer bound 3353 after repricing 84,770 placements. The second checks the position and population calculations used in the phase proof included below. The third compares the geometry and all index pairs in `pair_all.json` with the reconstructed exterior. Recorded outputs are in `reference_replay.txt`, `phase_replay.txt` and `pentagon_replay.txt`.

## Exact distance proof

Write E for the 3399 exterior placements, excluding the 28 tiles used to repack the two pentagonal holes. In any full tiling T let K count the members of E retained by T. Give each placement t score c(t) equal to S if t belongs to E and −S/100 otherwise, with S = 100,000,000. Since every full tiling has N = 3431 placements, its total score is S(101K − N)/100.

Choose a supporting line and an endpoint on it. An oriented counterclockwise tile edge contributes +1 if it starts at this endpoint and −1 if it ends there. The corresponding signed indicators sum over the tiling to the analogous outer boundary indicator. This follows by cancellation of the oriented boundary chain along each supporting line, including when a tile endpoint lies inside the side of a neighbor.

The certificate assigns signed integer weights to selected endpoint equations. Let D(t) be the resulting tile contribution and B the outer boundary contribution. Then the sum of D(t) over T is B. For each listed interior test point with nonnegative weight w, charge every tile containing the point strictly in its interior the amount w. The charge P(t) totals at most W, the sum of all test weights, since open interiors are disjoint. The verifier also accepts optional nonnegative charges for explicitly overlapping pairs with combined use at most one, although this certificate uses none.

With the nonnegative mass charge m from the certificate, a valid upper bound on the score is

```
B + W + m*N + sum_t max(0, c(t) - D(t) - P(t) - m).
```

Even for arbitrary real translations and arbitrary rotations or reflections, the positive residual sum is finite. Every exterior reference placement is enumerated. Among the other placements, a positive residual requires contact at a nonzero weighted endpoint, since c(t) is strictly negative and P(t) and m are nonnegative. At each such endpoint and supporting axis there are exactly 24 possible incident placements before board containment. Choose either axis sense, assign the three distinct side lengths to the incident axis side and its two remaining sides, then choose either side of the axis. The metric fixes the third vertex uniquely. The replayer constructs all 24 choices by exact rational operations in axial coordinates, retains the placements contained in the board, and removes duplicates. Every placement can have multiplicity at most one. The integer certificate verifies all contributions, and rounding the resulting score bound gives K ≤ 3353. The cap on E requires no assumptions on heights, phases, or allowable directions.

For the other 28 reference placements, the established board-specific phase theorem excludes each of 20 high placements. Retaining any of the other eight forces at least 290 omissions from the 3427 reference tiles. Thus with no replacement retained the total retained is at most 3353, and with any replacement retained it is at most 3137. Subtracting 3353 from 3427 and from 3431 gives the two claimed distance bounds. The included proof supplies the phase theorem's geometric premises and arithmetic deductions. [Board-specific proof](research/2026-11-20/semiprimes/continuation/phase-height/3431.md) · [Phase theorem](research/2026-11-20/semiprimes/continuation/phase-height/PHASE_BRANCHES.md)

## A pentagon with a sufficient matching condition

All coordinates in this section are physical axial coordinates multiplied by 37. The 3399 exterior tiles leave precisely two translates of one pentagonal region H. The translation is δ = (−4662,6105). H has cyclic vertices

```
(14208,4033), (15429,4033), (16485,4257), (14245,6105), (14208,6105).
```

Let U consist of all u in E for which u+δ also belongs to E. There are exactly 1047. The union C of H with the cells of U is a simple pentagon with counterclockwise vertices

```
(4662,0), (18907,0), (7665,34122), (11823,10362), (4662,8843).
```

Its successive physical side lengths are 385, 814, 594, 217, 239. Its fourth vertex is reflex, and its area is 1063 unit tile areas. Exactly 226 pairs u, u+δ both belong to U. All 452 endpoints of these pairs are distinct. The data file lists U and uses zero-based indices for pairs. The replay computes U and the pairs afresh and proves C has the stated area and boundary. Equality of oriented boundaries of the finite unions implies equality of multiplicity functions off the boundary lines, by winding numbers. For closed finite unions the resulting tilings include their boundary.

Suppose C has a genuine tiling by the unit triangles with at least one original placement from each of the 226 pairs. Let M be the cells of U absent from the new tiling and A the new tiling with its members of U omitted. Off finitely many boundary lines their multiplicities satisfy

```
sum of indicators of A − sum of indicators of M = indicator of H.
```

The pair condition says M and M+δ are disjoint families of original placements. Remove both from E and insert A and A+δ. Adding the displayed equality to its translate verifies the new whole-board multiplicity equals one inside the original board and zero outside. All triangle coefficients in the construction are nonnegative. Therefore the interiors cannot overlap, and area fixes the count at 3431.

Conversely, consider a successful repair that adds pairs t, t+δ and removes disjoint pairs u, u+δ of exterior tiles. Every lower removal belongs to U. Its difference from the displayed one-sheet equality is a compactly supported function f satisfying f(x)+f(x−δ)=0 almost everywhere. Iteration along this nonzero translation gives f=0 almost everywhere. Retaining the members of U outside the lower removal set and adding the lower additions thus gives a tiling of C obeying the 226 pair constraints. This characterizes that specific repair class; the original board can admit other kinds of tilings.

## Checking and lifting a candidate

A candidate file contains an integer `denominator` and a list `triangles` with 1063 entries. Each entry consists of three vertices, each an integer pair [x,y] representing the physical axial point (x/denominator,y/denominator). Reflections, orientations, triangle order and vertex order are unrestricted. Use a fresh output path.

```sh
python3 verify_pentagon.py candidate.json --output board3431.json
```

The command compares every triangle metric and the entire oriented boundary of the proposal to C. It checks the 226 constraints, performs the construction, and then independently checks that the resulting 3431 distinct congruent triangles have precisely the oriented boundary of the original triangle. This archive contains the reduction and its geometry with no proposed successful pentagon tiling.

## Earlier work and licenses

The reference geometry, reconstruction and phase theorem are from Denis Paliy's Erdős 634 tilings project. The files under `research/` are original repository materials. The earlier 20 November research checkpoint used the geometry of commit `aff4ab39ec4365fd72f29aab9f7beb04adc817f4`. The phase files and linked prerequisites are included from the public repository. License texts accompany the archive. [Repository](https://github.com/DenisUkranian/erdos-634-tilings) · [Pinned earlier sources](https://github.com/DenisUkranian/erdos-634-tilings/tree/aff4ab39ec4365fd72f29aab9f7beb04adc817f4)
